const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import MdirecordRec from "./components/MdirecordRec";
import ChmCngThnhCng from "./screens/ChmCngThnhCng";
import ChcNng from "./screens/ChcNng";
import DanhSchBoCoCngVic from "./screens/DanhSchBoCoCngVic";
import MnHnhHinThCngVic from "./screens/MnHnhHinThCngVic";
import VTrKhngHpL from "./screens/VTrKhngHpL";
import ChmCng from "./screens/ChmCng";
import ChmCng1 from "./screens/ChmCng1";
import BnCChcChnMunNgXu from "./screens/BnCChcChnMunNgXu";
import DanhSchNhGiNhnVinK from "./screens/DanhSchNhGiNhnVinK";
import NhGiNhnVinKhc from "./screens/NhGiNhnVinKhc";
import YuCuBtNhV from "./screens/YuCuBtNhV";
import NhpM from "./screens/NhpM";
import NhpSInThoiLyLi from "./screens/NhpSInThoiLyLi";
import NhpMtKhuMi from "./screens/NhpMtKhuMi";
import TmNhnVinNhGi from "./screens/TmNhnVinNhGi";
import TtCThngBo from "./screens/TtCThngBo";
import ThngBoMiNht from "./screens/ThngBoMiNht";
import ThngBoCHn from "./screens/ThngBoCHn";
import Component from "./components/Component";
import ThLi from "./components/ThLi";
import BQua from "./components/BQua";
import Bt from "./components/Bt";
import QuayLi1 from "./components/QuayLi1";
import NtChpNh from "./components/NtChpNh";
import GiOTP from "./components/GiOTP";
import ChcChn from "./components/ChcChn";
import Khng from "./components/Khng";
import MyQuay from "./components/MyQuay";
import ThngBo from "./components/ThngBo";
import TtC from "./components/TtC";
import MiNht from "./components/MiNht";
import CHn from "./components/CHn";
import XaThngBo from "./components/XaThngBo";
import NhpVoNtThngBo from "./components/NhpVoNtThngBo";
import ToMtKhuThnhCng from "./screens/ToMtKhuThnhCng";
import Ti1 from "./components/Ti1";
import Ti from "./screens/Ti";
import Ellipse from "./components/Ellipse";
import NiDungNhGi from "./screens/NiDungNhGi";
import MnHnhHinThInNiDun from "./components/MnHnhHinThInNiDun";
import NgNhp from "./screens/NgNhp";
import XemBngCngCNhn from "./screens/XemBngCngCNhn";
import DanhSchBngCngCNhnTh from "./screens/DanhSchBngCngCNhnTh";
import NhGi from "./components/NhGi";
import GiBoCo from "./components/GiBoCo";
import LuBoCo from "./components/LuBoCo";
import QuayLi from "./components/QuayLi";
import ChmCngVo from "./components/ChmCngVo";
import ChmCngRa from "./components/ChmCngRa";
import XemBngCng from "./components/XemBngCng";
import XemCngVic from "./components/XemCngVic";
import NhGiNhnVinKhc1 from "./components/NhGiNhnVinKhc1";
import NgNhp1 from "./components/NgNhp1";
import NgXut from "./components/NgXut";
import TipTc from "./components/TipTc";
import Xong1 from "./components/Xong";
import Gi from "./components/Gi";
import XcNhn from "./components/XcNhn";
import QunMtKhu from "./components/QunMtKhu";
import ChcNng1 from "./components/ChcNng1";
import MnHnhCameraQuayBoCoC from "./screens/MnHnhCameraQuayBoCoC";
import TrangCh from "./screens/TrangCh";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Roboto-Regular": require("./assets/fonts/Roboto-Regular.ttf"),
    "Roboto-Bold": require("./assets/fonts/Roboto-Bold.ttf"),
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
    "Alata-Regular": require("./assets/fonts/Alata-Regular.ttf"),
    "OpenSans-Light": require("./assets/fonts/OpenSans-Light.ttf"),
    "OpenSans-Regular": require("./assets/fonts/OpenSans-Regular.ttf"),
    "OpenSans-SemiBold": require("./assets/fonts/OpenSans-SemiBold.ttf"),
    "OpenSans-Bold": require("./assets/fonts/OpenSans-Bold.ttf"),
    "Montserrat-Medium": require("./assets/fonts/Montserrat-Medium.ttf"),
    "Montserrat-Bold": require("./assets/fonts/Montserrat-Bold.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="ChmCngThnhCng"
              component={ChmCngThnhCng}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChcNng"
              component={ChcNng}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DanhSchBoCoCngVic"
              component={DanhSchBoCoCngVic}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="MnHnhHinThCngVic"
              component={MnHnhHinThCngVic}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="VTrKhngHpL"
              component={VTrKhngHpL}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChmCng"
              component={ChmCng}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChmCng1"
              component={ChmCng1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="BnCChcChnMunNgXu"
              component={BnCChcChnMunNgXu}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DanhSchNhGiNhnVinK"
              component={DanhSchNhGiNhnVinK}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NhGiNhnVinKhc"
              component={NhGiNhnVinKhc}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="YuCuBtNhV"
              component={YuCuBtNhV}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NhpM"
              component={NhpM}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NhpSInThoiLyLi"
              component={NhpSInThoiLyLi}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NhpMtKhuMi"
              component={NhpMtKhuMi}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TmNhnVinNhGi"
              component={TmNhnVinNhGi}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TtCThngBo"
              component={TtCThngBo}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ThngBoMiNht"
              component={ThngBoMiNht}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ThngBoCHn"
              component={ThngBoCHn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ToMtKhuThnhCng"
              component={ToMtKhuThnhCng}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Ti"
              component={Ti}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NiDungNhGi"
              component={NiDungNhGi}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="NgNhp"
              component={NgNhp}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="XemBngCngCNhn"
              component={XemBngCngCNhn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DanhSchBngCngCNhnTh"
              component={DanhSchBngCngCNhnTh}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="MnHnhCameraQuayBoCoC"
              component={MnHnhCameraQuayBoCoC}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TrangCh"
              component={TrangCh}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;

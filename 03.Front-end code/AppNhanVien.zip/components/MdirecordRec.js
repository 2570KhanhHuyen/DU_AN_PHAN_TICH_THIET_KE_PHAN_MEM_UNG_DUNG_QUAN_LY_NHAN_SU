import * as React from "react";
import { StyleSheet, View } from "react-native";

const MdirecordRec = () => {
  return <View style={styles.mdirecordRec} />;
};

const styles = StyleSheet.create({
  mdirecordRec: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
});

export default MdirecordRec;

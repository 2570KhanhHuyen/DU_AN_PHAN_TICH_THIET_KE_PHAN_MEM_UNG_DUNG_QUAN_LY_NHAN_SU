import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const LuBoCo = () => {
  return (
    <View style={styles.luBoCo}>
      <View style={[styles.property1group7262, styles.property1groupLayout]}>
        <View style={styles.property1group7262Child} />
        <Text style={styles.luBoCo1}>Lưu báo cáo</Text>
      </View>
      <View style={[styles.property1group7263, styles.property1groupLayout]}>
        <View style={styles.property1group7262Child} />
        <Text style={styles.luBoCo1}>Lưu báo cáo</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 28,
    width: 118,
    left: 20,
    position: "absolute",
  },
  property1group7262Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: Color.colorPaleturquoise,
    position: "absolute",
    borderRadius: Border.br_8xs,
  },
  luBoCo1: {
    height: "83.33%",
    width: "86.44%",
    top: "10.87%",
    left: "6.78%",
    fontSize: FontSize.size_mid,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorSeagreen,
    textAlign: "left",
    position: "absolute",
  },
  property1group7262: {
    top: 20,
  },
  property1group7263: {
    top: 63,
  },
  luBoCo: {
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 158,
    height: 111,
    overflow: "hidden",
    borderRadius: Border.br_8xs,
  },
});

export default LuBoCo;

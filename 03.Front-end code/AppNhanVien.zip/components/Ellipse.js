import * as React from "react";
import { StyleSheet, View } from "react-native";

const Ellipse = () => {
  return <View style={styles.ellipseView} />;
};

const styles = StyleSheet.create({
  ellipseView: {
    backgroundColor: "#007bff",
    width: 6,
    height: 6,
    opacity: 0,
  },
});

export default Ellipse;

import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import Property1Component from "./Property1Component";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const Ti1 = () => {
  return (
    <View style={styles.ti}>
      <View style={styles.property1component2}>
        <Image
          style={styles.iconPerson}
          contentFit="cover"
          source={require("../assets/-icon-person.png")}
        />
        <Text style={styles.ti1}>TÔI</Text>
      </View>
      <Property1Component iconPerson={require("../assets/-icon-person2.png")} />
    </View>
  );
};

const styles = StyleSheet.create({
  iconPerson: {
    height: "58.37%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "41.63%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  ti1: {
    height: "25.58%",
    width: "59.38%",
    top: "74.42%",
    left: "18.75%",
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    textAlign: "center",
    position: "absolute",
  },
  property1component2: {
    top: 20,
    left: 20,
    width: 32,
    height: 43,
    position: "absolute",
  },
  ti: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 72,
    height: 149,
    overflow: "hidden",
  },
});

export default Ti1;

import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import Property1Component from "./Property1Component";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const MnHnhHinThInNiDun = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.baoCaoCongViec}>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.viewPosition]} />
        <Image
          style={[styles.groupItem, styles.groupItemLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-51.png")}
        />
      </View>
      <View style={[styles.vectorParent, styles.rectangleLayout]}>
        <Image
          style={styles.groupInner}
          contentFit="cover"
          source={require("../assets/vector-221.png")}
        />
        <View style={[styles.rectangleWrapper, styles.rectangleLayout]}>
          <View style={[styles.rectangleView, styles.rectangleLayout]} />
        </View>
        <View style={[styles.groupWrapper, styles.groupParentPosition]}>
          <View style={[styles.groupParent, styles.groupParentPosition]}>
            <View style={[styles.groupContainer, styles.groupParentPosition]}>
              <View style={[styles.cngVic1Parent, styles.groupParentPosition]}>
                <Text style={[styles.cngVic1Container, styles.text2Typo]}>
                  <Text style={styles.cngVic1}>Công việc 1</Text>
                  <Text style={styles.text}>{` `}</Text>
                </Text>
                <View style={[styles.frameView, styles.viewPosition]} />
                <Text style={[styles.text1, styles.text1Typo]}>02/08/2024</Text>
                <Text style={[styles.nhpNiDung, styles.text1Typo]}>
                  Nhập nội dung ...
                </Text>
                <Text style={[styles.text2, styles.text2Typo]}>10:00</Text>
              </View>
              <Image
                style={styles.vectorIcon}
                contentFit="cover"
                source={require("../assets/vector4.png")}
              />
            </View>
            <View style={styles.lineView} />
          </View>
        </View>
        <Image
          style={styles.rectangleIcon}
          contentFit="cover"
          source={require("../assets/rectangle-90.png")}
        />
      </View>
      <View style={styles.materialSymbolsLightpause} />
      <Image
        style={[styles.baoCaoCongViecChild, styles.groupItemLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <View style={styles.luBoCo}>
        <View style={[styles.luBoCoChild, styles.luBoCoChildPosition]} />
        <Text style={styles.luBoCo1}>Lưu báo cáo</Text>
      </View>
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[styles.quayLiChild, styles.quayIconLayout]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.quayIconLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-402.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcNngItemPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-422.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-412.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-432.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Clr]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={[styles.trangCh, styles.chcNng1Clr]}>TRANG CHỦ</Text>
        <Image
          style={styles.homeIcon}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={759}
        propLeft={338}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <Pressable
        style={[styles.myQuay, styles.myQuayLayout]}
        onPress={() => navigation.navigate("MnHnhCameraQuayBoCoC")}
      >
        <View style={[styles.videoCallParent, styles.myQuayLayout]}>
          <Image
            style={[styles.videoCallIcon, styles.luBoCoChildPosition]}
            contentFit="cover"
            source={require("../assets/video-call.png")}
          />
          <Image
            style={[styles.vectorIcon1, styles.quayIconLayout]}
            contentFit="cover"
            source={require("../assets/vector5.png")}
          />
        </View>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 66,
    position: "absolute",
    width: 402,
  },
  viewPosition: {
    top: 0,
    left: 0,
  },
  groupItemLayout: {
    opacity: 0,
    width: "1.59%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  rectangleLayout: {
    height: 442,
    width: 374,
    position: "absolute",
  },
  groupParentPosition: {
    height: 85,
    top: 0,
    position: "absolute",
  },
  text2Typo: {
    height: 27,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    top: 13,
    position: "absolute",
  },
  text1Typo: {
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.openSansRegular,
    height: 27,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  luBoCoChildPosition: {
    bottom: "0%",
    height: "100%",
    left: "0%",
    top: "0%",
    width: "100%",
    right: "0%",
    position: "absolute",
  },
  quayIconLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  chcNngLayout: {
    width: 62,
    position: "absolute",
  },
  chcLayout: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngItemPosition: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNngInnerLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Clr: {
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  myQuayLayout: {
    height: 104,
    width: 90,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorGray_200,
    height: 66,
    position: "absolute",
    width: 402,
  },
  groupItem: {
    height: "9.04%",
    top: "66.87%",
    right: "39.24%",
    bottom: "24.1%",
    left: "59.16%",
  },
  rectangleParent: {
    top: 746,
    left: 0,
  },
  groupInner: {
    left: 5,
    width: 355,
    top: 59,
    maxHeight: "100%",
    position: "absolute",
  },
  rectangleView: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_8xs,
    top: 0,
    left: 0,
  },
  rectangleWrapper: {
    top: 0,
    left: 0,
  },
  cngVic1: {
    color: Color.colorDarkorchid,
  },
  text: {
    color: Color.colorBlack,
  },
  cngVic1Container: {
    width: 87,
    left: 8,
  },
  frameView: {
    width: 100,
    height: 33,
    opacity: 0.33,
    position: "absolute",
    overflow: "hidden",
  },
  text1: {
    left: 134,
    width: 85,
    top: 13,
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.openSansRegular,
  },
  nhpNiDung: {
    width: 273,
    left: 8,
    top: 59,
  },
  text2: {
    left: 265,
    width: 42,
    color: Color.colorBlack,
  },
  cngVic1Parent: {
    width: 307,
    left: 0,
  },
  vectorIcon: {
    height: "28.3%",
    width: "6.2%",
    top: "14.85%",
    bottom: "56.84%",
    left: "93.8%",
    right: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  groupContainer: {
    left: 1,
    width: 355,
  },
  lineView: {
    top: 40,
    borderColor: Color.colorGray_400,
    borderTopWidth: 1,
    width: 357,
    height: 1,
    left: 0,
    position: "absolute",
    borderStyle: "solid",
  },
  groupParent: {
    width: 356,
    height: 85,
    left: 0,
  },
  groupWrapper: {
    left: 9,
    width: 356,
    height: 85,
  },
  rectangleIcon: {
    top: 191,
    left: 21,
    width: 332,
    height: 125,
    position: "absolute",
  },
  vectorParent: {
    top: 115,
    left: 14,
  },
  materialSymbolsLightpause: {
    top: 503,
    left: 149,
    width: 38,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  baoCaoCongViecChild: {
    height: "0.74%",
    top: "97.29%",
    right: "36.49%",
    bottom: "1.97%",
    left: "61.92%",
  },
  luBoCoChild: {
    backgroundColor: Color.colorPaleturquoise,
    left: "0%",
    borderRadius: Border.br_8xs,
  },
  luBoCo1: {
    height: "83.33%",
    width: "86.44%",
    top: "10.87%",
    left: "6.78%",
    fontSize: FontSize.size_mid,
    color: Color.colorSeagreen,
    textAlign: "left",
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  luBoCo: {
    top: 507,
    left: 132,
    width: 118,
    height: 28,
    position: "absolute",
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    color: Color.oil11,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    top: "0%",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
    maxHeight: "100%",
    position: "absolute",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
    maxHeight: "100%",
    position: "absolute",
  },
  quayLi: {
    top: 41,
    left: 19,
    width: 79,
    height: 19,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.02%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.02%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNng1: {
    top: "70.98%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    textAlign: "center",
  },
  chcNng: {
    top: 758,
    left: 17,
    height: 41,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    left: "0%",
    width: "100%",
    color: Color.colorWhite,
    textAlign: "left",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  component1: {
    top: 754,
    left: 170,
    height: 40,
  },
  videoCallIcon: {
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  vectorIcon1: {
    height: "37.64%",
    width: "47.78%",
    top: "30.89%",
    right: "37.78%",
    bottom: "31.47%",
    left: "14.44%",
    maxHeight: "100%",
    position: "absolute",
  },
  videoCallParent: {
    top: 0,
    left: 0,
  },
  myQuay: {
    top: 317,
    left: 160,
  },
  baoCaoCongViec: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    height: 812,
    overflow: "hidden",
    width: 402,
    borderStyle: "solid",
  },
});

export default MnHnhHinThInNiDun;

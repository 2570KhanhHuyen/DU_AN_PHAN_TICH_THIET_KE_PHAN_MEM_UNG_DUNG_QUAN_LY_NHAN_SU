import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const TtC = () => {
  return (
    <View style={styles.ttC}>
      <View style={[styles.property1group7290, styles.property1groupLayout]}>
        <View style={[styles.property1group7290Child, styles.childShadowBox]} />
        <Text style={styles.ttC1}>Tất cả</Text>
      </View>
      <View style={[styles.property1group7291, styles.property1groupLayout]}>
        <View style={[styles.property1group7291Child, styles.childShadowBox]} />
        <Text style={styles.ttC1}>Tất cả</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 46,
    width: 113,
    left: 20,
    position: "absolute",
  },
  childShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
    borderRadius: Border.br_8xs,
  },
  property1group7290Child: {
    backgroundColor: Color.colorWhite,
  },
  ttC1: {
    top: "26.09%",
    left: "29.2%",
    fontSize: FontSize.size_base,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    position: "absolute",
  },
  property1group7290: {
    top: 20,
  },
  property1group7291Child: {
    backgroundColor: Color.colorLightcyan,
  },
  property1group7291: {
    top: 133,
  },
  ttC: {
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 153,
    height: 199,
    overflow: "hidden",
    borderRadius: Border.br_8xs,
  },
});

export default TtC;

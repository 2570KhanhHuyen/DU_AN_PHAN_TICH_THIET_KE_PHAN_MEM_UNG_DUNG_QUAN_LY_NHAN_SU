import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const ChcChn = () => {
  return (
    <View style={styles.chcChn}>
      <View style={[styles.property1group7290, styles.property1groupLayout]}>
        <View style={styles.xongParentPosition}>
          <View style={[styles.xong, styles.property1groupLayout]}>
            <View style={styles.xongParentPosition}>
              <View style={[styles.groupChild, styles.xongParentPosition]} />
            </View>
            <Text style={[styles.xong1, styles.xong1FlexBox]}>Xong</Text>
          </View>
          <Text style={[styles.chcChn1, styles.xong1FlexBox]}>Chắc chắn</Text>
        </View>
      </View>
      <View style={[styles.property1group7292, styles.property1groupLayout]}>
        <View style={styles.xongParentPosition}>
          <View style={[styles.xong, styles.property1groupLayout]}>
            <View style={styles.xongParentPosition}>
              <View style={[styles.groupChild, styles.xongParentPosition]} />
            </View>
            <Text style={[styles.xong1, styles.xong1FlexBox]}>Xong</Text>
          </View>
          <Text style={[styles.chcChn1, styles.xong1FlexBox]}>Chắc chắn</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 52,
    width: 102,
    position: "absolute",
  },
  xongParentPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  xong1FlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorPaleturquoise,
  },
  xong1: {
    height: "55.58%",
    width: "24.9%",
    top: "22.31%",
    left: "37.55%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    display: "none",
  },
  xong: {
    marginLeft: -51,
    top: 0,
    left: "50%",
    width: 102,
    position: "absolute",
  },
  chcChn1: {
    marginTop: -10,
    top: "50%",
    left: 12,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorBlack,
    width: 79,
    height: 19,
  },
  property1group7290: {
    top: 20,
    left: 20,
    width: 102,
    position: "absolute",
  },
  property1group7292: {
    top: 113,
    left: 20,
    width: 102,
    position: "absolute",
  },
  chcChn: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 142,
    height: 185,
    overflow: "hidden",
  },
});

export default ChcChn;

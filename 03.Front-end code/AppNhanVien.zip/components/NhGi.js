import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const NhGi = () => {
  return (
    <View style={styles.nhGi}>
      <View
        style={[styles.property1component1, styles.property1componentLayout]}
      >
        <View style={styles.property1component1ItemPosition} />
        <View style={styles.property1component1ItemPosition} />
        <Text style={styles.nhGi1}>Đánh giá</Text>
      </View>
      <View
        style={[styles.property1component2, styles.property1componentLayout]}
      >
        <View style={styles.property1component1ItemPosition} />
        <View style={styles.property1component1ItemPosition} />
        <Text style={styles.nhGi1}>Đánh giá</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 33,
    width: 82,
    left: 20,
    position: "absolute",
  },
  property1component1ItemPosition: {
    transform: [
      {
        rotate: "180deg",
      },
    ],
    backgroundColor: Color.colorLightcyan,
    borderBottomLeftRadius: Border.br_3xs,
    left: "100%",
    bottom: "0%",
    right: "-100%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  nhGi1: {
    top: "27.27%",
    left: "24.39%",
    fontSize: FontSize.size_3xs,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorDarkcyan,
    textAlign: "center",
    position: "absolute",
  },
  property1component1: {
    top: 20,
  },
  property1component2: {
    top: 77,
  },
  nhGi: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 122,
    height: 130,
    overflow: "hidden",
  },
});

export default NhGi;

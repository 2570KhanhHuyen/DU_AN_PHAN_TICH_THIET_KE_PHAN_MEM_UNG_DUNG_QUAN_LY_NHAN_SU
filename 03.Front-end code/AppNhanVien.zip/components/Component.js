import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const Component = () => {
  return (
    <View style={styles.component1}>
      <View style={[styles.property1group7252, styles.property1groupLayout]}>
        <Text style={[styles.trangCh, styles.trangPosition]}>TRANG CHỦ</Text>
        <Image
          style={styles.homeIcon}
          contentFit="cover"
          source={require("../assets/home3.png")}
        />
      </View>
      <View style={[styles.property1group7261, styles.property1groupLayout]}>
        <Text style={[styles.trangCh1, styles.trangPosition]}>TRANG CHỦ</Text>
        <Image
          style={styles.homeIcon}
          contentFit="cover"
          source={require("../assets/home1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 40,
    width: 62,
    left: 20,
    position: "absolute",
  },
  trangPosition: {
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    left: "0%",
    top: "78.5%",
    width: "100%",
    height: "21.5%",
    position: "absolute",
  },
  trangCh: {
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    color: Color.colorSandybrown_200,
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    top: "0%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1group7252: {
    top: 108,
  },
  trangCh1: {
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
  },
  property1group7261: {
    top: 20,
  },
  component1: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 102,
    height: 168,
    overflow: "hidden",
  },
});

export default Component;

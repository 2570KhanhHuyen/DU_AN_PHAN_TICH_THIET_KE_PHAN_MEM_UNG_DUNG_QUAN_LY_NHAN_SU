import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const QunMtKhu = () => {
  return (
    <View style={styles.qunMtKhu}>
      <View style={[styles.property1default, styles.property1defaultLayout]}>
        <Text style={styles.qunMtKhu1}>Quên mật khẩu?</Text>
      </View>
      <View style={[styles.property1default1, styles.property1defaultLayout]}>
        <Text style={styles.qunMtKhu1}>Quên mật khẩu?</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1defaultLayout: {
    height: 20,
    width: 138,
    left: 20,
    position: "absolute",
  },
  qunMtKhu1: {
    top: "0%",
    left: "0%",
    fontSize: FontSize.size_base,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    color: Color.colorRoyalblue_100,
    textAlign: "left",
    position: "absolute",
  },
  property1default: {
    top: 20,
  },
  property1default1: {
    top: 67,
  },
  qunMtKhu: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 178,
    height: 107,
    overflow: "hidden",
  },
});

export default QunMtKhu;

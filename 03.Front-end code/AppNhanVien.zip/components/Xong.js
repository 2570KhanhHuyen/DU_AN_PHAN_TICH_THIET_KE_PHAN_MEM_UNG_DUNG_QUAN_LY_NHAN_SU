import * as React from "react";
import { StyleSheet, View } from "react-native";
import Xong from "./Xong1";
import { Border, Color } from "../GlobalStyles";

const Xong1 = () => {
  return (
    <View style={styles.xong}>
      <Xong propTop={20} propLeft={20} />
      <Xong propTop={114} propLeft={20} />
    </View>
  );
};

const styles = StyleSheet.create({
  xong: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 365,
    height: 179,
    overflow: "hidden",
  },
});

export default Xong1;

import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const QuayLi = () => {
  return (
    <View style={styles.quayLi}>
      <View
        style={[styles.property1component6, styles.property1componentLayout]}
      >
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[
            styles.property1component6Child,
            styles.property1component6Layout,
          ]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[
            styles.property1component6Item,
            styles.property1component6Layout,
          ]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View
        style={[styles.property1component7, styles.property1componentLayout]}
      >
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[
            styles.property1component6Child,
            styles.property1component6Layout,
          ]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[
            styles.property1component6Item,
            styles.property1component6Layout,
          ]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 19,
    width: 79,
    left: 20,
    position: "absolute",
  },
  property1component6Layout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  quayLi1: {
    width: "86.08%",
    top: "0%",
    left: "13.92%",
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.robotoRegular,
    color: Color.oil11,
    textAlign: "center",
    position: "absolute",
  },
  property1component6Child: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
  },
  property1component6Item: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
  },
  property1component6: {
    top: 20,
  },
  property1component7: {
    top: 52,
  },
  quayLi: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 119,
    height: 91,
    overflow: "hidden",
  },
});

export default QuayLi;

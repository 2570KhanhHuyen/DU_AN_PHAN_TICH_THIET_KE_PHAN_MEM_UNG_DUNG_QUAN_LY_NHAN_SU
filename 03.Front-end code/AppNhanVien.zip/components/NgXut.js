import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const NgXut = () => {
  return (
    <View style={styles.ngXut}>
      <View
        style={[styles.property1component27, styles.property1componentLayout]}
      >
        <Image
          style={styles.property1component27Child}
          contentFit="cover"
          source={require("../assets/group-54.png")}
        />
        <Text style={styles.ngXut1}>Đăng xuất</Text>
      </View>
      <View
        style={[styles.property1component28, styles.property1componentLayout]}
      >
        <Image
          style={styles.property1component27Child}
          contentFit="cover"
          source={require("../assets/group-54.png")}
        />
        <Text style={styles.ngXut1}>Đăng xuất</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 46,
    width: 325,
    left: 20,
    position: "absolute",
  },
  property1component27Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  ngXut1: {
    height: "54.35%",
    width: "39.68%",
    top: "23.91%",
    left: "30.33%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  property1component27: {
    top: 20,
  },
  property1component28: {
    top: 139,
  },
  ngXut: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 365,
    height: 205,
    overflow: "hidden",
  },
});

export default NgXut;

import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const ThngBo = () => {
  return (
    <View style={styles.thngBo}>
      <View
        style={[styles.property1component2, styles.property1componentLayout]}
      >
        <Image
          style={[styles.property1component2Child, styles.childLayout]}
          contentFit="cover"
          source={require("../assets/vector-141.png")}
        />
        <View style={[styles.vectorParent, styles.groupChildPosition]}>
          <Image
            style={[styles.groupChild, styles.groupChildPosition]}
            contentFit="cover"
            source={require("../assets/vector-131.png")}
          />
          <Text style={styles.thngBo1}>{`Thông báo `}</Text>
        </View>
      </View>
      <View
        style={[styles.property1component3, styles.property1componentLayout]}
      >
        <Image
          style={[styles.property1component2Child, styles.childLayout]}
          contentFit="cover"
          source={require("../assets/vector-141.png")}
        />
        <View style={[styles.vectorParent, styles.groupChildPosition]}>
          <Image
            style={[styles.groupChild, styles.groupChildPosition]}
            contentFit="cover"
            source={require("../assets/vector-131.png")}
          />
          <Text style={styles.thngBo1}>{`Thông báo `}</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 23,
    width: 120,
    left: 20,
    position: "absolute",
  },
  childLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  groupChildPosition: {
    left: "0%",
    position: "absolute",
  },
  property1component2Child: {
    height: "4.35%",
    width: "9.33%",
    top: "52.61%",
    right: "90.5%",
    bottom: "43.04%",
    left: "0.17%",
    position: "absolute",
  },
  groupChild: {
    height: "30%",
    width: "3%",
    top: "37.39%",
    right: "97%",
    bottom: "32.61%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  thngBo1: {
    left: "20%",
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    color: Color.oil11,
    textAlign: "center",
    top: "0%",
    position: "absolute",
  },
  vectorParent: {
    height: "100%",
    width: "100%",
    right: "0%",
    bottom: "0%",
    top: "0%",
  },
  property1component2: {
    top: 20,
  },
  property1component3: {
    top: 104,
  },
  thngBo: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 160,
    height: 147,
    overflow: "hidden",
  },
});

export default ThngBo;

import React, { useMemo } from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Xong = ({ propTop, propLeft }) => {
  const xongStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propTop, propLeft]);

  return (
    <View style={[styles.xong, xongStyle]}>
      <View style={styles.xongInnerPosition}>
        <View style={[styles.groupChild, styles.xongInnerPosition]} />
      </View>
      <Text style={styles.xong1}>Xong</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  xongInnerPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorMediumaquamarine_100,
  },
  xong1: {
    height: "55.56%",
    width: "24.92%",
    top: "22.22%",
    left: "37.54%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    textAlign: "center",
    position: "absolute",
  },
  xong: {
    top: 0,
    left: 0,
    width: 325,
    height: 45,
    position: "absolute",
  },
});

export default Xong;

import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const XemBngCng = () => {
  return (
    <View style={styles.xemBngCng}>
      <View
        style={[styles.property1component15, styles.property1componentLayout]}
      >
        <View style={styles.property1component15Child} />
        <Text style={styles.xemBngCng1}>XEM BẢNG CÔNG</Text>
        <Image
          style={styles.timetableIcon}
          contentFit="cover"
          source={require("../assets/timetable.png")}
        />
      </View>
      <View
        style={[styles.property1component16, styles.property1componentLayout]}
      >
        <View style={styles.property1component15Child} />
        <Text style={styles.xemBngCng1}>XEM BẢNG CÔNG</Text>
        <Image
          style={styles.timetableIcon}
          contentFit="cover"
          source={require("../assets/timetable.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 160,
    width: 342,
    left: 20,
    position: "absolute",
  },
  property1component15Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_xs,
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  xemBngCng1: {
    top: "72.5%",
    left: "34.21%",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.openSansRegular,
    color: Color.oil11,
    textAlign: "center",
    position: "absolute",
  },
  timetableIcon: {
    height: "56.25%",
    width: "26.32%",
    top: "4.38%",
    right: "35.67%",
    bottom: "39.38%",
    left: "38.01%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component15: {
    top: 20,
  },
  property1component16: {
    top: 216,
  },
  xemBngCng: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 382,
    height: 396,
    overflow: "hidden",
  },
});

export default XemBngCng;

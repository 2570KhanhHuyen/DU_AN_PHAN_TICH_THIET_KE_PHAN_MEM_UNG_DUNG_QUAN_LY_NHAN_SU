import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const ChmCngVo = () => {
  return (
    <View style={styles.chmCngVo}>
      <View
        style={[styles.property1component9, styles.property1componentLayout]}
      >
        <View style={[styles.rectangleParent, styles.chmCngVo1Position]}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.chmCngVo1, styles.chmCngVo1Position]}>
            Chấm công vào
          </Text>
        </View>
        <Image
          style={styles.groupIcon}
          contentFit="cover"
          source={require("../assets/group.png")}
        />
      </View>
      <View
        style={[styles.property1component10, styles.property1componentLayout]}
      >
        <View style={[styles.rectangleParent, styles.chmCngVo1Position]}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.chmCngVo1, styles.chmCngVo1Position]}>
            Chấm công vào
          </Text>
        </View>
        <Image
          style={styles.groupIcon}
          contentFit="cover"
          source={require("../assets/group.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 36,
    width: 211,
    left: 20,
    position: "absolute",
  },
  chmCngVo1Position: {
    left: "0%",
    position: "absolute",
  },
  groupChildPosition: {
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
  },
  groupChild: {
    width: "96.21%",
    left: "3.79%",
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorMediumaquamarine_100,
    position: "absolute",
  },
  chmCngVo1: {
    height: "69.44%",
    width: "78.91%",
    top: "25%",
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.openSansBold,
    color: Color.colorWhite,
    textAlign: "center",
  },
  rectangleParent: {
    width: "100%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
  },
  groupIcon: {
    height: "51.94%",
    width: "10.9%",
    top: "19.44%",
    right: "16.59%",
    bottom: "28.61%",
    left: "72.51%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component9: {
    top: 20,
  },
  property1component10: {
    top: 82,
  },
  chmCngVo: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 251,
    height: 138,
    overflow: "hidden",
  },
});

export default ChmCngVo;

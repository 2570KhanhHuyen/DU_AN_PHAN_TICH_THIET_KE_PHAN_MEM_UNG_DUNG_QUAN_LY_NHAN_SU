import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const CHn = () => {
  return (
    <View style={styles.cHn}>
      <View style={[styles.property1group7292, styles.property1groupLayout]}>
        <View style={[styles.property1group7292Child, styles.childShadowBox]} />
        <View style={styles.cHnParent}>
          <Text style={styles.cHn1}>Cũ hơn</Text>
          <Image
            style={styles.groupChild}
            contentFit="cover"
            source={require("../assets/ellipse-561.png")}
          />
        </View>
      </View>
      <View style={[styles.property1group7293, styles.property1groupLayout]}>
        <View style={[styles.property1group7293Child, styles.childShadowBox]} />
        <View style={styles.cHnParent}>
          <Text style={styles.cHn1}>Cũ hơn</Text>
          <Image
            style={styles.groupChild}
            contentFit="cover"
            source={require("../assets/ellipse-561.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 46,
    width: 113,
    left: 20,
    position: "absolute",
  },
  childShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    bottom: "0%",
    right: "0%",
    width: "100%",
    height: "100%",
    left: "0%",
    top: "0%",
    position: "absolute",
    borderRadius: Border.br_8xs,
  },
  property1group7292Child: {
    backgroundColor: Color.colorWhite,
  },
  cHn1: {
    left: "18.06%",
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorGray_100,
    textAlign: "left",
    top: "0%",
    position: "absolute",
  },
  groupChild: {
    height: "34.55%",
    width: "11.53%",
    top: "25.91%",
    right: "88.47%",
    bottom: "39.55%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  cHnParent: {
    height: "47.83%",
    width: "58.32%",
    top: "21.74%",
    right: "24.87%",
    bottom: "30.43%",
    left: "16.81%",
    position: "absolute",
  },
  property1group7292: {
    top: 20,
  },
  property1group7293Child: {
    backgroundColor: Color.colorLightcyan,
  },
  property1group7293: {
    top: 130,
  },
  cHn: {
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 153,
    height: 196,
    overflow: "hidden",
    borderRadius: Border.br_8xs,
  },
});

export default CHn;

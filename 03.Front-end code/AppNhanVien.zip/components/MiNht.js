import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const MiNht = () => {
  return (
    <View style={styles.miNht}>
      <View style={[styles.property1group7291, styles.property1groupLayout]}>
        <View style={[styles.property1group7291Child, styles.childShadowBox]} />
        <View style={styles.miNhtParent}>
          <Text style={styles.miNht1}>Mới nhất</Text>
          <Image
            style={styles.groupChild}
            contentFit="cover"
            source={require("../assets/ellipse-552.png")}
          />
        </View>
      </View>
      <View style={[styles.property1group7292, styles.property1groupLayout]}>
        <View style={[styles.property1group7292Child, styles.childShadowBox]} />
        <View style={styles.miNhtParent}>
          <Text style={styles.miNht1}>Mới nhất</Text>
          <Image
            style={styles.groupChild}
            contentFit="cover"
            source={require("../assets/ellipse-552.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 46,
    width: 113,
    left: 20,
    position: "absolute",
  },
  childShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    bottom: "0%",
    right: "0%",
    width: "100%",
    height: "100%",
    left: "0%",
    top: "0%",
    position: "absolute",
    borderRadius: Border.br_8xs,
  },
  property1group7291Child: {
    backgroundColor: Color.colorWhite,
  },
  miNht1: {
    left: "21.73%",
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorGray_100,
    textAlign: "left",
    top: "0%",
    position: "absolute",
  },
  groupChild: {
    height: "34.55%",
    width: "8.88%",
    top: "25.91%",
    right: "91.12%",
    bottom: "39.55%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  miNhtParent: {
    height: "47.83%",
    width: "75.75%",
    top: "26.09%",
    right: "11.86%",
    bottom: "26.09%",
    left: "12.39%",
    position: "absolute",
  },
  property1group7291: {
    top: 20,
  },
  property1group7292Child: {
    backgroundColor: Color.colorLightcyan,
  },
  property1group7292: {
    top: 133,
  },
  miNht: {
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 153,
    height: 199,
    overflow: "hidden",
    borderRadius: Border.br_8xs,
  },
});

export default MiNht;

import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border, Color } from "../GlobalStyles";

const XaThngBo = () => {
  return (
    <View style={styles.xaThngBo}>
      <Image
        style={[styles.property1trashIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/property-1trash.png")}
      />
      <Image
        style={[styles.property1closeIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/property-1close.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: 28,
    width: 43,
    left: 20,
    position: "absolute",
  },
  property1trashIcon: {
    top: 20,
  },
  property1closeIcon: {
    top: 97,
  },
  xaThngBo: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 83,
    height: 145,
    overflow: "hidden",
  },
});

export default XaThngBo;

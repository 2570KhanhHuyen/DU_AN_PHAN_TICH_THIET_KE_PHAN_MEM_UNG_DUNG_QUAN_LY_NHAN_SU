import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const NhGiNhnVinKhc1 = () => {
  return (
    <View style={styles.nhGiNhnVinKhc}>
      <View
        style={[styles.property1component21, styles.property1componentLayout]}
      >
        <View style={styles.property1component21Child} />
        <Text style={styles.nhGiNhn}>ĐÁNH GIÁ NHÂN VIÊN KHÁC</Text>
        <Image
          style={styles.inscriptionIcon}
          contentFit="cover"
          source={require("../assets/inscription.png")}
        />
      </View>
      <View
        style={[styles.property1component22, styles.property1componentLayout]}
      >
        <View style={styles.property1component21Child} />
        <Text style={styles.nhGiNhn}>ĐÁNH GIÁ NHÂN VIÊN KHÁC</Text>
        <Image
          style={styles.inscriptionIcon}
          contentFit="cover"
          source={require("../assets/inscription.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 160,
    width: 342,
    left: 20,
    position: "absolute",
  },
  property1component21Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_xs,
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  nhGiNhn: {
    top: "78.5%",
    left: "22.81%",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.openSansRegular,
    color: Color.oil11,
    textAlign: "center",
    position: "absolute",
  },
  inscriptionIcon: {
    height: "56.25%",
    width: "26.32%",
    top: "18.13%",
    right: "35.47%",
    bottom: "25.63%",
    left: "38.22%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component21: {
    top: 20,
  },
  property1component22: {
    top: 222,
  },
  nhGiNhnVinKhc: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 382,
    height: 402,
    overflow: "hidden",
  },
});

export default NhGiNhnVinKhc1;

import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const ChmCngRa = () => {
  return (
    <View style={styles.chmCngRa}>
      <View
        style={[styles.property1component12, styles.property1componentLayout]}
      >
        <View style={[styles.rectangleParent, styles.groupChildPosition]}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.chmCngRa1, styles.chmCngRa1Position]}>
            Chấm công ra
          </Text>
        </View>
        <Image
          style={[styles.groupIcon, styles.chmCngRa1Position]}
          contentFit="cover"
          source={require("../assets/group1.png")}
        />
      </View>
      <View
        style={[styles.property1component13, styles.property1componentLayout]}
      >
        <View style={[styles.rectangleParent, styles.groupChildPosition]}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.chmCngRa1, styles.chmCngRa1Position]}>
            Chấm công ra
          </Text>
        </View>
        <Image
          style={[styles.groupIcon, styles.chmCngRa1Position]}
          contentFit="cover"
          source={require("../assets/group1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 36,
    width: 214,
    left: 20,
    position: "absolute",
  },
  groupChildPosition: {
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
  },
  chmCngRa1Position: {
    top: "22.22%",
    position: "absolute",
  },
  groupChild: {
    width: "93.94%",
    left: "6.06%",
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorMediumaquamarine_100,
  },
  chmCngRa1: {
    height: "69.44%",
    width: "77.05%",
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.openSansBold,
    color: Color.colorWhite,
    textAlign: "center",
    left: "0%",
  },
  rectangleParent: {
    width: "100%",
    left: "0%",
  },
  groupIcon: {
    height: "52.78%",
    width: "10.87%",
    right: "16.84%",
    bottom: "25%",
    left: "72.29%",
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  property1component12: {
    top: 20,
  },
  property1component13: {
    top: 94,
  },
  chmCngRa: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 254,
    height: 150,
    overflow: "hidden",
  },
});

export default ChmCngRa;

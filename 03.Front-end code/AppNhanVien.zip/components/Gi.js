import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Gi = () => {
  return (
    <View style={styles.gi}>
      <View
        style={[styles.property1component36, styles.property1componentLayout]}
      >
        <View style={styles.property1component36Child} />
        <Text style={styles.gi1}>Gửi</Text>
      </View>
      <View
        style={[styles.property1component37, styles.property1componentLayout]}
      >
        <View style={styles.property1component36Child} />
        <Text style={styles.gi1}>Gửi</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 38,
    width: 83,
    left: 20,
    position: "absolute",
  },
  property1component36Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: Color.colorPaleturquoise,
    position: "absolute",
    borderRadius: Border.br_8xs,
  },
  gi1: {
    top: "13.16%",
    left: "28.92%",
    fontSize: FontSize.size_xl,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorSeagreen,
    textAlign: "left",
    position: "absolute",
  },
  property1component36: {
    top: 20,
  },
  property1component37: {
    top: 76,
  },
  gi: {
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 123,
    height: 134,
    overflow: "hidden",
    borderRadius: Border.br_8xs,
  },
});

export default Gi;

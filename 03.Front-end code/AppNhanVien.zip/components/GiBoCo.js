import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const GiBoCo = () => {
  return (
    <View style={styles.giBoCo}>
      <View style={[styles.property1group7262, styles.property1groupLayout]}>
        <View style={styles.property1group7262Child} />
        <Text style={styles.giBoCo1}>Gửi báo cáo</Text>
      </View>
      <View style={[styles.property1group7263, styles.property1groupLayout]}>
        <View style={styles.property1group7262Child} />
        <Text style={styles.giBoCo1}>Gửi báo cáo</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 26,
    width: 122,
    left: 20,
    position: "absolute",
  },
  property1group7262Child: {
    height: "92.31%",
    width: "96.72%",
    top: "3.85%",
    right: "3.28%",
    bottom: "3.85%",
    left: "0%",
    backgroundColor: Color.colorPaleturquoise,
    position: "absolute",
    borderRadius: Border.br_8xs,
  },
  giBoCo1: {
    height: "100%",
    width: "91.8%",
    top: "0%",
    left: "8.2%",
    fontSize: FontSize.size_mid,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    color: Color.colorSeagreen,
    textAlign: "left",
    position: "absolute",
  },
  property1group7262: {
    top: 20,
  },
  property1group7263: {
    top: 67,
  },
  giBoCo: {
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 162,
    height: 113,
    overflow: "hidden",
    borderRadius: Border.br_8xs,
  },
});

export default GiBoCo;

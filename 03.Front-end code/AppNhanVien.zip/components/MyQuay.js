import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border, Color } from "../GlobalStyles";

const MyQuay = () => {
  return (
    <View style={styles.myQuay}>
      <View style={[styles.property1default, styles.property1defaultLayout]}>
        <View style={[styles.videoCallParent, styles.property1defaultLayout]}>
          <Image
            style={[styles.videoCallIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/video-call.png")}
          />
          <Image
            style={[styles.vectorIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/vector5.png")}
          />
        </View>
      </View>
      <View style={[styles.property1default1, styles.property1defaultLayout]}>
        <View style={[styles.videoCallParent, styles.property1defaultLayout]}>
          <Image
            style={[styles.videoCallParent, styles.property1defaultLayout]}
            contentFit="cover"
            source={require("../assets/video-call.png")}
          />
          <Image
            style={[styles.vectorIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/vector5.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1defaultLayout: {
    height: 104,
    width: 90,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  videoCallIcon: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  vectorIcon: {
    height: "37.64%",
    width: "47.78%",
    top: "30.89%",
    right: "37.78%",
    bottom: "31.47%",
    left: "14.44%",
  },
  videoCallParent: {
    top: 0,
    left: 0,
    width: 90,
    position: "absolute",
  },
  property1default: {
    top: 20,
    left: 20,
    width: 90,
    position: "absolute",
  },
  property1default1: {
    top: 161,
    left: 20,
    width: 90,
    position: "absolute",
  },
  myQuay: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 130,
    height: 285,
    overflow: "hidden",
  },
});

export default MyQuay;

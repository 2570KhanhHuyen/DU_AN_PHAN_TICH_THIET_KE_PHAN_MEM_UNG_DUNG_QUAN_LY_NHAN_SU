import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const ThLi = () => {
  return (
    <View style={styles.thLi}>
      <View style={[styles.property1frame10, styles.property1frameFlexBox]}>
        <Text style={styles.thLi1}>Thử lại</Text>
      </View>
      <View style={[styles.property1frame12, styles.property1frameFlexBox]}>
        <Text style={styles.thLi1}>Thử lại</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1frameFlexBox: {
    paddingVertical: Padding.p_xl,
    paddingHorizontal: Padding.p_lg,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 55,
    width: 100,
    backgroundColor: Color.colorPaleturquoise,
    borderRadius: Border.br_3xs,
    left: 20,
    position: "absolute",
    overflow: "hidden",
  },
  thLi1: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "center",
  },
  property1frame10: {
    top: 20,
  },
  property1frame12: {
    top: 110,
  },
  thLi: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 140,
    height: 185,
    overflow: "hidden",
  },
});

export default ThLi;

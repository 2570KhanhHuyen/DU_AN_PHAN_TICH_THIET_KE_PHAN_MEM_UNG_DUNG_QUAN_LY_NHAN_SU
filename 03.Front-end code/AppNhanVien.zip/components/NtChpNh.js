import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border, Color } from "../GlobalStyles";

const NtChpNh = () => {
  return (
    <View style={styles.ntChpNh}>
      <Image
        style={[styles.property1defaultIcon, styles.property1defaultIconLayout]}
        contentFit="cover"
        source={require("../assets/property-1default.png")}
      />
      <Image
        style={[
          styles.property1defaultIcon1,
          styles.property1defaultIconLayout,
        ]}
        contentFit="cover"
        source={require("../assets/property-1default.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  property1defaultIconLayout: {
    height: 100,
    width: 141,
    left: 20,
    position: "absolute",
  },
  property1defaultIcon: {
    top: 20,
  },
  property1defaultIcon1: {
    top: 169,
  },
  ntChpNh: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 181,
    height: 289,
    overflow: "hidden",
  },
});

export default NtChpNh;

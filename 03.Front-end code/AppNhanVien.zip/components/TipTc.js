import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const TipTc = () => {
  return (
    <View style={styles.tipTc}>
      <View
        style={[styles.property1component30, styles.property1componentLayout]}
      >
        <View style={styles.groupChildPosition}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
        </View>
        <Text style={styles.tipTc1}>Tiếp tục</Text>
      </View>
      <View
        style={[styles.property1component31, styles.property1componentLayout]}
      >
        <View style={styles.groupChildPosition}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
        </View>
        <Text style={styles.tipTc1}>Tiếp tục</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 45,
    width: 325,
    left: 20,
    position: "absolute",
  },
  groupChildPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorMediumaquamarine_100,
  },
  tipTc1: {
    height: "55.56%",
    width: "39.69%",
    top: "22.22%",
    left: "34.15%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  property1component30: {
    top: 20,
  },
  property1component31: {
    top: 100,
  },
  tipTc: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 365,
    height: 165,
    overflow: "hidden",
  },
});

export default TipTc;

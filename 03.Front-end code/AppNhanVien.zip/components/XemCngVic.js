import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const XemCngVic = () => {
  return (
    <View style={styles.xemCngVic}>
      <View
        style={[styles.property1component18, styles.property1componentLayout]}
      >
        <View style={styles.property1component18Child} />
        <Text style={styles.xemCngVic1}>XEM CÔNG VIỆC</Text>
        <Image
          style={styles.iconWorkload}
          contentFit="cover"
          source={require("../assets/-icon-workload.png")}
        />
      </View>
      <View
        style={[styles.property1component19, styles.property1componentLayout]}
      >
        <View style={styles.property1component18Child} />
        <Text style={styles.xemCngVic1}>XEM CÔNG VIỆC</Text>
        <Image
          style={styles.iconWorkload}
          contentFit="cover"
          source={require("../assets/-icon-workload.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1componentLayout: {
    height: 160,
    width: 342,
    left: 20,
    position: "absolute",
  },
  property1component18Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_xs,
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  xemCngVic1: {
    top: "77.5%",
    left: "34.8%",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.openSansRegular,
    color: Color.oil11,
    textAlign: "center",
    position: "absolute",
  },
  iconWorkload: {
    height: "39.81%",
    width: "18.63%",
    top: "23.13%",
    right: "40.44%",
    bottom: "37.06%",
    left: "40.94%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component18: {
    top: 20,
  },
  property1component19: {
    top: 240,
  },
  xemCngVic: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 382,
    height: 420,
    overflow: "hidden",
  },
});

export default XemCngVic;

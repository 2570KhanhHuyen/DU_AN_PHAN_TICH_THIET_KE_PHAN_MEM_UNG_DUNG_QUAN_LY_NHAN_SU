import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const ChcNng1 = () => {
  return (
    <View style={styles.chcNng}>
      <View style={styles.property1component40}>
        <Image
          style={[
            styles.property1component40Child,
            styles.property1component40Layout,
          ]}
          contentFit="cover"
          source={require("../assets/ellipse-405.png")}
        />
        <Image
          style={[styles.property1component40Item, styles.ellipseIconPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-426.png")}
        />
        <Image
          style={[styles.property1component40Inner, styles.ellipseIconLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-411.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.ellipseIconLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-431.png")}
        />
        <Text style={[styles.chcNng1, styles.chcPosition]}>CHỨC NĂNG</Text>
      </View>
      <View style={styles.property1component41}>
        <Text style={[styles.chcNng2, styles.chcPosition]}>CHỨC NĂNG</Text>
        <Image
          style={[
            styles.property1component41Child,
            styles.property1component41Position1,
          ]}
          contentFit="cover"
          source={require("../assets/ellipse-551.png")}
        />
        <Image
          style={[
            styles.property1component41Item,
            styles.property1component41Position,
          ]}
          contentFit="cover"
          source={require("../assets/ellipse-551.png")}
        />
        <Image
          style={[
            styles.property1component41Inner,
            styles.property1component41Layout,
          ]}
          contentFit="cover"
          source={require("../assets/ellipse-551.png")}
        />
        <Image
          style={[
            styles.property1component41Child1,
            styles.property1component41Layout,
          ]}
          contentFit="cover"
          source={require("../assets/ellipse-551.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1component40Layout: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    position: "absolute",
    overflow: "hidden",
  },
  ellipseIconPosition: {
    bottom: "50.97%",
    top: "28.06%",
  },
  ellipseIconLayout: {
    left: "50%",
    right: "35.87%",
    maxHeight: "100%",
    maxWidth: "100%",
    width: "14.13%",
    height: "20.97%",
    position: "absolute",
    overflow: "hidden",
  },
  chcPosition: {
    left: "0%",
    position: "absolute",
  },
  property1component41Position1: {
    left: "49.15%",
    right: "35.59%",
  },
  property1component41Position: {
    left: "28.81%",
    right: "55.93%",
  },
  property1component41Layout: {
    bottom: "78.05%",
    width: "15.25%",
    height: "21.95%",
    maxHeight: "100%",
    maxWidth: "100%",
    top: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component40Child: {
    bottom: "79.03%",
    top: "0%",
  },
  property1component40Item: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component40Inner: {
    bottom: "79.03%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNng1: {
    top: "70.97%",
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    textAlign: "center",
  },
  property1component40: {
    top: 20,
    left: 26,
    width: 46,
    height: 31,
    position: "absolute",
  },
  chcNng2: {
    height: "34.15%",
    width: "100%",
    top: "65.85%",
    fontSize: FontSize.size_3xs,
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    color: Color.colorSandybrown_200,
    textAlign: "left",
  },
  property1component41Child: {
    bottom: "51.22%",
    top: "26.83%",
    width: "15.25%",
    height: "21.95%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component41Item: {
    bottom: "51.22%",
    top: "26.83%",
    width: "15.25%",
    height: "21.95%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  property1component41Inner: {
    left: "49.15%",
    right: "35.59%",
  },
  property1component41Child1: {
    left: "28.81%",
    right: "55.93%",
  },
  property1component41: {
    top: 77,
    left: 18,
    width: 59,
    height: 41,
    position: "absolute",
  },
  chcNng: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 99,
    height: 127,
    overflow: "hidden",
  },
});

export default ChcNng1;

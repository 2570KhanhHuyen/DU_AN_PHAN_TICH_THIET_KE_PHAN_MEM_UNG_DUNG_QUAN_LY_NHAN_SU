import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border, Color } from "../GlobalStyles";

const NhpVoNtThngBo = () => {
  return (
    <View style={styles.nhpVoNtThngBo}>
      <Image
        style={[styles.property1group1363, styles.property1groupLayout]}
        contentFit="cover"
        source={require("../assets/property-1group-1363.png")}
      />
      <Image
        style={[styles.property1group1405, styles.property1groupLayout]}
        contentFit="cover"
        source={require("../assets/property-1group-1363.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 23,
    width: 25,
    left: 20,
    position: "absolute",
  },
  property1group1363: {
    top: 20,
  },
  property1group1405: {
    top: 75,
  },
  nhpVoNtThngBo: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 65,
    height: 118,
    overflow: "hidden",
  },
});

export default NhpVoNtThngBo;

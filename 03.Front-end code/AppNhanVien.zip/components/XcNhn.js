import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const XcNhn = () => {
  return (
    <View style={styles.xcNhn}>
      <View style={[styles.property1group1366, styles.property1groupLayout]}>
        <View style={styles.property1group1366Child} />
        <Text style={styles.xcNhn1}>Xác nhận</Text>
      </View>
      <View style={[styles.property1group7261, styles.property1groupLayout]}>
        <View style={styles.property1group1366Child} />
        <Text style={styles.xcNhn1}>Xác nhận</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1groupLayout: {
    height: 36,
    width: 233,
    left: 20,
    position: "absolute",
  },
  property1group1366Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorMediumaquamarine_100,
    position: "absolute",
  },
  xcNhn1: {
    height: "69.44%",
    width: "82.02%",
    top: "13.89%",
    left: "6.87%",
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.openSansBold,
    color: Color.colorWhite,
    textAlign: "center",
    position: "absolute",
  },
  property1group1366: {
    top: 20,
  },
  property1group7261: {
    top: 86,
  },
  xcNhn: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 273,
    height: 142,
    overflow: "hidden",
  },
});

export default XcNhn;

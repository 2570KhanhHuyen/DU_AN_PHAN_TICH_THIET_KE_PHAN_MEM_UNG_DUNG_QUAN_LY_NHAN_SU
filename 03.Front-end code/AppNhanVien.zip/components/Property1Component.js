import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1Component = ({
  iconPerson,
  propTop,
  propLeft,
  propFontWeight,
  propFontFamily,
  propColor,
}) => {
  const property1Component3Style = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propTop, propLeft]);

  const tIStyle = useMemo(() => {
    return {
      ...getStyleValue("fontWeight", propFontWeight),
      ...getStyleValue("fontFamily", propFontFamily),
      ...getStyleValue("color", propColor),
    };
  }, [propFontWeight, propFontFamily, propColor]);

  return (
    <View style={[styles.property1component3, property1Component3Style]}>
      <Image style={styles.iconPerson} contentFit="cover" source={iconPerson} />
      <Text style={[styles.ti, tIStyle]}>TÔI</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  iconPerson: {
    height: "58.37%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "41.63%",
    left: "0%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  ti: {
    height: "25.58%",
    width: "59.38%",
    top: "74.42%",
    left: "18.75%",
    fontSize: FontSize.size_5xs,
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    color: Color.colorSandybrown_100,
    textAlign: "center",
    position: "absolute",
  },
  property1component3: {
    top: 86,
    left: 20,
    width: 32,
    height: 43,
    position: "absolute",
  },
});

export default Property1Component;

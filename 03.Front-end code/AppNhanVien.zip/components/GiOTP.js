import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const GiOTP = () => {
  return (
    <View style={styles.giOtp}>
      <View style={[styles.property1frame7310, styles.property1frameLayout]}>
        <View style={[styles.tipTc, styles.property1frameLayout]}>
          <View style={styles.tipTcInnerPosition}>
            <View style={[styles.groupChild, styles.tipTcInnerPosition]} />
          </View>
          <Text style={styles.tipTc1}>Gửi OTP</Text>
        </View>
      </View>
      <View style={[styles.property1frame7311, styles.property1frameLayout]}>
        <View style={[styles.tipTc, styles.property1frameLayout]}>
          <View style={styles.tipTcInnerPosition}>
            <View style={[styles.groupChild, styles.tipTcInnerPosition]} />
          </View>
          <Text style={styles.tipTc1}>Gửi OTP</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1frameLayout: {
    height: 45,
    width: 334,
    position: "absolute",
  },
  tipTcInnerPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorMediumaquamarine_100,
  },
  tipTc1: {
    height: "55.56%",
    width: "39.7%",
    top: "22.22%",
    left: "34.16%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  tipTc: {
    top: 0,
    left: 0,
  },
  property1frame7310: {
    top: 20,
    left: 20,
    width: 334,
  },
  property1frame7311: {
    top: 143,
    left: 20,
    width: 334,
  },
  giOtp: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 374,
    height: 208,
    overflow: "hidden",
  },
});

export default GiOTP;

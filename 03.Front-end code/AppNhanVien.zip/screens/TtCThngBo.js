import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Component from "../components/Property1Component";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const TtCThngBo = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.ttCThngBo}>
      <Pressable
        style={[styles.ttCThngBoChild, styles.thngChildLayout]}
        onPress={() => navigation.navigate("DanhSchBoCoCngVic")}
      />
      <Image
        style={styles.ttCThngBoItem}
        contentFit="cover"
        source={require("../assets/vector-161.png")}
      />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Image
          style={[styles.groupItem, styles.homeIconLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-51.png")}
        />
      </View>
      <Text style={[styles.bnCMt, styles.bngFlexBox]}>
        Bạn có một công việc mới !
      </Text>
      <Text style={[styles.bngCngThng, styles.bngFlexBox]}>
        Bảng công tháng 4 vừa được cập nhật
      </Text>
      <Text style={[styles.miNht, styles.nhtTypo]}>Mới nhất</Text>
      <Text style={[styles.cHn, styles.cHnTypo]}>Cũ hơn</Text>
      <Text style={[styles.miNht1, styles.nhtTypo]}>Mới nhất</Text>
      <Text style={[styles.text, styles.textTypo]}>6/05/2024</Text>
      <Text style={[styles.text1, styles.textTypo]}>1/05/2024</Text>
      <Pressable
        style={[styles.ttCThngBoInner, styles.thngChildLayout]}
        onPress={() => navigation.navigate("DanhSchBngCngCNhnTh")}
      />
      <Text style={[styles.bngCngThng1, styles.bngFlexBox]}>
        Bảng công tháng 3 vừa được cập nhật
      </Text>
      <Text style={[styles.text2, styles.textTypo]}>1/04/2024</Text>
      <Pressable
        style={[styles.rectanglePressable, styles.thngChildLayout]}
        onPress={() => navigation.navigate("DanhSchBngCngCNhnTh")}
      />
      <Text style={[styles.cHn1, styles.cHnTypo]}>Cũ hơn</Text>
      <Text
        style={[styles.bnCMt1, styles.bngFlexBox]}
      >{`Bạn có một công việc mới `}</Text>
      <Text style={[styles.text3, styles.textTypo]}>6/04/2024</Text>
      <Pressable
        style={[styles.ttCThngBoChild1, styles.thngChildLayout]}
        onPress={() => navigation.navigate("DanhSchBoCoCngVic")}
      />
      <View style={styles.chcNng}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-401.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcNngItemPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-421.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-411.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-431.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1FlexBox]}>CHỨC NĂNG</Text>
      </View>
      <View style={styles.component1}>
        <Text style={[styles.trangCh, styles.chcNng1Clr]}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.homeIconLayout]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={759}
        propLeft={334}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <View style={styles.thngBo}>
        <Image
          style={[styles.thngBoChild, styles.homeIconLayout]}
          contentFit="cover"
          source={require("../assets/vector-141.png")}
        />
        <View style={styles.vectorParent}>
          <Image
            style={styles.groupInner}
            contentFit="cover"
            source={require("../assets/vector-131.png")}
          />
          <Text
            style={[styles.thngBo1, styles.chcNng1FlexBox]}
          >{`Thông báo `}</Text>
        </View>
      </View>
      <View style={[styles.ttC, styles.ttCLayout]}>
        <View style={styles.childShadowBox} />
        <Text style={styles.ttC1}>Tất cả</Text>
      </View>
      <View style={[styles.miNht2, styles.ttCLayout]}>
        <View style={styles.childShadowBox} />
        <View style={[styles.miNhtParent, styles.parentLayout]}>
          <Text style={[styles.miNht3, styles.cHn3Typo]}>Mới nhất</Text>
          <Image
            style={[styles.groupChild1, styles.groupChildPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-55.png")}
          />
        </View>
      </View>
      <View style={[styles.cHn2, styles.ttCLayout]}>
        <View style={styles.childShadowBox} />
        <View style={[styles.cHnParent, styles.parentLayout]}>
          <Text style={[styles.cHn3, styles.cHn3Typo]}>Cũ hơn</Text>
          <Image
            style={[styles.groupChild2, styles.groupChildPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-56.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  thngChildLayout: {
    height: 98,
    width: 339,
    borderWidth: 0.2,
    borderColor: Color.colorSilver_200,
    borderRadius: Border.br_8xs,
    left: 32,
    position: "absolute",
    borderStyle: "solid",
  },
  groupChildLayout: {
    height: 66,
    width: 402,
    left: 0,
    position: "absolute",
  },
  homeIconLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  bngFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  nhtTypo: {
    color: Color.colorGoldenrod,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    left: 44,
    textAlign: "left",
    position: "absolute",
  },
  cHnTypo: {
    color: Color.colorMediumpurple,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  textTypo: {
    color: Color.colorMidnightblue,
    fontFamily: FontFamily.openSansLight,
    fontWeight: "300",
    fontSize: FontSize.size_sm,
    left: 44,
    textAlign: "left",
    position: "absolute",
  },
  chcLayout: {
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngItemPosition: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNngInnerLayout: {
    left: "50%",
    right: "35.87%",
    width: "14.13%",
    height: "20.97%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1FlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  chcNng1Clr: {
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    left: "0%",
  },
  ttCLayout: {
    height: 46,
    width: 113,
    top: 113,
    position: "absolute",
  },
  parentLayout: {
    height: "47.83%",
    position: "absolute",
  },
  cHn3Typo: {
    color: Color.colorGray_100,
    fontFamily: FontFamily.openSansRegular,
    top: "0%",
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  groupChildPosition: {
    bottom: "39.55%",
    top: "25.91%",
    height: "34.55%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  ttCThngBoChild: {
    top: 200,
    backgroundColor: Color.colorWhite,
    width: 339,
    borderWidth: 0.2,
    borderColor: Color.colorSilver_200,
    borderRadius: Border.br_8xs,
  },
  ttCThngBoItem: {
    top: 82,
    width: 398,
    maxHeight: "100%",
    left: 0,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    backgroundColor: Color.colorGray_200,
  },
  groupItem: {
    height: "9.04%",
    width: "1.59%",
    top: "66.87%",
    right: "39.24%",
    bottom: "24.1%",
    left: "59.16%",
    opacity: 0,
  },
  rectangleParent: {
    top: 746,
  },
  bnCMt: {
    top: 217,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.openSansBold,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontWeight: "700",
    left: 42,
  },
  bngCngThng: {
    top: 335,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.openSansBold,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontWeight: "700",
    left: 42,
  },
  miNht: {
    top: 261,
  },
  cHn: {
    top: 619,
    color: Color.colorMediumpurple,
    left: 42,
  },
  miNht1: {
    top: 378,
  },
  text: {
    top: 237,
  },
  text1: {
    top: 356,
  },
  ttCThngBoInner: {
    top: 318,
  },
  bngCngThng1: {
    top: 572,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.openSansBold,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontWeight: "700",
    left: 42,
  },
  text2: {
    top: 593,
  },
  rectanglePressable: {
    top: 555,
  },
  cHn1: {
    top: 499,
    left: 44,
    color: Color.colorMediumpurple,
  },
  bnCMt1: {
    top: 452,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.openSansBold,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontWeight: "700",
    left: 42,
  },
  text3: {
    top: 473,
  },
  ttCThngBoChild1: {
    top: 435,
  },
  chcNngChild: {
    bottom: "79.03%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.03%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNng1: {
    top: "70.97%",
    fontSize: FontSize.size_5xs,
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    left: "0%",
  },
  chcNng: {
    top: 765,
    left: 31,
    width: 46,
    height: 31,
    position: "absolute",
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
    width: "100%",
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
  },
  component1: {
    top: 754,
    left: 170,
    width: 62,
    height: 40,
    position: "absolute",
  },
  thngBoChild: {
    height: "4.35%",
    width: "9.33%",
    top: "52.61%",
    right: "90.5%",
    bottom: "43.04%",
    left: "0.17%",
  },
  groupInner: {
    height: "30%",
    width: "3%",
    top: "37.39%",
    right: "97%",
    bottom: "32.61%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  thngBo1: {
    left: "20%",
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.robotoBold,
    color: Color.oil11,
    top: "0%",
    fontWeight: "700",
    textAlign: "center",
  },
  vectorParent: {
    bottom: "0%",
    right: "0%",
    height: "100%",
    left: "0%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  thngBo: {
    top: 35,
    left: 33,
    width: 120,
    height: 23,
    position: "absolute",
  },
  childShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    bottom: "0%",
    right: "0%",
    height: "100%",
    left: "0%",
    top: "0%",
    borderRadius: Border.br_8xs,
    position: "absolute",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
  ttC1: {
    left: "29.2%",
    color: Color.colorBlack,
    top: "26.09%",
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  ttC: {
    left: 32,
    width: 113,
    top: 113,
  },
  miNht3: {
    left: "21.73%",
  },
  groupChild1: {
    width: "8.88%",
    right: "91.12%",
  },
  miNhtParent: {
    width: "75.75%",
    right: "11.86%",
    bottom: "26.09%",
    left: "12.39%",
    top: "26.09%",
  },
  miNht2: {
    left: 148,
  },
  cHn3: {
    left: "18.06%",
  },
  groupChild2: {
    width: "11.53%",
    right: "88.47%",
  },
  cHnParent: {
    width: "58.32%",
    top: "21.74%",
    right: "24.87%",
    bottom: "30.43%",
    left: "16.81%",
  },
  cHn2: {
    left: 264,
  },
  ttCThngBo: {
    borderRadius: Border.br_6xl,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    borderStyle: "solid",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default TtCThngBo;

import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import Property1Component from "../components/Property1Component";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const DanhSchBoCoCngVic = () => {
  return (
    <View style={[styles.danhSchBoCoCngVic, styles.cngLayout]}>
      <View style={[styles.xemCngVic, styles.xemCngVicPosition]}>
        <Image
          style={[styles.xemCngVicChild, styles.childLayout]}
          contentFit="cover"
          source={require("../assets/vector-22.png")}
        />
        <View style={[styles.rectangleParent, styles.xemCngVicPosition]}>
          <View style={[styles.componentChild, styles.giBoCo1Layout]} />
          <Image
            style={[styles.componentItem, styles.componentItemLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-51.png")}
          />
        </View>
        <Image
          style={[styles.xemCngVicItem, styles.quayLiPosition]}
          contentFit="cover"
          source={require("../assets/vector-22.png")}
        />
        <Image
          style={[styles.xemCngVicInner, styles.componentItemLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-51.png")}
        />
        <View style={[styles.frameView, styles.frameViewLayout]}>
          <View style={[styles.quayLiParent, styles.frameViewLayout]}>
            <View style={[styles.quayLi, styles.quayLiPosition]}>
              <Text style={styles.quayLi1}>Quay lại</Text>
              <Image
                style={[styles.quayLiChild, styles.iconLayout]}
                contentFit="cover"
                source={require("../assets/vector-13.png")}
              />
              <Image
                style={[styles.quayLiItem, styles.iconLayout]}
                contentFit="cover"
                source={require("../assets/vector-14.png")}
              />
            </View>
            <Image
              style={styles.nhpVoNtThngBo}
              contentFit="cover"
              source={require("../assets/nhp-vo-nt-thng-bo1.png")}
            />
          </View>
        </View>
        <View style={styles.chcNng}>
          <Image
            style={[styles.chcNngChild, styles.chcLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-401.png")}
          />
          <Image
            style={[styles.chcNngItem, styles.chcNngItemPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-421.png")}
          />
          <Image
            style={[styles.chcNngInner, styles.chcNngInnerLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-411.png")}
          />
          <Image
            style={[styles.ellipseIcon, styles.chcNngInnerLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-431.png")}
          />
          <Text style={styles.chcNng1}>CHỨC NĂNG</Text>
        </View>
        <View style={styles.component1}>
          <Text style={styles.trangCh}>TRANG CHỦ</Text>
          <Image
            style={[styles.homeIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/home.png")}
          />
        </View>
        <Property1Component
          iconPerson={require("../assets/-icon-person.png")}
          propTop={761}
          propLeft={328}
          propFontWeight="unset"
          propFontFamily="Roboto-Regular"
          propColor="#fff"
        />
      </View>
      <View style={[styles.danhSchBoCoCngVicInner, styles.groupWrapperLayout]}>
        <View style={[styles.groupWrapper, styles.groupWrapperLayout]}>
          <View style={[styles.groupWrapper, styles.groupWrapperLayout]}>
            <View style={[styles.groupContainer, styles.groupLayout1]}>
              <View style={[styles.groupContainer, styles.groupLayout1]}>
                <View style={[styles.groupContainer, styles.groupLayout1]}>
                  <View style={[styles.groupContainer, styles.groupLayout1]}>
                    <View
                      style={[styles.groupChild, styles.groupChildShadowBox]}
                    />
                  </View>
                  <View style={[styles.groupFrame, styles.groupParentPosition]}>
                    <View
                      style={[styles.groupParent2, styles.groupParentPosition]}
                    >
                      <View
                        style={[
                          styles.groupParent3,
                          styles.groupParentPosition,
                        ]}
                      >
                        <View
                          style={[
                            styles.cngVic1Parent,
                            styles.groupParentPosition,
                          ]}
                        >
                          <Text
                            style={[styles.cngVic1Container, styles.text2Typo]}
                          >
                            <Text style={styles.cngVic1}>Công việc 1</Text>
                            <Text style={styles.text}>{` `}</Text>
                          </Text>
                          <View style={styles.groupItem} />
                          <Text style={styles.text1}>02/08/2024</Text>
                          <Text
                            style={[styles.gpMtKhch, styles.gpMtKhchPosition]}
                          >
                            Gặp mặt khách hàng tại 12 Mỹ An 12
                          </Text>
                          <Text style={[styles.text2, styles.text2Typo]}>
                            10:00
                          </Text>
                        </View>
                        <Image
                          style={[styles.vectorIcon, styles.vectorIconLayout]}
                          contentFit="cover"
                          source={require("../assets/vector.png")}
                        />
                      </View>
                      <View style={styles.groupInner} />
                    </View>
                  </View>
                </View>
                <View style={[styles.giBoCo, styles.giBoCoLayout]}>
                  <View style={styles.giBoCoChild} />
                  <Text style={[styles.giBoCo1, styles.text2Typo]}>
                    Gửi báo cáo
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.groupParent4, styles.groupChildLayout]}>
              <View
                style={[styles.rectangleContainer, styles.groupChildLayout]}
              >
                <View style={[styles.rectangleView, styles.groupChildLayout]} />
              </View>
              <View style={[styles.groupFrame, styles.groupParentPosition]}>
                <View style={[styles.groupParent2, styles.groupParentPosition]}>
                  <View
                    style={[styles.groupParent6, styles.groupParentPosition]}
                  >
                    <View
                      style={[styles.cngVic1Parent, styles.groupParentPosition]}
                    >
                      <Text style={[styles.cngVic1Container, styles.text2Typo]}>
                        <Text style={styles.cngVic1}>Công việc 2</Text>
                        <Text style={styles.text}>{` `}</Text>
                      </Text>
                      <View style={styles.groupItem} />
                      <Text style={styles.text1}>02/08/2024</Text>
                      <Text style={[styles.gpMtKhch, styles.gpMtKhchPosition]}>
                        Tạo báo cáo công việc tuần vừa qua
                      </Text>
                      <Text style={[styles.text2, styles.text2Typo]}>
                        13:00
                      </Text>
                    </View>
                    <Image
                      style={[styles.vectorIcon1, styles.vectorIconLayout]}
                      contentFit="cover"
                      source={require("../assets/vector1.png")}
                    />
                  </View>
                  <View style={styles.groupInner} />
                </View>
              </View>
              <View style={[styles.giBoCo2, styles.giBoCoLayout]}>
                <View style={styles.giBoCoChild} />
                <Text style={[styles.giBoCo1, styles.text2Typo]}>
                  Gửi báo cáo
                </Text>
              </View>
            </View>
            <View style={[styles.groupParent7, styles.groupChildLayout]}>
              <View
                style={[styles.rectangleContainer, styles.groupChildLayout]}
              >
                <Image
                  style={[styles.groupChild2, styles.childLayout]}
                  contentFit="cover"
                  source={require("../assets/vector-22.png")}
                />
                <View
                  style={[styles.rectangleContainer, styles.groupChildLayout]}
                >
                  <View style={[styles.groupChild3, styles.groupChildLayout]} />
                </View>
                <View style={[styles.groupFrame, styles.groupParentPosition]}>
                  <View
                    style={[styles.groupParent2, styles.groupParentPosition]}
                  >
                    <View
                      style={[styles.groupParent9, styles.groupParentPosition]}
                    >
                      <View
                        style={[
                          styles.cngVic3Parent,
                          styles.groupParentPosition,
                        ]}
                      >
                        <Text
                          style={[styles.cngVic1Container, styles.text2Typo]}
                        >
                          <Text style={styles.cngVic1}>Công việc 3</Text>
                          <Text style={styles.text}>{` `}</Text>
                        </Text>
                        <View style={styles.groupItem} />
                        <Text style={styles.text1}>02/08/2024</Text>
                        <Text
                          style={[styles.giNiDung, styles.gpMtKhchPosition]}
                        >
                          Gửi nội dung cho đợt quảng cáo thứ 2
                        </Text>
                        <Text style={[styles.text2, styles.text2Typo]}>
                          16:00
                        </Text>
                      </View>
                      <Image
                        style={[styles.vectorIcon2, styles.iconLayout]}
                        contentFit="cover"
                        source={require("../assets/vector2.png")}
                      />
                    </View>
                    <View style={styles.groupInner} />
                  </View>
                </View>
              </View>
              <View style={[styles.giBoCo4, styles.giBoCoLayout]}>
                <View style={styles.giBoCoChild} />
                <Text style={[styles.giBoCo1, styles.text2Typo]}>
                  Gửi báo cáo
                </Text>
              </View>
            </View>
            <View style={[styles.groupWrapper3, styles.groupChildLayout]}>
              <View
                style={[styles.rectangleContainer, styles.groupChildLayout]}
              >
                <View
                  style={[styles.rectangleContainer, styles.groupChildLayout]}
                >
                  <Image
                    style={[styles.groupChild2, styles.childLayout]}
                    contentFit="cover"
                    source={require("../assets/vector-22.png")}
                  />
                  <View
                    style={[styles.rectangleContainer, styles.groupChildLayout]}
                  >
                    <View
                      style={[styles.groupChild7, styles.groupChildLayout]}
                    />
                  </View>
                  <View style={[styles.groupFrame, styles.groupParentPosition]}>
                    <View
                      style={[styles.groupParent2, styles.groupParentPosition]}
                    >
                      <View
                        style={[
                          styles.groupParent9,
                          styles.groupParentPosition,
                        ]}
                      >
                        <View
                          style={[
                            styles.cngVic3Parent,
                            styles.groupParentPosition,
                          ]}
                        >
                          <Text
                            style={[styles.cngVic1Container, styles.text2Typo]}
                          >
                            <Text style={styles.cngVic1}>Công việc 4</Text>
                            <Text style={styles.text}>{` `}</Text>
                          </Text>
                          <View style={styles.groupItem} />
                          <Text style={styles.text1}>02/08/2024</Text>
                          <Text
                            style={[styles.giNiDung, styles.gpMtKhchPosition]}
                          >
                            Họp tổng kết tại D202
                          </Text>
                          <Text style={[styles.text2, styles.text2Typo]}>
                            17:00
                          </Text>
                        </View>
                        <Image
                          style={styles.vectorIcon3}
                          contentFit="cover"
                          source={require("../assets/vector3.png")}
                        />
                      </View>
                      <View style={styles.groupInner} />
                    </View>
                  </View>
                </View>
                <View style={[styles.giBoCo4, styles.giBoCoLayout]}>
                  <View style={styles.giBoCoChild} />
                  <Text style={[styles.giBoCo1, styles.text2Typo]}>
                    Gửi báo cáo
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.groupWrapper3, styles.groupChildLayout]}>
              <View
                style={[styles.rectangleContainer, styles.groupChildLayout]}
              >
                <View
                  style={[styles.rectangleContainer, styles.groupChildLayout]}
                >
                  <Image
                    style={[styles.groupChild2, styles.childLayout]}
                    contentFit="cover"
                    source={require("../assets/vector-22.png")}
                  />
                  <View
                    style={[styles.rectangleContainer, styles.groupChildLayout]}
                  >
                    <View
                      style={[styles.groupChild11, styles.groupChildLayout]}
                    />
                  </View>
                  <View style={[styles.groupFrame, styles.groupParentPosition]}>
                    <View
                      style={[styles.groupParent2, styles.groupParentPosition]}
                    >
                      <View
                        style={[
                          styles.groupParent9,
                          styles.groupParentPosition,
                        ]}
                      >
                        <View
                          style={[
                            styles.cngVic3Parent,
                            styles.groupParentPosition,
                          ]}
                        >
                          <Text
                            style={[styles.cngVic1Container, styles.text2Typo]}
                          >
                            <Text style={styles.cngVic1}>Công việc 4</Text>
                            <Text style={styles.text}>{` `}</Text>
                          </Text>
                          <View style={styles.groupItem} />
                          <Text style={styles.text1}>02/08/2024</Text>
                          <Text
                            style={[styles.giNiDung, styles.gpMtKhchPosition]}
                          >
                            Họp tổng kết tại D202
                          </Text>
                          <Text style={[styles.text2, styles.text2Typo]}>
                            17:00
                          </Text>
                        </View>
                        <Image
                          style={styles.vectorIcon3}
                          contentFit="cover"
                          source={require("../assets/vector3.png")}
                        />
                      </View>
                      <View style={styles.groupInner} />
                    </View>
                  </View>
                </View>
                <View style={[styles.giBoCo4, styles.giBoCoLayout]}>
                  <View style={styles.giBoCoChild} />
                  <Text style={[styles.giBoCo1, styles.text2Typo]}>
                    Gửi báo cáo
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.giBoCoWrapper, styles.giBoCoLayout]}>
              <View style={[styles.giBoCo10, styles.giBoCoLayout]}>
                <View style={styles.giBoCoChild} />
                <Text style={[styles.giBoCo1, styles.text2Typo]}>
                  Gửi báo cáo
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cngLayout: {
    height: 812,
    borderRadius: Border.br_6xl,
  },
  xemCngVicPosition: {
    width: 402,
    left: 0,
    position: "absolute",
  },
  childLayout: {
    width: 355,
    maxHeight: "100%",
  },
  giBoCo1Layout: {
    height: "100%",
    top: "0%",
  },
  componentItemLayout: {
    opacity: 0,
    width: "1.59%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  quayLiPosition: {
    left: 20,
    position: "absolute",
  },
  frameViewLayout: {
    height: 77,
    width: 402,
    top: 0,
    position: "absolute",
  },
  iconLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcLayout: {
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngItemPosition: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNngInnerLayout: {
    left: "50%",
    right: "35.87%",
    width: "14.13%",
    height: "20.97%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  groupWrapperLayout: {
    width: 375,
    position: "absolute",
  },
  groupLayout1: {
    height: 156,
    width: 374,
    position: "absolute",
  },
  groupChildShadowBox: {
    backgroundColor: Color.colorWhite,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  groupParentPosition: {
    height: 93,
    top: 0,
    position: "absolute",
  },
  text2Typo: {
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  gpMtKhchPosition: {
    left: 41,
    top: 70,
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    height: 23,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  vectorIconLayout: {
    height: "15.7%",
    maxWidth: "100%",
    right: "0%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  giBoCoLayout: {
    height: 26,
    width: 122,
    position: "absolute",
  },
  groupChildLayout: {
    height: 145,
    width: 374,
    position: "absolute",
  },
  xemCngVicChild: {
    top: 138,
    left: 19,
    position: "absolute",
  },
  componentChild: {
    bottom: "0%",
    backgroundColor: Color.colorGray_200,
    left: "0%",
    right: "0%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  componentItem: {
    height: "9.04%",
    top: "66.87%",
    right: "39.24%",
    bottom: "24.1%",
    left: "59.16%",
  },
  rectangleParent: {
    top: 746,
    height: 66,
  },
  xemCngVicItem: {
    top: 301,
    width: 355,
    maxHeight: "100%",
  },
  xemCngVicInner: {
    height: "0.74%",
    top: "97.17%",
    right: "42.71%",
    bottom: "2.09%",
    left: "55.7%",
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    color: Color.oil11,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_base,
    top: "0%",
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
  },
  quayLi: {
    top: 32,
    width: 79,
    height: 19,
  },
  nhpVoNtThngBo: {
    top: 30,
    left: 357,
    width: 25,
    height: 23,
    position: "absolute",
  },
  quayLiParent: {
    left: 0,
    overflow: "hidden",
  },
  frameView: {
    left: -1,
  },
  chcNngChild: {
    bottom: "79.03%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.03%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNng1: {
    top: "70.97%",
    fontSize: FontSize.size_5xs,
    color: Color.colorWhite,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    left: "0%",
    position: "absolute",
  },
  chcNng: {
    top: 765,
    left: 29,
    width: 46,
    height: 31,
    position: "absolute",
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    left: "0%",
    position: "absolute",
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
  },
  component1: {
    top: 754,
    left: 165,
    width: 62,
    height: 40,
    position: "absolute",
  },
  xemCngVic: {
    backgroundColor: Color.colorWhitesmoke,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    borderStyle: "solid",
    top: 0,
    height: 812,
    borderRadius: Border.br_6xl,
  },
  groupChild: {
    height: 156,
    width: 374,
    position: "absolute",
  },
  groupContainer: {
    left: 0,
    top: 0,
  },
  cngVic1: {
    color: Color.colorDarkorchid,
  },
  text: {
    color: Color.colorBlack,
  },
  cngVic1Container: {
    left: 8,
    width: 87,
    top: 11,
    fontWeight: "600",
    height: 23,
    fontSize: FontSize.size_base,
  },
  groupItem: {
    width: 100,
    height: 29,
    opacity: 0.33,
    left: 0,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  text1: {
    left: 134,
    width: 85,
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.openSansRegular,
    top: 12,
    textAlign: "left",
    height: 23,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  gpMtKhch: {
    width: 273,
  },
  text2: {
    left: 265,
    width: 42,
    color: Color.colorBlack,
    top: 11,
    fontWeight: "600",
    height: 23,
    fontSize: FontSize.size_base,
  },
  cngVic1Parent: {
    width: 314,
    left: 0,
  },
  vectorIcon: {
    width: "6.23%",
    top: "13.98%",
    bottom: "70.32%",
    left: "93.77%",
  },
  groupParent3: {
    width: 353,
    left: 1,
  },
  groupInner: {
    top: 35,
    borderColor: Color.colorGray_400,
    borderTopWidth: 1,
    width: 357,
    height: 1,
    borderStyle: "solid",
    left: 0,
    position: "absolute",
  },
  groupParent2: {
    width: 356,
    height: 93,
    left: 0,
  },
  groupFrame: {
    left: 9,
    width: 356,
    height: 93,
  },
  giBoCoChild: {
    height: "92.31%",
    width: "96.72%",
    top: "3.85%",
    right: "3.28%",
    bottom: "3.85%",
    backgroundColor: Color.colorPaleturquoise,
    borderRadius: Border.br_8xs,
    left: "0%",
    position: "absolute",
  },
  giBoCo1: {
    width: "91.8%",
    left: "8.2%",
    fontSize: FontSize.size_mid,
    color: Color.colorSeagreen,
    top: "0%",
    height: "100%",
  },
  giBoCo: {
    top: 127,
    left: 121,
  },
  rectangleView: {
    backgroundColor: Color.colorWhite,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  rectangleContainer: {
    left: 0,
    top: 0,
  },
  vectorIcon1: {
    width: "6.27%",
    top: "14.73%",
    bottom: "69.57%",
    left: "93.73%",
  },
  groupParent6: {
    width: 351,
    left: 1,
  },
  giBoCo2: {
    top: 112,
    left: 127,
  },
  groupParent4: {
    top: 172,
    left: 0,
  },
  groupChild2: {
    top: 51,
    left: 5,
    position: "absolute",
  },
  groupChild3: {
    backgroundColor: Color.colorWhite,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  giNiDung: {
    width: 306,
  },
  cngVic3Parent: {
    width: 347,
    left: 0,
  },
  vectorIcon2: {
    height: "17.2%",
    width: "6.29%",
    top: "13.44%",
    bottom: "69.35%",
    left: "93.71%",
    right: "0%",
  },
  groupParent9: {
    width: 350,
    left: 1,
  },
  giBoCo4: {
    top: 110,
    left: 123,
  },
  groupParent7: {
    top: 336,
    left: 1,
  },
  groupChild7: {
    backgroundColor: Color.colorWhite,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  vectorIcon3: {
    left: 328,
    width: 22,
    height: 17,
    top: 12,
    position: "absolute",
  },
  groupWrapper3: {
    top: 493,
    left: 1,
  },
  groupChild11: {
    backgroundColor: Color.colorWhite,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  giBoCo10: {
    left: 0,
    top: 0,
  },
  giBoCoWrapper: {
    top: 762,
    left: 124,
  },
  groupWrapper: {
    height: 788,
    left: 0,
    top: 0,
  },
  danhSchBoCoCngVicInner: {
    top: 64,
    left: 13,
    height: 667,
  },
  danhSchBoCoCngVic: {
    flex: 1,
    overflow: "hidden",
    width: "100%",
  },
});

export default DanhSchBoCoCngVic;

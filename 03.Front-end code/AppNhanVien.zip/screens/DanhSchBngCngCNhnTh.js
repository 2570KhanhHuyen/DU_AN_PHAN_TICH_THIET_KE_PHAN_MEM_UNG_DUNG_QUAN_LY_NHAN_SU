import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Component from "../components/Property1Component";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const DanhSchBngCngCNhnTh = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.danhSachBangCong}>
      <View style={styles.danhSachBangCongChild} />
      <Text style={styles.bngCngC}>Bảng công cá nhân</Text>
      <Image
        style={[styles.danhSachBangCongItem, styles.danhPosition]}
        contentFit="cover"
        source={require("../assets/vector-151.png")}
      />
      <Image
        style={[styles.danhSachBangCongInner, styles.danhPosition]}
        contentFit="cover"
        source={require("../assets/vector-162.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.quayLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-51.png")}
      />
      <Pressable
        style={[styles.rectanglePressable, styles.danhChildShadowBox]}
        onPress={() => navigation.navigate("XemBngCngCNhn")}
      />
      <Text style={[styles.bngCngThng, styles.bngTypo2]}>
        Bảng công tháng 4/2024
      </Text>
      <Text style={[styles.ngyTo1052024, styles.ngyLayout]}>{`Ngày tạo
1/05/2024`}</Text>
      <Pressable
        style={[styles.danhSachBangCongChild1, styles.danhChildShadowBox]}
        onPress={() => navigation.navigate("XemBngCngCNhn")}
      />
      <Text style={[styles.bngCngThng1, styles.bngTypo2]}>
        Bảng công tháng 3/2024
      </Text>
      <Text style={[styles.ngyTo1042024, styles.ngyLayout]}>{`Ngày tạo
1/04/2024`}</Text>
      <Pressable
        style={[styles.danhSachBangCongChild2, styles.danhChildShadowBox]}
        onPress={() => navigation.navigate("XemBngCngCNhn")}
      />
      <Text style={[styles.bngCngThng2, styles.bngTypo1]}>
        Bảng công tháng 2/2024
      </Text>
      <Text style={[styles.ngyTo1032024, styles.ngyLayout]}>{`Ngày tạo
1/03/2024`}</Text>
      <Pressable
        style={[styles.danhSachBangCongChild3, styles.danhChildShadowBox]}
        onPress={() => navigation.navigate("XemBngCngCNhn")}
      />
      <Text style={[styles.bngCngThng3, styles.bngTypo]}>
        Bảng công tháng 1/2024
      </Text>
      <Text style={[styles.ngyTo1022024, styles.ngyLayout]}>{`Ngày tạo
1/02/2024`}</Text>
      <Pressable
        style={[styles.danhSachBangCongChild4, styles.danhChildShadowBox]}
        onPress={() => navigation.navigate("XemBngCngCNhn")}
      />
      <Text style={[styles.bngCngThng4, styles.bngTypo]}>
        Bảng công tháng 12/2023
      </Text>
      <Text style={[styles.ngyTo1012023, styles.ngyLayout]}>{`Ngày tạo
1/01/2023`}</Text>
      <Pressable
        style={[styles.danhSachBangCongChild5, styles.danhChildShadowBox]}
        onPress={() => navigation.navigate("XemBngCngCNhn")}
      />
      <Text style={[styles.bngCngThng5, styles.bngTypo1]}>
        Bảng công tháng 11/2023
      </Text>
      <Text style={[styles.ngyTo1122023, styles.ngyLayout]}>{`Ngày tạo
1/12/2023`}</Text>
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[styles.quayLiChild, styles.quayLayout]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.quayLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-40.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-42.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-41.png")}
        />
        <Image
          style={[styles.chcNngChild1, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-43.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Clr]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={[styles.trangCh, styles.chcNng1Clr]}>TRANG CHỦ</Text>
        <Image
          style={styles.homeIcon}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={760}
        propLeft={338}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  danhPosition: {
    maxHeight: "100%",
    top: 108,
    position: "absolute",
  },
  quayLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  danhChildShadowBox: {
    height: 84,
    width: 343,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 26,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  bngTypo2: {
    height: 34,
    width: 226,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  ngyLayout: {
    height: 40,
    width: 76,
    color: Color.colorDimgray_300,
    fontFamily: FontFamily.openSansRegular,
    lineHeight: 15,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  bngTypo1: {
    left: 36,
    height: 34,
    width: 226,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  bngTypo: {
    left: 35,
    height: 34,
    width: 226,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  chcNngLayout: {
    width: 62,
    height: 40,
    position: "absolute",
  },
  chcLayout1: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcPosition: {
    bottom: "51%",
    top: "28.25%",
  },
  chcLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Clr: {
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  danhSachBangCongChild: {
    top: 746,
    left: 0,
    backgroundColor: Color.colorGray_200,
    width: 399,
    height: 66,
    position: "absolute",
  },
  bngCngC: {
    top: 83,
    left: 30,
    color: Color.colorMediumaquamarine_200,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  danhSachBangCongItem: {
    left: 31,
    width: 340,
  },
  danhSachBangCongInner: {
    left: -12,
    width: 398,
  },
  ellipseIcon: {
    height: "0.74%",
    width: "1.59%",
    top: "97.29%",
    right: "35.5%",
    bottom: "1.97%",
    left: "62.91%",
    opacity: 0,
  },
  rectanglePressable: {
    top: 130,
  },
  bngCngThng: {
    top: 149,
    left: 33,
  },
  ngyTo1052024: {
    top: 146,
    left: 300,
    height: 40,
    width: 76,
    color: Color.colorDimgray_300,
    fontFamily: FontFamily.openSansRegular,
    lineHeight: 15,
  },
  danhSachBangCongChild1: {
    top: 230,
  },
  bngCngThng1: {
    top: 252,
    left: 38,
  },
  ngyTo1042024: {
    top: 249,
    left: 302,
  },
  danhSachBangCongChild2: {
    top: 333,
  },
  bngCngThng2: {
    top: 356,
  },
  ngyTo1032024: {
    top: 353,
    left: 300,
    height: 40,
    width: 76,
    color: Color.colorDimgray_300,
    fontFamily: FontFamily.openSansRegular,
    lineHeight: 15,
  },
  danhSachBangCongChild3: {
    top: 434,
  },
  bngCngThng3: {
    top: 460,
  },
  ngyTo1022024: {
    top: 453,
    left: 299,
  },
  danhSachBangCongChild4: {
    top: 535,
  },
  bngCngThng4: {
    top: 563,
  },
  ngyTo1012023: {
    top: 554,
    left: 300,
    height: 40,
    width: 76,
    color: Color.colorDimgray_300,
    fontFamily: FontFamily.openSansRegular,
    lineHeight: 15,
  },
  danhSachBangCongChild5: {
    top: 642,
  },
  bngCngThng5: {
    top: 659,
  },
  ngyTo1122023: {
    top: 656,
    left: 300,
    height: 40,
    width: 76,
    color: Color.colorDimgray_300,
    fontFamily: FontFamily.openSansRegular,
    lineHeight: 15,
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    color: Color.oil11,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    top: "0%",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
  },
  quayLi: {
    top: 37,
    left: 28,
    width: 79,
    height: 19,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngChild1: {
    bottom: "51%",
    top: "28.25%",
  },
  chcNng1: {
    top: "71%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    textAlign: "center",
  },
  chcNng: {
    top: 758,
    left: 21,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    left: "0%",
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    textAlign: "left",
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  component1: {
    top: 755,
    left: 167,
  },
  danhSachBangCong: {
    borderRadius: Border.br_6xl,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default DanhSchBngCngCNhnTh;

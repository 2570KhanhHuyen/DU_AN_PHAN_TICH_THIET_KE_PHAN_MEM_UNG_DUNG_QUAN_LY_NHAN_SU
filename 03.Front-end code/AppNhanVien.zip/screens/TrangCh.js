import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import Property1Component from "../components/Property1Component";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const TrangCh = () => {
  return (
    <View style={styles.trangChu}>
      <Image
        style={styles.trangChuChild}
        contentFit="cover"
        source={require("../assets/rectangle-42.png")}
      />
      <Image
        style={[styles.trangChuItem, styles.groupIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-22.png")}
      />
      <View style={styles.trangChuInner}>
        <View style={styles.trangChWrapper}>
          <Text style={styles.trangCh}>Trang chủ</Text>
        </View>
      </View>
      <Text style={styles.text}>{` `}</Text>
      <View style={[styles.rectangleParent, styles.image14x1Layout]}>
        <View style={[styles.groupChild, styles.groupChildPosition]} />
        <Text style={styles.xinCho}>Xin chào,</Text>
        <Text style={styles.choMngBn}>{`Chào mừng bạn đến với hệ thống 
quản lý nhân sự của chúng tôi!`}</Text>
        <Image
          style={[styles.image14x1, styles.image14x1Layout]}
          contentFit="cover"
          source={require("../assets/image-14x-1.png")}
        />
      </View>
      <Image
        style={styles.calendarIcon}
        contentFit="cover"
        source={require("../assets/calendar.png")}
      />
      <View style={[styles.chmCngVo, styles.chmLayout]}>
        <View style={[styles.rectangleGroup, styles.trangCh1Position]}>
          <View style={[styles.groupItem, styles.groupItemPosition]} />
          <Text style={[styles.chmCngVo1, styles.chmTypo]}>Chấm công vào</Text>
        </View>
        <Image
          style={[styles.groupIcon, styles.groupIconLayout]}
          contentFit="cover"
          source={require("../assets/group.png")}
        />
      </View>
      <View style={[styles.chmCngVo, styles.chmLayout]}>
        <View style={[styles.rectangleGroup, styles.trangCh1Position]}>
          <View style={[styles.groupItem, styles.groupItemPosition]} />
          <Text style={[styles.chmCngVo1, styles.chmTypo]}>Chấm công vào</Text>
        </View>
        <Image
          style={[styles.groupIcon, styles.groupIconLayout]}
          contentFit="cover"
          source={require("../assets/group.png")}
        />
      </View>
      <View style={[styles.chmCngRa, styles.chmLayout]}>
        <View style={[styles.rectangleGroup, styles.trangCh1Position]}>
          <View style={[styles.rectangleView, styles.groupItemPosition]} />
          <Text style={[styles.chmCngRa1, styles.chmCngRa1Position]}>
            Chấm công ra
          </Text>
        </View>
        <Image
          style={[styles.groupIcon2, styles.chmCngRa1Position]}
          contentFit="cover"
          source={require("../assets/group1.png")}
        />
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-402.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcNngItemPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-422.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-412.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-432.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Typo]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={[styles.trangCh1, styles.chcNng1Typo]}>TRANG CHỦ</Text>
        <Image
          style={styles.homeIcon}
          contentFit="cover"
          source={require("../assets/home1.png")}
        />
      </View>
      <View style={styles.groupParent}>
        <View style={[styles.rectangleParent1, styles.groupChild1Layout]}>
          <View style={[styles.groupChild1, styles.groupChild1Layout]} />
          <Text style={[styles.text1, styles.textClr]}>04/05/2024</Text>
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/vector-7.png")}
          />
          <Image
            style={styles.groupChild2}
            contentFit="cover"
            source={require("../assets/group-7254.png")}
          />
        </View>
        <View style={[styles.groupWrapper, styles.groupLayout]}>
          <View style={[styles.groupContainer, styles.groupLayout]}>
            <View style={[styles.groupContainer, styles.groupLayout]}>
              <View style={[styles.groupContainer, styles.groupLayout]}>
                <View style={[styles.groupContainer, styles.groupLayout]}>
                  <View style={[styles.groupChild3, styles.groupChildLayout]} />
                  <View style={[styles.groupChild4, styles.groupChildLayout]} />
                  <View style={[styles.groupChild5, styles.groupChildLayout]} />
                </View>
              </View>
            </View>
            <Text style={[styles.text2, styles.textClr]}>07</Text>
            <Text style={[styles.text3, styles.amTypo]}>00</Text>
            <Text style={[styles.am, styles.amTypo]}>AM</Text>
          </View>
        </View>
        <View style={[styles.groupWrapper2, styles.groupWrapperLayout]}>
          <View style={[styles.groupWrapper3, styles.groupWrapperLayout]}>
            <Image
              style={[styles.groupWrapper3, styles.groupWrapperLayout]}
              contentFit="cover"
              source={require("../assets/group-7255.png")}
            />
          </View>
        </View>
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={759}
        propLeft={326}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <Image
        style={styles.nhpVoNtThngBo}
        contentFit="cover"
        source={require("../assets/nhp-vo-nt-thng-bo.png")}
      />
      <Image
        style={[styles.iconUserCircle, styles.groupIconLayout]}
        contentFit="cover"
        source={require("../assets/-icon-user-circle.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupIconLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  image14x1Layout: {
    height: 137,
    position: "absolute",
  },
  groupChildPosition: {
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    left: 0,
    position: "absolute",
  },
  chmLayout: {
    height: 36,
    position: "absolute",
  },
  trangCh1Position: {
    left: "0%",
    width: "100%",
  },
  groupItemPosition: {
    backgroundColor: Color.colorMediumaquamarine_100,
    borderRadius: Border.br_mini,
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
  },
  chmTypo: {
    color: Color.colorWhite,
    height: "69.44%",
    left: "0%",
    fontFamily: FontFamily.openSansBold,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    fontWeight: "700",
  },
  chmCngRa1Position: {
    top: "22.22%",
    position: "absolute",
  },
  chcNngLayout: {
    width: 62,
    position: "absolute",
  },
  chcLayout: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngItemPosition: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNngInnerLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Typo: {
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    position: "absolute",
  },
  groupChild1Layout: {
    height: 353,
    width: 345,
  },
  textClr: {
    color: Color.colorBlack,
    textAlign: "center",
    position: "absolute",
  },
  groupLayout: {
    height: 68,
    width: 210,
    position: "absolute",
  },
  groupChildLayout: {
    width: 65,
    backgroundColor: Color.colorLavenderblush,
    borderRadius: Border.br_8xs,
    height: 68,
    top: 0,
    position: "absolute",
  },
  amTypo: {
    height: 24,
    top: 15,
    color: Color.colorBlack,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "center",
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  groupWrapperLayout: {
    height: 50,
    width: 73,
    position: "absolute",
  },
  trangChuChild: {
    top: 745,
    width: 399,
    height: 66,
    left: 0,
    position: "absolute",
  },
  trangChuItem: {
    height: "0.99%",
    width: "1.99%",
    top: "97.13%",
    right: "35.27%",
    bottom: "1.88%",
    left: "62.74%",
    opacity: 0,
    maxHeight: "100%",
    position: "absolute",
  },
  trangCh: {
    fontFamily: FontFamily.robotoBold,
    textAlign: "center",
    color: Color.oil11,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
  },
  trangChWrapper: {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  trangChuInner: {
    top: 29,
    left: 78,
    padding: 10,
    position: "absolute",
  },
  text: {
    top: 164,
    color: "#534c4c",
    textAlign: "left",
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    left: 43,
    position: "absolute",
  },
  groupChild: {
    top: 19,
    height: 100,
    width: 346,
  },
  xinCho: {
    top: 38,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.openSansBold,
    left: 14,
    textAlign: "left",
    color: Color.oil11,
    fontWeight: "700",
    position: "absolute",
  },
  choMngBn: {
    top: 72,
    fontSize: FontSize.size_xs,
    left: 14,
    textAlign: "left",
    fontFamily: FontFamily.openSansRegular,
    color: Color.oil11,
    position: "absolute",
  },
  image14x1: {
    left: 204,
    width: 124,
    top: 0,
  },
  rectangleParent: {
    top: 90,
    left: 29,
    width: 346,
  },
  calendarIcon: {
    top: 541,
    left: 117,
    width: 44,
    height: 28,
    position: "absolute",
  },
  groupItem: {
    width: "96.21%",
    left: "3.79%",
  },
  chmCngVo1: {
    width: "78.91%",
    top: "25%",
    position: "absolute",
  },
  rectangleGroup: {
    bottom: "0%",
    right: "0%",
    height: "100%",
    left: "0%",
    top: "0%",
    position: "absolute",
  },
  groupIcon: {
    height: "51.94%",
    width: "10.9%",
    top: "19.44%",
    right: "16.59%",
    bottom: "28.61%",
    left: "72.51%",
    maxHeight: "100%",
    position: "absolute",
  },
  chmCngVo: {
    top: 623,
    width: 211,
    left: 96,
  },
  rectangleView: {
    width: "93.94%",
    left: "6.06%",
  },
  chmCngRa1: {
    width: "77.05%",
    color: Color.colorWhite,
    height: "69.44%",
    left: "0%",
    fontFamily: FontFamily.openSansBold,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    fontWeight: "700",
  },
  groupIcon2: {
    height: "52.78%",
    width: "10.87%",
    right: "16.84%",
    bottom: "25%",
    left: "72.29%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  chmCngRa: {
    top: 678,
    left: 94,
    width: 214,
  },
  chcNngChild: {
    bottom: "79.02%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.02%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNng1: {
    top: "70.98%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    textAlign: "center",
  },
  chcNng: {
    top: 760,
    height: 41,
    left: 18,
  },
  trangCh1: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    left: "0%",
    width: "100%",
    textAlign: "left",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  component1: {
    top: 756,
    left: 169,
    height: 40,
  },
  groupChild1: {
    top: 0,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    left: 0,
    position: "absolute",
  },
  text1: {
    top: 315,
    fontSize: FontSize.size_mini,
    fontWeight: "600",
    fontFamily: FontFamily.openSansSemiBold,
    width: 173,
    height: 34,
    left: 96,
  },
  vectorIcon: {
    top: 296,
    left: 50,
    width: 286,
    maxHeight: "100%",
    position: "absolute",
  },
  groupChild2: {
    top: 40,
    width: 263,
    height: 53,
    left: 43,
    position: "absolute",
  },
  rectangleParent1: {
    zIndex: 0,
  },
  groupChild3: {
    left: 0,
  },
  groupChild4: {
    left: 73,
  },
  groupChild5: {
    left: 146,
  },
  groupContainer: {
    top: 0,
    left: 0,
  },
  text2: {
    top: 16,
    left: 18,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_5xl,
    color: Color.colorBlack,
  },
  text3: {
    left: 93,
    width: 29,
  },
  am: {
    left: 159,
    width: 38,
  },
  groupWrapper: {
    top: 146,
    left: 44,
    zIndex: 1,
  },
  groupWrapper3: {
    top: 0,
    left: 0,
  },
  groupWrapper2: {
    top: 153,
    left: 263,
    zIndex: 2,
  },
  groupParent: {
    top: 230,
    left: 26,
    flexDirection: "row",
    position: "absolute",
  },
  nhpVoNtThngBo: {
    top: 41,
    left: 346,
    width: 25,
    height: 23,
    position: "absolute",
  },
  iconUserCircle: {
    height: "5.3%",
    width: "10.95%",
    top: "3.94%",
    right: "80.1%",
    bottom: "90.76%",
    left: "8.96%",
    maxHeight: "100%",
    position: "absolute",
  },
  trangChu: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default TrangCh;

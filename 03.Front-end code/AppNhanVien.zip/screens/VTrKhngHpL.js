import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontFamily, Padding, FontSize } from "../GlobalStyles";

const VTrKhngHpL = () => {
  return (
    <View style={[styles.vTrKhngHpL, styles.vTrKhngHpLLayout]}>
      <View style={[styles.frameParent, styles.vTrKhngHpLLayout]}>
        <View style={styles.vTrCaBnKhngHpLWrapper}>
          <Text style={[styles.vTrCa, styles.vTrCaTypo]}>
            Vị trí của bạn không hợp lệ
          </Text>
        </View>
        <View style={[styles.thLi, styles.thLiFlexBox]}>
          <Text style={[styles.thLi1, styles.vTrCaTypo]}>Thử lại</Text>
        </View>
        <View style={[styles.bQua, styles.thLiFlexBox]}>
          <Text style={[styles.thLi1, styles.vTrCaTypo]}>{`Bỏ qua `}</Text>
        </View>
        <Image
          style={styles.cancelIcon}
          contentFit="cover"
          source={require("../assets/cancel.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  vTrKhngHpLLayout: {
    overflow: "hidden",
    height: 253,
    borderWidth: 1,
    borderStyle: "solid",
    borderRadius: Border.br_3xs,
  },
  vTrCaTypo: {
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.interRegular,
  },
  thLiFlexBox: {
    paddingVertical: Padding.p_xl,
    paddingHorizontal: Padding.p_lg,
    justifyContent: "center",
    flexDirection: "row",
    height: 55,
    width: 100,
    backgroundColor: Color.colorPaleturquoise,
    top: 167,
    alignItems: "center",
    position: "absolute",
    overflow: "hidden",
    borderRadius: Border.br_3xs,
  },
  vTrCa: {
    fontSize: FontSize.size_6xl,
    width: 263,
    height: 69,
  },
  vTrCaBnKhngHpLWrapper: {
    top: 80,
    left: 36,
    alignItems: "center",
    position: "absolute",
  },
  thLi1: {
    fontSize: FontSize.size_base,
  },
  thLi: {
    left: 26,
  },
  bQua: {
    left: 206,
  },
  cancelIcon: {
    top: 15,
    left: 100,
    width: 135,
    height: 65,
    position: "absolute",
  },
  frameParent: {
    borderColor: Color.colorBlack,
    width: 334,
  },
  vTrKhngHpL: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorWhite,
    borderColor: Color.colorSilver_100,
    flex: 1,
    width: "100%",
  },
});

export default VTrKhngHpL;

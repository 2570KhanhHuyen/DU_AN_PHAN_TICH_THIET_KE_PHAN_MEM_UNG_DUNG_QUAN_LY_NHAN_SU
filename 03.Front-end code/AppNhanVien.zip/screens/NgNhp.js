import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const NgNhp = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.dangNhap}>
      <Image
        style={[styles.dangNhapChild, styles.childLayout]}
        contentFit="cover"
        source={require("../assets/group-401.png")}
      />
      <View style={[styles.dangNhapItem, styles.dangPosition]} />
      <Image
        style={[styles.dangNhapInner, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-4.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-5.png")}
      />
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <Text
        style={[styles.nhpMNhn, styles.nhpTypo]}
      >{`Nhập mã nhân viên `}</Text>
      <Text style={[styles.mNhnVin, styles.mtKhuTypo]}>Mã Nhân Viên</Text>
      <View style={[styles.dangNhapChild1, styles.rectangleViewLayout]} />
      <Text style={[styles.nhpMtKhu, styles.nhpTypo]}>Nhập mật khẩu</Text>
      <Text style={[styles.mtKhu, styles.mtKhuTypo]}>Mật Khẩu</Text>
      <Text style={[styles.ghiNhNg, styles.textTypo]}>Ghi nhớ đăng nhập</Text>
      <View style={[styles.dangNhapChild2, styles.dangNhapChild2Layout]} />
      <View style={styles.groupParent}>
        <Image
          style={[styles.groupChild, styles.groupLayout]}
          contentFit="cover"
          source={require("../assets/group-2.png")}
        />
        <Image
          style={[styles.groupItem, styles.groupLayout]}
          contentFit="cover"
          source={require("../assets/group-3.png")}
        />
        <Image
          style={[styles.wifiIcon, styles.groupLayout]}
          contentFit="cover"
          source={require("../assets/wifi.png")}
        />
        <Text style={[styles.text, styles.textTypo]}>8.00</Text>
      </View>
      <View style={[styles.dangNhapChild3, styles.qunMtKhuPosition]} />
      <View style={[styles.dodos11Wrapper, styles.dodos11Layout]}>
        <View style={[styles.dodos11, styles.dodos11Layout]}>
          <Text style={[styles.hrms, styles.hrmsClr]}> HRMS</Text>
        </View>
      </View>
      <Image
        style={styles.image10Icon}
        contentFit="cover"
        source={require("../assets/image-10.png")}
      />
      <Image
        style={[styles.managementIcon, styles.dangNhapChild2Layout]}
        contentFit="cover"
        source={require("../assets/management.png")}
      />
      <Pressable
        style={[styles.ngNhpWrapper, styles.nhpLayout]}
        onPress={() => navigation.navigate("TrangCh")}
      >
        <View style={[styles.ngNhp, styles.nhpLayout]}>
          <Image
            style={[styles.ngNhpChild, styles.qunMtKhu1Position]}
            contentFit="cover"
            source={require("../assets/group-54.png")}
          />
          <Text style={[styles.ngNhp1, styles.hrmsClr]}>Đăng nhập</Text>
        </View>
      </Pressable>
      <View style={[styles.qunMtKhu, styles.qunMtKhuPosition]}>
        <Text style={[styles.qunMtKhu1, styles.qunMtKhu1Position]}>
          Quên mật khẩu?
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  childLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  dangPosition: {
    width: 375,
    left: 0,
    top: 0,
    backgroundColor: Color.colorWhite,
  },
  ellipseIconLayout: {
    height: 441,
    width: 441,
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 45,
    width: 324,
    borderRadius: Border.br_3xs,
    left: 25,
    borderWidth: 1,
    borderColor: Color.colorDarkslateblue_100,
    position: "absolute",
    borderStyle: "solid",
  },
  nhpTypo: {
    textAlign: "left",
    color: Color.colorDarkslateblue_200,
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_mini,
    left: 53,
    position: "absolute",
  },
  mtKhuTypo: {
    color: Color.colorBlack,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  textTypo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
    position: "absolute",
  },
  dangNhapChild2Layout: {
    height: 39,
    position: "absolute",
  },
  groupLayout: {
    width: 16,
    height: 16,
    top: 0,
    position: "absolute",
  },
  qunMtKhuPosition: {
    left: 30,
    position: "absolute",
  },
  dodos11Layout: {
    height: 49,
    width: 189,
    position: "absolute",
  },
  hrmsClr: {
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  nhpLayout: {
    height: 46,
    width: 325,
    position: "absolute",
  },
  qunMtKhu1Position: {
    left: "0%",
    top: "0%",
    position: "absolute",
  },
  dangNhapChild: {
    height: "23.4%",
    width: "31.95%",
    top: "11.08%",
    right: "70.19%",
    bottom: "65.52%",
    left: "-2.13%",
    display: "none",
    opacity: 0.3,
    position: "absolute",
  },
  dangNhapItem: {
    position: "absolute",
    height: 812,
  },
  dangNhapInner: {
    top: -92,
    left: -229,
  },
  ellipseIcon: {
    top: -190,
    left: 79,
  },
  rectangleView: {
    top: 408,
  },
  nhpMNhn: {
    top: 422,
  },
  mNhnVin: {
    top: 384,
    fontSize: FontSize.size_lg,
    color: Color.colorBlack,
    textAlign: "left",
    left: 25,
    position: "absolute",
  },
  dangNhapChild1: {
    top: 502,
  },
  nhpMtKhu: {
    top: 516,
  },
  mtKhu: {
    top: 478,
    fontSize: FontSize.size_lg,
    color: Color.colorBlack,
    textAlign: "left",
    left: 25,
    position: "absolute",
  },
  ghiNhNg: {
    top: 560,
    left: 56,
    color: Color.colorBlack,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  dangNhapChild2: {
    width: 375,
    left: 0,
    top: 0,
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    left: 290,
  },
  groupItem: {
    left: 306,
  },
  wifiIcon: {
    left: 274,
    overflow: "hidden",
  },
  text: {
    fontFamily: FontFamily.montserratBold,
    color: Color.colorDimgray_200,
    fontWeight: "700",
    left: 0,
    top: 0,
  },
  groupParent: {
    top: 12,
    width: 322,
    height: 16,
    left: 25,
    position: "absolute",
  },
  dangNhapChild3: {
    top: 556,
    width: 15,
    height: 15,
    borderWidth: 1,
    borderColor: Color.colorDarkslateblue_100,
    left: 30,
    borderStyle: "solid",
  },
  hrms: {
    top: "28.16%",
    left: "26.61%",
    fontSize: FontSize.size_12xl_6,
    fontFamily: FontFamily.alataRegular,
  },
  dodos11: {
    left: 0,
    top: 0,
    overflow: "hidden",
  },
  dodos11Wrapper: {
    top: 39,
    left: 221,
  },
  image10Icon: {
    top: 265,
    left: 165,
    width: 202,
    height: 64,
    position: "absolute",
  },
  managementIcon: {
    top: 58,
    left: 235,
    width: 36,
  },
  ngNhpChild: {
    height: "100%",
    right: "0%",
    bottom: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    width: "100%",
  },
  ngNhp1: {
    height: "54.35%",
    width: "39.68%",
    top: "23.91%",
    left: "30.33%",
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  ngNhp: {
    left: 0,
    top: 0,
  },
  ngNhpWrapper: {
    top: 601,
    left: 24,
  },
  qunMtKhu1: {
    fontSize: FontSize.size_base,
    color: Color.colorRoyalblue_100,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    top: "0%",
    textAlign: "left",
  },
  qunMtKhu: {
    top: 660,
    width: 138,
    height: 20,
  },
  dangNhap: {
    borderRadius: Border.br_6xl,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    overflow: "hidden",
    height: 812,
    width: "100%",
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
  },
});

export default NgNhp;

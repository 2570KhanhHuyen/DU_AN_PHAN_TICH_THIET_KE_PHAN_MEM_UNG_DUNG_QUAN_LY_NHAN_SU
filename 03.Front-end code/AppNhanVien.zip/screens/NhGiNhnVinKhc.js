import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const NhGiNhnVinKhc = () => {
  return (
    <View style={styles.nhGiNhnVinKhc}>
      <View style={styles.nhGiNhnVinKhcChild} />
      <View style={styles.rectangleParent}>
        <View style={styles.frameChild} />
        <View style={[styles.nhGi, styles.nhGiLayout]}>
          <View style={styles.nhGiItemPosition} />
          <View style={styles.nhGiItemPosition} />
          <Text style={[styles.nhGi1, styles.nhGi1FlexBox]}>Đánh giá</Text>
        </View>
      </View>
      <Text style={styles.lThKim}>Lê Thị Kim Cương</Text>
      <Text style={[styles.ngyTo16042024, styles.ngyClr]}>{`Ngày tạo
16/04/2024`}</Text>
      <Text style={styles.danhSchNhn}>Danh sách nhân viên</Text>
      <Image
        style={[styles.nhGiNhnVinKhcItem, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector-15.png")}
      />
      <Image
        style={[styles.nhGiNhnVinKhcInner, styles.nhnLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-481.png")}
      />
      <Text style={[styles.chcV, styles.chcLayout2]}>Chức vụ</Text>
      <Text style={[styles.nhnVinKinh, styles.nTypo]}>
        Nhân viên Kinh doanh
      </Text>
      <Text style={[styles.ngySinh, styles.ngyLayout]}>
        <Text style={styles.blankLine}> </Text>
        <Text style={styles.ngyTypo}>Ngày sinh</Text>
      </Text>
      <Text style={[styles.text, styles.textTypo1]}>16/04/2004</Text>
      <Text style={[styles.n, styles.nLayout]}>Nữ</Text>
      <Text style={[styles.giiTnh, styles.giiLayout]}>
        <Text style={styles.blankLine}> </Text>
        <Text style={styles.ngyTypo}>Giới tính</Text>
      </Text>
      <Text style={[styles.bngCp, styles.bngLayout]}>Bằng cấp</Text>
      <Text style={[styles.cNhnIt, styles.textTypo1]}>Cử nhân IT</Text>
      <View style={styles.rectangleViewShadowBox} />
      <View style={styles.rectangleViewShadowBox} />
      <Text style={[styles.lThPhng, styles.lThPhngPosition]}>
        Lê Thị Phương Thảo
      </Text>
      <Text style={[styles.ngyTo160420241, styles.ngyPosition]}>{`Ngày tạo
16/04/2024`}</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-491.png")}
      />
      <Text style={[styles.chcV1, styles.chcTypo]}>Chức vụ</Text>
      <Text style={[styles.nhnVinBn, styles.nhnTypo1]}>Nhân viên bán hàng</Text>
      <Text style={[styles.ngySinh2, styles.chcTypo]}>{`
Ngày sinh`}</Text>
      <Text style={[styles.text1, styles.textTypo]}>04/11/2004</Text>
      <Text style={[styles.n1, styles.textTypo]}>Nữ</Text>
      <Text style={[styles.giiTnh2, styles.chcTypo]}>{`
Giới tính`}</Text>
      <Text style={[styles.bngCp1, styles.chcTypo]}>Bằng cấp</Text>
      <Text style={[styles.cNhnQun, styles.textTypo]}>
        Cử nhân Quản trị Kinh doanh
      </Text>
      <View style={styles.nhnChildShadowBox1} />
      <View style={styles.nhnChildShadowBox1} />
      <Text style={[styles.trnhThKhnh, styles.trnhThKhnhPosition]}>
        Trịnh Thị Khánh Huyền
      </Text>
      <Text
        style={[styles.ngyTo160420242, styles.trnhThKhnhPosition]}
      >{`Ngày tạo
16/04/2024`}</Text>
      <Image
        style={[styles.nhGiNhnVinKhcChild4, styles.nhnLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-501.png")}
      />
      <Text style={[styles.chcV2, styles.chcV2Typo]}>Chức vụ</Text>
      <Text style={[styles.nhnVinMarketing, styles.nhnTypo]}>
        Nhân viên marketing
      </Text>
      <Text style={[styles.ngySinh3, styles.chcV2Typo]}>{`
Ngày sinh`}</Text>
      <Text style={[styles.text2, styles.nhnTypo]}>{`
25/07/2004`}</Text>
      <Text style={[styles.n2, styles.nhnTypo]}>{`
Nữ`}</Text>
      <Text style={[styles.giiTnh3, styles.chcV2Typo]}>{`
Giới tính`}</Text>
      <Text style={[styles.bngCp2, styles.chcV2Typo]}>Bằng cấp</Text>
      <Text style={[styles.cNhnMarketing, styles.nhnTypo]}>
        Cử nhân marketing
      </Text>
      <View style={styles.nhnChildShadowBox} />
      <View style={styles.nhnChildShadowBox} />
      <Text style={[styles.nguynThCm, styles.nguynThCmPosition]}>
        Nguyễn Thị Cẩm Nhi
      </Text>
      <Text style={[styles.ngyTo04052024, styles.nguynThCmPosition]}>{`Ngày tạo
04/05/2024`}</Text>
      <Image
        style={[styles.nhGiNhnVinKhcChild7, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-512.png")}
      />
      <Text style={[styles.chcV3, styles.chcTypo]}>Chức vụ</Text>
      <Text style={[styles.nhnVinBn1, styles.nhnTypo1]}>
        Nhân viên Bán hàng
      </Text>
      <Text style={[styles.ngySinh4, styles.chcTypo]}>{`
Ngày sinh`}</Text>
      <Text style={[styles.text3, styles.textTypo]}>20/04/2004</Text>
      <Text style={[styles.cNhnIn, styles.textTypo]}>Cử Nhân Điện lực</Text>
      <Text style={[styles.giiTnh4, styles.chcTypo]}>{`
Giới tính`}</Text>
      <Text style={[styles.bngCp3, styles.chcTypo]}>Bằng cấp</Text>
      <Text style={[styles.n3, styles.textTypo]}>Nữ</Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector-16.png")}
      />
      <Image
        style={[styles.nhGiNhnVinKhcChild8, styles.quayChildLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-51.png")}
      />
      <View style={[styles.nhGi2, styles.nhGi2Position]}>
        <View style={styles.childPosition} />
        <View style={styles.childPosition} />
        <Text style={[styles.nhGi3, styles.nTypo]}>Đánh giá</Text>
      </View>
      <View style={[styles.nhGi4, styles.nhGiLayout]}>
        <View style={styles.childPosition} />
        <View style={styles.childPosition} />
        <Text style={[styles.nhGi3, styles.nTypo]}>Đánh giá</Text>
      </View>
      <View style={[styles.nhGi6, styles.nhGi2Position]}>
        <View style={styles.childPosition} />
        <View style={styles.childPosition} />
        <Text style={[styles.nhGi3, styles.nTypo]}>Đánh giá</Text>
      </View>
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[styles.quayLiChild, styles.quayChildLayout]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.quayChildLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[styles.quayLiChild, styles.quayChildLayout]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.quayChildLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-40.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-42.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-41.png")}
        />
        <Image
          style={[styles.chcNngChild1, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-43.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Clr]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={[styles.trangCh, styles.chcNng1Clr]}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.quayChildLayout]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={760}
        propLeft={326}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  nhGiLayout: {
    height: 33,
    width: 82,
    position: "absolute",
  },
  nhGi1FlexBox: {
    textAlign: "center",
    top: "27.27%",
  },
  ngyClr: {
    color: Color.colorDimgray_300,
    lineHeight: 12,
    fontSize: FontSize.size_5xs,
  },
  vectorIconLayout: {
    maxHeight: "100%",
    position: "absolute",
  },
  nhnLayout: {
    height: 36,
    width: 36,
    position: "absolute",
  },
  chcLayout2: {
    width: 107,
    lineHeight: 13,
    height: 12,
  },
  nTypo: {
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  ngyLayout: {
    height: 6,
    width: 61,
    lineHeight: 1,
  },
  textTypo1: {
    left: 178,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  nLayout: {
    width: 37,
    height: 29,
  },
  giiLayout: {
    width: 98,
    height: 6,
    lineHeight: 1,
  },
  bngLayout: {
    height: 5,
    width: 62,
    lineHeight: 1,
  },
  lThPhngPosition: {
    left: 88,
    height: 23,
    color: Color.colorBlack,
    fontSize: FontSize.size_sm,
  },
  ngyPosition: {
    left: 317,
    color: Color.colorDimgray_300,
    lineHeight: 12,
    fontSize: FontSize.size_5xs,
  },
  ellipseIconPosition: {
    left: 41,
    height: 36,
    width: 36,
    position: "absolute",
  },
  chcTypo: {
    left: 54,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    position: "absolute",
  },
  nhnTypo1: {
    height: 15,
    width: 101,
    left: 180,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  textTypo: {
    left: 180,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  trnhThKhnhPosition: {
    top: 450,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  chcV2Typo: {
    left: 56,
    fontFamily: FontFamily.openSansRegular,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    position: "absolute",
  },
  nhnTypo: {
    left: 182,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  nguynThCmPosition: {
    top: 604,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  quayChildLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  nhGi2Position: {
    left: 293,
    height: 33,
    width: 82,
    position: "absolute",
  },
  chcNngLayout: {
    height: 40,
    width: 62,
    position: "absolute",
  },
  chcLayout1: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcPosition: {
    bottom: "51%",
    top: "28.25%",
  },
  chcLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Clr: {
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  nhGiNhnVinKhcChild: {
    right: 3,
    bottom: 0,
    backgroundColor: Color.colorGray_200,
    height: 66,
    left: 0,
    position: "absolute",
  },
  frameChild: {
    top: 0,
    backgroundColor: "#fffdd7",
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    height: 138,
    width: 343,
    left: 0,
    position: "absolute",
  },
  nhGiItemPosition: {
    transform: [
      {
        rotate: "180deg",
      },
    ],
    backgroundColor: Color.colorYellow,
    borderBottomLeftRadius: Border.br_3xs,
    left: "100%",
    bottom: "0%",
    right: "-100%",
    height: "100%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  nhGi1: {
    left: "23.17%",
    color: "#666200",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  nhGi: {
    top: 105,
    left: 261,
  },
  rectangleParent: {
    top: 117,
    left: 30,
    backgroundColor: "rgba(194, 40, 40, 0)",
    height: 138,
    width: 343,
    position: "absolute",
  },
  lThKim: {
    top: 138,
    left: 87,
    width: 128,
    height: 23,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  ngyTo16042024: {
    top: 135,
    left: 316,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  danhSchNhn: {
    top: 83,
    color: Color.oil11,
    fontSize: FontSize.size_base,
    left: 31,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  nhGiNhnVinKhcItem: {
    top: 108,
    left: 31,
    maxHeight: "100%",
    width: 343,
  },
  nhGiNhnVinKhcInner: {
    top: 129,
    left: 40,
  },
  chcV: {
    top: 177,
    height: 12,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    left: 53,
    textAlign: "left",
    position: "absolute",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
  },
  nhnVinKinh: {
    top: 180,
    width: 116,
    height: 14,
    lineHeight: 11,
    left: 179,
    fontWeight: "600",
    color: Color.oil11,
    textAlign: "left",
  },
  blankLine: {
    fontFamily: FontFamily.openSansRegular,
  },
  ngyTypo: {
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
  },
  ngySinh: {
    top: 198,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    left: 53,
    textAlign: "left",
    position: "absolute",
  },
  text: {
    top: 195,
    width: 72,
    height: 29,
  },
  n: {
    top: 213,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_3xs,
    position: "absolute",
    lineHeight: 11,
    left: 179,
    color: Color.oil11,
    textAlign: "left",
  },
  giiTnh: {
    top: 215,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    left: 53,
    textAlign: "left",
    position: "absolute",
  },
  bngCp: {
    top: 233,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    left: 53,
    textAlign: "left",
    position: "absolute",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
  },
  cNhnIt: {
    top: 229,
    width: 71,
    height: 14,
  },
  rectangleViewShadowBox: {
    backgroundColor: Color.colorWhite,
    top: 280,
    left: 32,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    height: 138,
    width: 343,
    position: "absolute",
  },
  lThPhng: {
    width: 161,
    top: 294,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  ngyTo160420241: {
    top: 294,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  ellipseIcon: {
    top: 285,
  },
  chcV1: {
    top: 333,
    height: 12,
    width: 107,
    lineHeight: 13,
  },
  nhnVinBn: {
    top: 336,
  },
  ngySinh2: {
    top: 354,
    height: 6,
    width: 61,
    lineHeight: 1,
  },
  text1: {
    top: 351,
    width: 69,
    height: 29,
  },
  n1: {
    top: 367,
    width: 37,
    height: 29,
  },
  giiTnh2: {
    top: 371,
    width: 98,
    height: 6,
    lineHeight: 1,
  },
  bngCp1: {
    top: 389,
    height: 5,
    width: 62,
    lineHeight: 1,
  },
  cNhnQun: {
    width: 76,
    top: 385,
    height: 14,
  },
  nhnChildShadowBox1: {
    left: 34,
    top: 436,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    height: 138,
    width: 343,
    position: "absolute",
  },
  trnhThKhnh: {
    left: 90,
    width: 160,
    height: 24,
    color: Color.colorBlack,
    fontSize: FontSize.size_sm,
    top: 450,
  },
  ngyTo160420242: {
    left: 319,
    color: Color.colorDimgray_300,
    lineHeight: 12,
    fontSize: FontSize.size_5xs,
  },
  nhGiNhnVinKhcChild4: {
    top: 441,
    left: 43,
  },
  chcV2: {
    top: 489,
    height: 12,
    width: 107,
    lineHeight: 13,
  },
  nhnVinMarketing: {
    top: 492,
    width: 113,
    height: 14,
  },
  ngySinh3: {
    top: 510,
    height: 6,
    width: 61,
    lineHeight: 1,
  },
  text2: {
    top: 498,
    width: 68,
    height: 29,
  },
  n2: {
    top: 514,
    width: 37,
    height: 29,
  },
  giiTnh3: {
    top: 527,
    width: 98,
    height: 6,
    lineHeight: 1,
  },
  bngCp2: {
    top: 545,
    height: 5,
    width: 62,
    lineHeight: 1,
  },
  cNhnMarketing: {
    top: 543,
    width: 99,
    height: 14,
  },
  nhnChildShadowBox: {
    top: 590,
    backgroundColor: Color.colorWhite,
    left: 32,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    height: 138,
    width: 343,
    position: "absolute",
  },
  nguynThCm: {
    width: 144,
    left: 88,
    height: 23,
    color: Color.colorBlack,
    fontSize: FontSize.size_sm,
  },
  ngyTo04052024: {
    left: 317,
    color: Color.colorDimgray_300,
    lineHeight: 12,
    fontSize: FontSize.size_5xs,
  },
  nhGiNhnVinKhcChild7: {
    top: 595,
  },
  chcV3: {
    top: 643,
    height: 12,
    width: 107,
    lineHeight: 13,
  },
  nhnVinBn1: {
    top: 646,
  },
  ngySinh4: {
    top: 664,
    height: 6,
    width: 61,
    lineHeight: 1,
  },
  text3: {
    top: 662,
    width: 63,
    height: 12,
  },
  cNhnIn: {
    width: 97,
    height: 10,
    top: 695,
  },
  giiTnh4: {
    top: 681,
    width: 98,
    height: 6,
    lineHeight: 1,
  },
  bngCp3: {
    top: 699,
    height: 5,
    width: 62,
    lineHeight: 1,
  },
  n3: {
    top: 678,
    width: 50,
    height: 9,
  },
  vectorIcon: {
    top: 109,
    left: 4,
    width: 398,
  },
  nhGiNhnVinKhcChild8: {
    height: "0.74%",
    width: "1.59%",
    top: "97.29%",
    right: "37.49%",
    bottom: "1.97%",
    left: "60.92%",
    opacity: 0,
  },
  childPosition: {
    backgroundColor: Color.colorLightcyan,
    transform: [
      {
        rotate: "180deg",
      },
    ],
    borderBottomLeftRadius: Border.br_3xs,
    left: "100%",
    bottom: "0%",
    right: "-100%",
    top: "0%",
    height: "100%",
    position: "absolute",
    width: "100%",
  },
  nhGi3: {
    left: "24.39%",
    color: Color.colorDarkcyan,
    textAlign: "center",
    top: "27.27%",
  },
  nhGi2: {
    top: 385,
  },
  nhGi4: {
    top: 541,
    left: 295,
  },
  nhGi6: {
    top: 695,
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    fontFamily: FontFamily.robotoRegular,
    color: Color.oil11,
    fontSize: FontSize.size_base,
    textAlign: "center",
    top: "0%",
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
  },
  quayLi: {
    top: 45,
    width: 79,
    height: 19,
    left: 32,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngChild1: {
    bottom: "51%",
    top: "28.25%",
  },
  chcNng1: {
    top: "71%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    color: Color.colorWhite,
    textAlign: "center",
  },
  chcNng: {
    top: 761,
    left: 23,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    left: "0%",
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxWidth: "100%",
  },
  component1: {
    top: 758,
    left: 167,
  },
  nhGiNhnVinKhc: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default NhGiNhnVinKhc;

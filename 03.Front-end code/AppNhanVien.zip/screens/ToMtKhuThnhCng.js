import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import Xong from "../components/Xong1";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const ToMtKhuThnhCng = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.toMtKhuThnhCng}>
      <View style={[styles.iMtKhuThnhCng, styles.khuPosition]}>
        <Image
          style={styles.iMtKhuThnhCngChild}
          contentFit="cover"
          source={require("../assets/group-40.png")}
        />
        <View style={[styles.iMtKhuThnhCngItem, styles.khuPosition]} />
        <Image
          style={[styles.iMtKhuThnhCngInner, styles.ellipseIconLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-4.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.ellipseIconLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-5.png")}
        />
        <Text style={[styles.thnhCng, styles.textFlexBox]}>Thành công!</Text>
        <Text style={[styles.mtKhuCa, styles.textFlexBox]}>
          Mật khẩu của bạn đã được cập nhật.
        </Text>
        <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
        <View style={styles.groupParent}>
          <Image
            style={[styles.groupChild, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/group-2.png")}
          />
          <Image
            style={[styles.groupItem, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/group-3.png")}
          />
          <Image
            style={[styles.wifiIcon, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <Text style={[styles.text, styles.textFlexBox]}>8.00</Text>
        </View>
        <View style={[styles.dodos11Wrapper, styles.dodos11Layout]}>
          <View style={[styles.dodos11, styles.dodos11Layout]}>
            <Text style={[styles.hrms, styles.textFlexBox]}> HRMS</Text>
          </View>
        </View>
        <Image
          style={styles.image10Icon}
          contentFit="cover"
          source={require("../assets/image-10.png")}
        />
        <Image
          style={[styles.managementIcon, styles.rectangleViewLayout]}
          contentFit="cover"
          source={require("../assets/management.png")}
        />
        <Image
          style={styles.checkMarkIcon}
          contentFit="cover"
          source={require("../assets/check-mark.png")}
        />
        <Pressable
          style={styles.xongWrapper}
          onPress={() => navigation.navigate("NgNhp")}
        >
          <Xong />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  khuPosition: {
    width: 375,
    backgroundColor: Color.colorWhite,
    left: 0,
    top: 0,
  },
  ellipseIconLayout: {
    height: 441,
    width: 441,
    position: "absolute",
  },
  textFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 39,
    position: "absolute",
  },
  groupLayout: {
    width: 16,
    height: 16,
    top: 0,
    position: "absolute",
  },
  dodos11Layout: {
    height: 49,
    width: 189,
    position: "absolute",
  },
  iMtKhuThnhCngChild: {
    height: "23.4%",
    width: "31.95%",
    top: "11.08%",
    right: "70.19%",
    bottom: "65.52%",
    left: "-2.13%",
    maxWidth: "100%",
    maxHeight: "100%",
    display: "none",
    opacity: 0.3,
    overflow: "hidden",
    position: "absolute",
  },
  iMtKhuThnhCngItem: {
    position: "absolute",
    height: 812,
  },
  iMtKhuThnhCngInner: {
    top: -92,
    left: -229,
  },
  ellipseIcon: {
    top: -190,
    left: 79,
  },
  thnhCng: {
    marginLeft: -69.5,
    top: 436,
    left: "50%",
    fontSize: FontSize.size_6xl,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.montserratBold,
    fontWeight: "700",
  },
  mtKhuCa: {
    top: 472,
    left: 48,
    fontSize: FontSize.size_mini,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    color: Color.colorBlack,
    textAlign: "left",
  },
  rectangleView: {
    width: 375,
    backgroundColor: Color.colorWhite,
    left: 0,
    top: 0,
  },
  groupChild: {
    left: 290,
  },
  groupItem: {
    left: 306,
  },
  wifiIcon: {
    left: 274,
    overflow: "hidden",
  },
  text: {
    fontSize: FontSize.size_xs,
    color: Color.colorDimgray_200,
    fontFamily: FontFamily.montserratBold,
    fontWeight: "700",
    left: 0,
    top: 0,
  },
  groupParent: {
    top: 12,
    width: 322,
    height: 16,
    left: 25,
    position: "absolute",
  },
  hrms: {
    top: "28.16%",
    left: "26.61%",
    fontSize: FontSize.size_12xl_6,
    fontFamily: FontFamily.alataRegular,
    color: Color.colorWhite,
  },
  dodos11: {
    overflow: "hidden",
    left: 0,
    top: 0,
  },
  dodos11Wrapper: {
    top: 39,
    left: 221,
  },
  image10Icon: {
    top: 265,
    left: 165,
    width: 202,
    height: 64,
    position: "absolute",
  },
  managementIcon: {
    top: 58,
    left: 235,
    width: 36,
  },
  checkMarkIcon: {
    top: 503,
    left: 137,
    width: 90,
    height: 90,
    position: "absolute",
  },
  xongWrapper: {
    top: 618,
    width: 325,
    height: 45,
    left: 25,
    position: "absolute",
  },
  iMtKhuThnhCng: {
    borderRadius: Border.br_6xl,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    overflow: "hidden",
    position: "absolute",
    height: 812,
  },
  toMtKhuThnhCng: {
    flex: 1,
    width: "100%",
    height: 812,
  },
});

export default ToMtKhuThnhCng;

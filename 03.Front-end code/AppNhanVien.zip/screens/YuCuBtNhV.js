import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, Padding, Border, FontSize } from "../GlobalStyles";

const YuCuBtNhV = () => {
  return (
    <View style={styles.yuCuBtNhV}>
      <View style={styles.yuCuBtNhVChild} />
      <Image
        style={styles.placeMarkerIcon}
        contentFit="cover"
        source={require("../assets/place-marker.png")}
      />
      <Text style={[styles.vuiLngBt, styles.bt1Typo]}>
        Vui lòng bật định vị của bạn
      </Text>
      <View style={[styles.bt, styles.btFlexBox]}>
        <Text style={[styles.bt1, styles.bt1Typo]}>Bật</Text>
      </View>
      <View style={[styles.quayLi, styles.btFlexBox]}>
        <Text style={[styles.bt1, styles.bt1Typo]}>Quay lại</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  bt1Typo: {
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.interRegular,
  },
  btFlexBox: {
    paddingVertical: Padding.p_xl,
    paddingHorizontal: Padding.p_lg,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 55,
    width: 97,
    backgroundColor: Color.colorPaleturquoise,
    top: 163,
    position: "absolute",
    overflow: "hidden",
    borderRadius: Border.br_3xs,
  },
  yuCuBtNhVChild: {
    backgroundColor: Color.colorWhite,
    width: 334,
    height: 254,
    zIndex: 0,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  placeMarkerIcon: {
    top: 17,
    left: 119,
    width: 94,
    height: 54,
    zIndex: 1,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  vuiLngBt: {
    top: 75,
    left: 38,
    fontSize: FontSize.size_6xl,
    width: 257,
    height: 69,
    zIndex: 2,
    position: "absolute",
  },
  bt1: {
    fontSize: FontSize.size_base,
  },
  bt: {
    left: 30,
    zIndex: 3,
  },
  quayLi: {
    left: 213,
    zIndex: 4,
  },
  yuCuBtNhV: {
    borderStyle: "solid",
    borderColor: Color.colorSilver_100,
    borderWidth: 1,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
});

export default YuCuBtNhV;

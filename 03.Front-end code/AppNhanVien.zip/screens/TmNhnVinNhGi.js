import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const TmNhnVinNhGi = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.tmNhnVinNhGi}>
      <View
        style={[styles.tmNhnVinNhGiChild, styles.tmNhnVinNhGiChildLayout]}
      />
      <Image
        style={[styles.tmNhnVinNhGiItem, styles.itemLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <View style={styles.chcNng}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-404.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcNngItemPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-425.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-414.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-434.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Typo]}>CHỨC NĂNG</Text>
      </View>
      <View style={styles.component1}>
        <Text style={[styles.trangCh, styles.chcNng1Position]}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.itemLayout]}
          contentFit="cover"
          source={require("../assets/home2.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person1.png")}
        propTop={759}
        propLeft={330}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <View style={styles.quayLi}>
        <Text style={[styles.quayLi1, styles.tmKimClr]}>Quay lại</Text>
        <Image
          style={styles.quayLiChild}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.itemLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <Text style={[styles.tmKim, styles.tmKimClr]}>Tìm kiếm</Text>
      <View style={[styles.groupParent, styles.groupParentPosition]}>
        <View style={[styles.bgRecentSearchesParent, styles.parentPosition]}>
          <View style={[styles.bgRecentSearches, styles.bgInputIconPosition]} />
          <Image
            style={[styles.bgInputIcon, styles.bgInputIconPosition]}
            contentFit="cover"
            source={require("../assets/bg-input.png")}
          />
          <View style={[styles.groupContainer, styles.containerLayout]}>
            <Pressable
              style={[
                styles.deleteFromHistoryParent,
                styles.deleteParentLayout,
              ]}
              onPress={() => navigation.navigate("NhGiNhnVinKhc")}
            >
              <Image
                style={[styles.deleteFromHistory, styles.deleteLayout]}
                contentFit="cover"
                source={require("../assets/delete-from-history.png")}
              />
              <Image
                style={[styles.searchIcon, styles.searchIconLayout]}
                contentFit="cover"
                source={require("../assets/search1.png")}
              />
              <Text style={[styles.lThKim, styles.lThKimTypo]}>
                Lê Thị Kim Cương
              </Text>
            </Pressable>
            <View
              style={[styles.deleteFromHistoryGroup, styles.deleteParentLayout]}
            >
              <Image
                style={[styles.deleteFromHistory, styles.deleteLayout]}
                contentFit="cover"
                source={require("../assets/delete-from-history.png")}
              />
              <Image
                style={[styles.searchIcon, styles.searchIconLayout]}
                contentFit="cover"
                source={require("../assets/search1.png")}
              />
              <Text style={[styles.lThKim, styles.lThKimTypo]}>Hòa</Text>
            </View>
            <View
              style={[styles.deleteFromHistoryContainer, styles.deletePosition]}
            >
              <Image
                style={[styles.deleteFromHistory, styles.deleteLayout]}
                contentFit="cover"
                source={require("../assets/delete-from-history.png")}
              />
              <Image
                style={[styles.searchIcon, styles.searchIconLayout]}
                contentFit="cover"
                source={require("../assets/search1.png")}
              />
              <Text style={[styles.lThKim, styles.lThKimTypo]}>Huyền</Text>
              <View style={[styles.groupView, styles.groupViewLayout]}>
                <Image
                  style={[styles.deleteFromHistory3, styles.deleteLayout]}
                  contentFit="cover"
                  source={require("../assets/delete-from-history.png")}
                />
                <Image
                  style={[styles.searchIcon3, styles.searchIconLayout]}
                  contentFit="cover"
                  source={require("../assets/search1.png")}
                />
                <Text style={[styles.trnThThu, styles.lThKimTypo]}>
                  Trần Thị Thu
                </Text>
                <View
                  style={[
                    styles.deleteFromHistoryParent1,
                    styles.groupViewLayout,
                  ]}
                >
                  <Image
                    style={[styles.deleteFromHistory, styles.deleteLayout]}
                    contentFit="cover"
                    source={require("../assets/delete-from-history.png")}
                  />
                  <Image
                    style={[styles.searchIcon, styles.searchIconLayout]}
                    contentFit="cover"
                    source={require("../assets/search1.png")}
                  />
                  <Text style={[styles.lThKim, styles.lThKimTypo]}>
                    Trần Thị
                  </Text>
                  <View
                    style={[
                      styles.deleteFromHistoryParent2,
                      styles.parentPosition,
                    ]}
                  >
                    <Image
                      style={[styles.deleteFromHistory, styles.deleteLayout]}
                      contentFit="cover"
                      source={require("../assets/delete-from-history.png")}
                    />
                    <Image
                      style={[styles.searchIcon, styles.searchIconLayout]}
                      contentFit="cover"
                      source={require("../assets/search1.png")}
                    />
                    <Text style={[styles.lThKim, styles.lThKimTypo]}>
                      Lê Thị Bảo Ngọc
                    </Text>
                    <View
                      style={[
                        styles.deleteFromHistoryParent3,
                        styles.tmNhnVinNhGiChildLayout,
                      ]}
                    >
                      <Image
                        style={[styles.deleteFromHistory, styles.deleteLayout]}
                        contentFit="cover"
                        source={require("../assets/delete-from-history.png")}
                      />
                      <Image
                        style={[styles.searchIcon, styles.searchIconLayout]}
                        contentFit="cover"
                        source={require("../assets/search1.png")}
                      />
                      <Text style={[styles.lThKim, styles.lThKimTypo]}>
                        Bảo Ngọc
                      </Text>
                      <View
                        style={[
                          styles.deleteFromHistoryParent4,
                          styles.deleteParentLayout,
                        ]}
                      >
                        <Image
                          style={[
                            styles.deleteFromHistory,
                            styles.deleteLayout,
                          ]}
                          contentFit="cover"
                          source={require("../assets/delete-from-history.png")}
                        />
                        <Image
                          style={[styles.searchIcon, styles.searchIconLayout]}
                          contentFit="cover"
                          source={require("../assets/search1.png")}
                        />
                        <Text style={[styles.lThKim, styles.lThKimTypo]}>
                          Ngọc
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.groupParent1}>
          <View style={styles.groupParent1}>
            <View style={[styles.bgRecentSearches1, styles.bgInputBorder]} />
            <View style={[styles.bgInput, styles.bgInputBorder]} />
          </View>
          <View style={styles.searchParent}>
            <Image
              style={styles.searchIcon8}
              contentFit="cover"
              source={require("../assets/search2.png")}
            />
            <Text style={styles.nhpThngTin}>Nhập thông tin tìm kiếm</Text>
          </View>
        </View>
      </View>
      <Image
        style={[styles.tmNhnVinNhGiInner, styles.groupParentPosition]}
        contentFit="cover"
        source={require("../assets/vector-17.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  tmNhnVinNhGiChildLayout: {
    height: 66,
    position: "absolute",
  },
  itemLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcLayout: {
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngItemPosition: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNngInnerLayout: {
    left: "50%",
    right: "35.87%",
    width: "14.13%",
    height: "20.97%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Typo: {
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
  },
  chcNng1Position: {
    color: Color.colorWhite,
    left: "0%",
    position: "absolute",
  },
  tmKimClr: {
    color: Color.oil11,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  groupParentPosition: {
    left: 36,
    position: "absolute",
  },
  parentPosition: {
    left: 2,
    position: "absolute",
  },
  bgInputIconPosition: {
    borderRadius: Border.br_11xl,
    top: 0,
    width: 329,
    left: 0,
    position: "absolute",
  },
  containerLayout: {
    width: 308,
    position: "absolute",
  },
  deleteParentLayout: {
    height: 25,
    width: 303,
    position: "absolute",
  },
  deleteLayout: {
    height: 23,
    width: 23,
    borderRadius: Border.br_11xl,
    top: 0,
    position: "absolute",
  },
  searchIconLayout: {
    height: 16,
    width: 16,
    top: 2,
    borderRadius: Border.br_11xl,
    position: "absolute",
    overflow: "hidden",
  },
  lThKimTypo: {
    height: 24,
    width: 197,
    color: Color.colorDimgray_100,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    top: 1,
    textAlign: "left",
    position: "absolute",
  },
  deletePosition: {
    top: 42,
    left: 0,
  },
  groupViewLayout: {
    width: 307,
    position: "absolute",
  },
  bgInputBorder: {
    borderWidth: 1,
    borderColor: Color.colorDimgray_500,
    borderRadius: 41,
    height: 45,
    top: 0,
    left: 0,
    position: "absolute",
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
  },
  tmNhnVinNhGiChild: {
    top: 746,
    backgroundColor: Color.colorGray_200,
    width: 402,
    left: 0,
  },
  tmNhnVinNhGiItem: {
    height: "0.74%",
    width: "1.59%",
    top: "97.29%",
    right: "39.23%",
    bottom: "1.97%",
    left: "59.18%",
    opacity: 0,
    maxHeight: "100%",
  },
  chcNngChild: {
    bottom: "79.03%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.22%",
    width: "14.13%",
    height: "20.97%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.03%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.97%",
    top: "28.06%",
  },
  chcNng1: {
    top: "70.97%",
    fontSize: FontSize.size_5xs,
    color: Color.colorWhite,
    left: "0%",
    position: "absolute",
  },
  chcNng: {
    top: 762,
    left: 40,
    width: 46,
    height: 31,
    position: "absolute",
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxHeight: "100%",
  },
  component1: {
    top: 756,
    left: 177,
    width: 62,
    height: 40,
    position: "absolute",
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    top: "0%",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
    maxHeight: "100%",
  },
  quayLi: {
    top: 47,
    left: 34,
    width: 79,
    height: 19,
    position: "absolute",
  },
  tmKim: {
    top: 80,
    left: 42,
    fontWeight: "700",
    fontFamily: FontFamily.openSansBold,
    textAlign: "left",
  },
  bgRecentSearches: {
    shadowOpacity: 1,
    elevation: 49.54,
    shadowRadius: 49.54,
    shadowOffset: {
      width: 0,
      height: 24.769420623779297,
    },
    shadowColor: "rgba(0, 0, 0, 0.16)",
    height: 378,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_11xl,
  },
  bgInputIcon: {
    height: 51,
  },
  deleteFromHistory: {
    left: 280,
  },
  searchIcon: {
    left: 0,
  },
  lThKim: {
    left: 29,
  },
  deleteFromHistoryParent: {
    left: 1,
    top: 0,
  },
  deleteFromHistoryGroup: {
    top: 277,
    left: 4,
  },
  deleteFromHistory3: {
    left: 281,
  },
  searchIcon3: {
    left: 1,
  },
  trnThThu: {
    left: 30,
  },
  deleteFromHistoryParent4: {
    top: 41,
    left: 1,
  },
  deleteFromHistoryParent3: {
    top: 38,
    width: 304,
    left: 1,
  },
  deleteFromHistoryParent2: {
    top: 40,
    width: 305,
    height: 104,
  },
  deleteFromHistoryParent1: {
    height: 144,
    top: 42,
    left: 0,
  },
  groupView: {
    top: 39,
    height: 186,
    left: 1,
  },
  deleteFromHistoryContainer: {
    height: 225,
    width: 308,
    position: "absolute",
  },
  groupContainer: {
    top: 56,
    left: 12,
    height: 302,
  },
  bgRecentSearchesParent: {
    top: 8,
    height: 378,
    width: 329,
  },
  bgRecentSearches1: {
    shadowOpacity: 1,
    elevation: 49.54,
    shadowRadius: 49.54,
    shadowOffset: {
      width: 0,
      height: 24.769420623779297,
    },
    shadowColor: "rgba(0, 0, 0, 0.16)",
    width: 329,
  },
  bgInput: {
    width: 333,
  },
  groupParent1: {
    height: 45,
    top: 0,
    width: 333,
    left: 0,
    position: "absolute",
  },
  searchIcon8: {
    height: 18,
    borderRadius: 41,
    width: 16,
    top: 2,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  nhpThngTin: {
    left: 24,
    color: Color.oil04,
    width: 295,
    height: 15,
    top: 0,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  searchParent: {
    top: 13,
    left: 14,
    width: 319,
    height: 20,
    position: "absolute",
  },
  groupParent: {
    top: 129,
    height: 386,
    width: 333,
  },
  tmNhnVinNhGiInner: {
    top: 108,
    width: 331,
    maxHeight: "100%",
  },
  tmNhnVinNhGi: {
    borderRadius: Border.br_6xl,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    borderStyle: "solid",
    backgroundColor: Color.colorWhite,
  },
});

export default TmNhnVinNhGi;

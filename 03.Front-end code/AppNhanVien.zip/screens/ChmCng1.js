import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const ChmCng1 = () => {
  return (
    <View style={styles.chmCng}>
      <Image
        style={styles.image13Icon}
        contentFit="cover"
        source={require("../assets/image-131.png")}
      />
      <Text style={styles.pm71Ng}>{`1/5/2024  07:00:00 PM
71 Ngũ Hành Sơn
Đà Nẵng
Việt Nam`}</Text>
      <Image
        style={styles.ntChpNh}
        contentFit="cover"
        source={require("../assets/nt-chp-nh1.png")}
      />
      <Image
        style={styles.ntChpNh}
        contentFit="cover"
        source={require("../assets/nt-chp-nh1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  image13Icon: {
    top: -5,
    left: -9,
    width: 426,
    height: 875,
    position: "absolute",
  },
  pm71Ng: {
    top: "9.85%",
    right: 13,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    textAlign: "right",
    width: 278,
    position: "absolute",
  },
  ntChpNh: {
    top: 712,
    left: 134,
    width: 144,
    height: 100,
    position: "absolute",
  },
  chmCng: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default ChmCng1;

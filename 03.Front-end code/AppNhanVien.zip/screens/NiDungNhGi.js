import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const NiDungNhGi = () => {
  return (
    <View style={styles.danhGiaNhanVien}>
      <View style={styles.danhGiaNhanVienChild} />
      <Text style={styles.niDungNh}>Nội dung đánh giá</Text>
      <Image
        style={[styles.danhGiaNhanVienItem, styles.danhPosition]}
        contentFit="cover"
        source={require("../assets/vector-151.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienInner, styles.danhPosition]}
        contentFit="cover"
        source={require("../assets/vector-161.png")}
      />
      <Image
        style={[styles.vectorIcon, styles.danhChildLayout]}
        contentFit="cover"
        source={require("../assets/vector-24.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild1, styles.danhChildLayout]}
        contentFit="cover"
        source={require("../assets/vector-28.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild2, styles.danhChildLayout]}
        contentFit="cover"
        source={require("../assets/vector-24.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild3, styles.danhChildLayout]}
        contentFit="cover"
        source={require("../assets/vector-26.png")}
      />
      <Text style={[styles.hiuQuCng, styles.thiTypo]}>Hiệu quả công việc</Text>
      <Text style={[styles.mc, styles.mcTypo]}>Mức độ</Text>
      <Text style={[styles.mc1, styles.mcTypo]}>Mức độ</Text>
      <Text style={[styles.hiuBitV, styles.hiuTypo]}>
        Hiểu biết về chuyên môn
      </Text>
      <Text style={[styles.hiuBitV1, styles.hiuTypo]}>{`Hiểu biết về kiến thức 
phục vụ công việc`}</Text>
      <Text style={[styles.mcHon, styles.hiuTypo]}>Mức độ hoàn thành</Text>
      <Text style={[styles.text, styles.hiuTypo]}>{` `}</Text>
      <Text style={[styles.tKhchHng, styles.danhChildPosition1]}>
        Đặt khách hàng là trung tâm
      </Text>
      <Text style={[styles.chuCP, styles.danhChildPosition1]}>
        Chịu được áp lực cao
      </Text>
      <Text style={[styles.trungThcV, styles.danhChildPosition1]}>
        Trung thực và cẩn thận
      </Text>
      <Image
        style={[styles.danhGiaNhanVienChild4, styles.danhChildPosition1]}
        contentFit="cover"
        source={require("../assets/vector-24.png")}
      />
      <Text style={[styles.thi, styles.thiTypo]}>Thái độ</Text>
      <Image
        style={[styles.danhGiaNhanVienChild5, styles.danhChildPosition1]}
        contentFit="cover"
        source={require("../assets/vector-31.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild6, styles.danhChildPosition1]}
        contentFit="cover"
        source={require("../assets/vector-28.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild7, styles.danhChildPosition1]}
        contentFit="cover"
        source={require("../assets/vector-26.png")}
      />
      <Text style={[styles.tChcThi, styles.danhChildPosition]}>
        Tổ chức thời gian
      </Text>
      <Text style={[styles.phnTchV, styles.danhChildPosition]}>
        Phân tích và xử lý tình huống
      </Text>
      <Text style={[styles.giaoTipTt, styles.danhChildPosition]}>
        Giao tiếp tốt
      </Text>
      <Image
        style={[styles.danhGiaNhanVienChild8, styles.danhChildPosition]}
        contentFit="cover"
        source={require("../assets/vector-24.png")}
      />
      <Text style={[styles.kNng, styles.thiTypo]}>Kỹ năng</Text>
      <Image
        style={[styles.danhGiaNhanVienChild9, styles.danhChildPosition]}
        contentFit="cover"
        source={require("../assets/vector-24.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild10, styles.danhChildPosition]}
        contentFit="cover"
        source={require("../assets/vector-28.png")}
      />
      <Image
        style={[styles.danhGiaNhanVienChild11, styles.danhChildPosition]}
        contentFit="cover"
        source={require("../assets/vector-26.png")}
      />
      <View style={[styles.square90Parent, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.square90Group, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.square115Parent, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon4, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.square115Group, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon4, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.square121Parent, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.square121Group, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <Text style={[styles.mc2, styles.mcTypo]}>Mức độ</Text>
      <View style={[styles.square90Container, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.square121Container, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <View style={[styles.groupView, styles.groupParentLayout]}>
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
        <Image
          style={[styles.square90Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square99Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.square92Icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/square-90.png")}
        />
        <Image
          style={[styles.doneIcon, styles.doneIconLayout]}
          contentFit="cover"
          source={require("../assets/done.png")}
        />
      </View>
      <Image
        style={[styles.ellipseIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-51.png")}
      />
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[styles.quayLiChild, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={styles.gi}>
        <View style={[styles.giChild, styles.giChildPosition]} />
        <Text style={styles.gi1}>Gửi</Text>
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-402.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-423.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-412.png")}
        />
        <Image
          style={[styles.chcNngChild1, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-432.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Clr]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={[styles.trangCh, styles.chcNng1Clr]}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.giChildPosition]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={758}
        propLeft={332}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  danhPosition: {
    maxHeight: "100%",
    top: 108,
    position: "absolute",
  },
  danhChildLayout: {
    width: 302,
    maxHeight: "100%",
  },
  thiTypo: {
    height: 24,
    width: 165,
    color: Color.colorBlack,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  mcTypo: {
    width: 61,
    height: 24,
    color: Color.colorBlack,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  hiuTypo: {
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  danhChildPosition1: {
    left: 65,
    position: "absolute",
  },
  danhChildPosition: {
    left: 66,
    position: "absolute",
  },
  groupParentLayout: {
    height: 18,
    width: 72,
    position: "absolute",
  },
  iconLayout1: {
    width: 24,
    top: 0,
    height: 18,
    position: "absolute",
  },
  doneIconLayout: {
    height: 14,
    width: 12,
    top: 2,
    position: "absolute",
  },
  iconLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  giChildPosition: {
    top: "0%",
    position: "absolute",
  },
  chcNngLayout: {
    width: 62,
    position: "absolute",
  },
  chcLayout1: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcPosition: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.98%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Clr: {
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  danhGiaNhanVienChild: {
    top: 746,
    backgroundColor: Color.colorGray_200,
    width: 399,
    height: 66,
    left: 0,
    position: "absolute",
  },
  niDungNh: {
    top: 83,
    fontWeight: "700",
    fontFamily: FontFamily.openSansBold,
    color: Color.colorMediumaquamarine_200,
    textAlign: "left",
    fontSize: FontSize.size_base,
    left: 33,
    position: "absolute",
  },
  danhGiaNhanVienItem: {
    width: 340,
    left: 31,
  },
  danhGiaNhanVienInner: {
    left: 3,
    width: 398,
  },
  vectorIcon: {
    top: 210,
    left: 68,
    position: "absolute",
  },
  danhGiaNhanVienChild1: {
    top: 170,
    left: 68,
    position: "absolute",
  },
  danhGiaNhanVienChild2: {
    top: 259,
    left: 68,
    position: "absolute",
  },
  danhGiaNhanVienChild3: {
    top: 289,
    left: 68,
    position: "absolute",
  },
  hiuQuCng: {
    left: 35,
    width: 165,
    color: Color.colorBlack,
    top: 140,
  },
  mc: {
    left: 300,
    width: 61,
    top: 140,
  },
  mc1: {
    top: 516,
    left: 304,
  },
  hiuBitV: {
    top: 181,
    left: 68,
    position: "absolute",
  },
  hiuBitV1: {
    top: 215,
    left: 68,
    position: "absolute",
  },
  mcHon: {
    top: 265,
    left: 68,
    position: "absolute",
  },
  text: {
    top: 346,
    left: 67,
    position: "absolute",
  },
  tKhchHng: {
    top: 450,
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  chuCP: {
    top: 406,
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  trungThcV: {
    top: 366,
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  danhGiaNhanVienChild4: {
    top: 395,
    width: 302,
    maxHeight: "100%",
  },
  thi: {
    top: 325,
    left: 35,
    width: 165,
    color: Color.colorBlack,
  },
  danhGiaNhanVienChild5: {
    top: 434,
    width: 302,
    maxHeight: "100%",
  },
  danhGiaNhanVienChild6: {
    top: 355,
    width: 302,
    maxHeight: "100%",
  },
  danhGiaNhanVienChild7: {
    top: 474,
    width: 302,
    maxHeight: "100%",
  },
  tChcThi: {
    top: 634,
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  phnTchV: {
    top: 594,
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  giaoTipTt: {
    top: 554,
    width: 197,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
  },
  danhGiaNhanVienChild8: {
    top: 583,
    width: 302,
    maxHeight: "100%",
  },
  kNng: {
    top: 513,
    width: 165,
    color: Color.colorBlack,
    left: 33,
  },
  danhGiaNhanVienChild9: {
    top: 623,
    width: 302,
    maxHeight: "100%",
  },
  danhGiaNhanVienChild10: {
    top: 543,
    width: 302,
    maxHeight: "100%",
  },
  danhGiaNhanVienChild11: {
    top: 662,
    width: 302,
    maxHeight: "100%",
  },
  square90Icon: {
    left: 0,
  },
  square99Icon: {
    left: 24,
  },
  square92Icon: {
    left: 48,
  },
  doneIcon: {
    left: 54,
  },
  square90Parent: {
    top: 556,
    left: 294,
    width: 72,
  },
  square90Group: {
    top: 228,
    left: 294,
    width: 72,
  },
  doneIcon4: {
    left: 30,
  },
  square115Parent: {
    top: 597,
    left: 294,
    width: 72,
  },
  square115Group: {
    left: 293,
    top: 265,
  },
  square121Parent: {
    top: 637,
    left: 294,
    width: 72,
  },
  square121Group: {
    top: 186,
    left: 294,
    width: 72,
  },
  mc2: {
    top: 331,
    left: 300,
    width: 61,
  },
  square90Container: {
    top: 372,
    left: 294,
    width: 72,
  },
  square121Container: {
    top: 415,
    left: 294,
    width: 72,
  },
  groupView: {
    top: 453,
    left: 295,
  },
  ellipseIcon: {
    height: "0.74%",
    width: "1.59%",
    top: "97.29%",
    right: "35.5%",
    bottom: "1.97%",
    left: "62.91%",
    opacity: 0,
    position: "absolute",
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    color: Color.oil11,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    top: "0%",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
    position: "absolute",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
    position: "absolute",
  },
  quayLi: {
    top: 45,
    width: 79,
    height: 19,
    left: 31,
    position: "absolute",
  },
  giChild: {
    height: "100%",
    right: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorPaleturquoise,
    left: "0%",
    width: "100%",
  },
  gi1: {
    top: "13.16%",
    left: "28.92%",
    fontSize: FontSize.size_xl,
    color: Color.colorSeagreen,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  gi: {
    top: 685,
    left: 165,
    width: 83,
    height: 38,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.02%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.02%",
    top: "0%",
  },
  chcNngChild1: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNng1: {
    top: "70.98%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    textAlign: "center",
  },
  chcNng: {
    top: 760,
    left: 22,
    height: 41,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    left: "0%",
    textAlign: "left",
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  component1: {
    top: 754,
    left: 170,
    height: 40,
  },
  danhGiaNhanVien: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhite,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default NiDungNhGi;

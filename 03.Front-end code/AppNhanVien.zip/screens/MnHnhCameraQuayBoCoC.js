import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const MnHnhCameraQuayBoCoC = () => {
  return (
    <View style={styles.ghiHinhCongViec}>
      <Image
        style={styles.zondiconsfilm}
        contentFit="cover"
        source={require("../assets/zondiconsfilm1.png")}
      />
      <View style={styles.materialSymbolsLightpause} />
      <Image
        style={styles.ghiHinhCongViecChild}
        contentFit="cover"
        source={require("../assets/ellipse-51.png")}
      />
      <Image
        style={styles.image13Icon}
        contentFit="cover"
        source={require("../assets/image-13.png")}
      />
      <Text style={styles.pm71Ng}>{`1/5/2024  07:00:00 PM
71 Ngũ Hành Sơn
Đà Nẵng
Việt Nam`}</Text>
      <Image
        style={styles.ntChpNh}
        contentFit="cover"
        source={require("../assets/nt-chp-nh.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  zondiconsfilm: {
    top: 0,
    left: 0,
    width: 20,
    height: 20,
    position: "absolute",
    overflow: "hidden",
  },
  materialSymbolsLightpause: {
    top: 503,
    left: 149,
    width: 38,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  ghiHinhCongViecChild: {
    height: "0.74%",
    width: "1.59%",
    top: "97.29%",
    right: "38.48%",
    bottom: "1.97%",
    left: "59.93%",
    maxWidth: "100%",
    maxHeight: "100%",
    opacity: 0,
    position: "absolute",
    overflow: "hidden",
  },
  image13Icon: {
    top: -3,
    left: -12,
    width: 426,
    height: 875,
    position: "absolute",
  },
  pm71Ng: {
    top: "9.61%",
    right: 9,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    textAlign: "right",
    width: 278,
    position: "absolute",
  },
  ntChpNh: {
    top: 712,
    left: 127,
    width: 151,
    height: 106,
    position: "absolute",
  },
  ghiHinhCongViec: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default MnHnhCameraQuayBoCoC;

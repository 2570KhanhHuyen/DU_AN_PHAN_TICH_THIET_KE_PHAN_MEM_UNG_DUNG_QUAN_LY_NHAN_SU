import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, FontSize, FontFamily, Color } from "../GlobalStyles";

const ChmCngThnhCng = () => {
  return (
    <View style={[styles.chmCngThnhCng, styles.chmLayout]}>
      <View>
        <View style={[styles.chmCngThnhCngParent, styles.chmLayout]}>
          <Text style={[styles.chmCngThnh, styles.xong1FlexBox]}>
            Chấm công thành công
          </Text>
          <View style={styles.xong}>
            <View style={styles.xongInnerPosition}>
              <View style={[styles.groupChild, styles.xongInnerPosition]} />
            </View>
            <Text style={[styles.xong1, styles.xong1FlexBox]}>Xong</Text>
          </View>
        </View>
        <Image
          style={styles.checkMarkIcon}
          contentFit="cover"
          source={require("../assets/check-mark1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  chmLayout: {
    overflow: "hidden",
    borderRadius: Border.br_3xs,
  },
  xong1FlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  xongInnerPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
    width: "100%",
  },
  chmCngThnh: {
    marginLeft: -132,
    top: 46,
    fontSize: FontSize.size_6xl,
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorBlack,
    width: 263,
    height: 46,
    left: "50%",
  },
  groupChild: {
    backgroundColor: Color.colorMediumaquamarine_100,
    borderRadius: Border.br_3xs,
  },
  xong1: {
    height: "55.56%",
    width: "24.91%",
    top: "22.22%",
    left: "37.53%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
  },
  xong: {
    marginLeft: -145,
    top: 181,
    width: 291,
    height: 45,
    left: "50%",
    position: "absolute",
  },
  chmCngThnhCngParent: {
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 1,
    width: 334,
    height: 253,
    zIndex: 0,
  },
  checkMarkIcon: {
    top: 88,
    left: 115,
    width: 104,
    height: 77,
    zIndex: 1,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  chmCngThnhCng: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    overflow: "hidden",
  },
});

export default ChmCngThnhCng;

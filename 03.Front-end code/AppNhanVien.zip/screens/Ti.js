import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Ti = () => {
  return (
    <View style={styles.toi}>
      <View style={styles.toiChild} />
      <View style={[styles.toiItem, styles.toiItemShadowBox]} />
      <Text style={styles.trnThThy}>Trần Thị Thùy Trang</Text>
      <Text style={styles.ngyTo20032024}>{`Ngày tạo
20/03/2024`}</Text>
      <Text style={styles.hSC}>{`Hồ sơ cá nhân `}</Text>
      <Image
        style={[styles.toiInner, styles.toiInnerLayout]}
        contentFit="cover"
        source={require("../assets/vector-15.png")}
      />
      <Image
        style={styles.ellipseIcon}
        contentFit="cover"
        source={require("../assets/ellipse-482.png")}
      />
      <Text style={[styles.giiTnh, styles.giiLayout]}>{`
Giới tính`}</Text>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.hVTn, styles.hVTnLayout]}>Họ và tên</Text>
        <Text style={[styles.chcV, styles.aChTypo]}>Chức vụ</Text>
        <Text style={[styles.kNng, styles.aChTypo]}>Kỹ năng</Text>
        <Text style={[styles.kinhNghim, styles.chngChLayout]}>Kinh nghiệm</Text>
        <Text style={[styles.chngCh, styles.chngChLayout]}>Chứng chỉ</Text>
        <Text style={styles.bngCp}>Bằng cấp</Text>
        <Text style={[styles.aCh, styles.aChTypo]}>Địa chỉ</Text>
        <Text style={styles.trnThThy1}>{`Trần Thị Thùy Trang
`}</Text>
        <Text style={[styles.ngySinh, styles.aChTypo]}>{`
Ngày sinh`}</Text>
        <Text style={[styles.text, styles.nTypo]}>24/02/2004</Text>
        <Text style={[styles.nhnVinMarketing, styles.editVideoVitTypo]}>
          Nhân viên Marketing
        </Text>
        <Text style={[styles.n, styles.nTypo]}>{`
Nữ`}</Text>
        <Text style={[styles.giiTnh1, styles.aChTypo]}>{`
Giới tính`}</Text>
        <Text style={[styles.email, styles.aChTypo]}>{`
Email`}</Text>
        <Text style={[styles.sInThoi, styles.hVTnTypo]}>Số điện thoại</Text>
        <Text style={[styles.tiuLa, styles.tiuLaTypo]}>130 Tiểu La</Text>
        <Text style={[styles.text1, styles.tiuLaTypo]}>032333444</Text>
        <Text style={[styles.editVideoVit, styles.editVideoVitTypo]}>
          Edit video, Viết lách...
        </Text>
        <Text style={[styles.contentCreation, styles.ielts70Typo]}>
          Content creation
        </Text>
        <Text style={[styles.cNhnNgnh, styles.ielts70Typo]}>
          Cử nhân ngành Marketing
        </Text>
        <Text style={[styles.ielts70, styles.ielts70Typo]}>IELTS 7.0</Text>
        <Text style={[styles.thuytranggmailcom, styles.editVideoVitTypo]}>
          ThuyTrang@gmail.com
        </Text>
      </View>
      <Image
        style={[styles.vectorIcon, styles.toiInnerLayout]}
        contentFit="cover"
        source={require("../assets/vector-162.png")}
      />
      <Text style={styles.ti}>Tôi</Text>
      <Image
        style={styles.iconUserCircle}
        contentFit="cover"
        source={require("../assets/-icon-user-circle.png")}
      />
      <View style={styles.ngXut}>
        <Image
          style={[styles.ngXutChild, styles.trangChPosition]}
          contentFit="cover"
          source={require("../assets/group-54.png")}
        />
        <Text style={styles.ngXut1}>Đăng xuất</Text>
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-40.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-42.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-41.png")}
        />
        <Image
          style={[styles.chcNngChild1, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-43.png")}
        />
        <Text style={[styles.chcNng1, styles.chcNng1Typo]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={[styles.trangCh, styles.chcNng1Typo]}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.homeIconPosition]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={759}
        propLeft={331}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <Image
        style={styles.nhpVoNtThngBo}
        contentFit="cover"
        source={require("../assets/nhp-vo-nt-thng-bo.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  toiItemShadowBox: {
    width: 342,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  toiInnerLayout: {
    maxHeight: "100%",
    position: "absolute",
  },
  giiLayout: {
    height: 2,
    width: 124,
    lineHeight: 1,
  },
  groupChildLayout: {
    height: 443,
    position: "absolute",
  },
  hVTnLayout: {
    height: 16,
    width: 135,
    lineHeight: 13,
  },
  aChTypo: {
    left: 14,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  chngChLayout: {
    height: 17,
    width: 134,
    left: 13,
    lineHeight: 13,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  nTypo: {
    left: 186,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  editVideoVitTypo: {
    left: 185,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  hVTnTypo: {
    left: 15,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  tiuLaTypo: {
    width: 99,
    left: 186,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  ielts70Typo: {
    left: 187,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  trangChPosition: {
    left: "0%",
    width: "100%",
  },
  chcNngLayout: {
    width: 62,
    height: 40,
    position: "absolute",
  },
  chcLayout1: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcPosition: {
    bottom: "51%",
    top: "28.25%",
  },
  chcLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng1Typo: {
    fontFamily: FontFamily.robotoRegular,
    color: Color.colorWhite,
    position: "absolute",
  },
  homeIconPosition: {
    top: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  toiChild: {
    top: 746,
    backgroundColor: Color.colorGray_200,
    width: 399,
    height: 66,
    left: 0,
    position: "absolute",
  },
  toiItem: {
    top: 886,
    left: -897,
    height: 204,
    position: "absolute",
  },
  trnThThy: {
    top: 165,
    left: 101,
    fontSize: FontSize.size_sm,
    color: Color.colorBlack,
    width: 216,
    height: 32,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  ngyTo20032024: {
    top: 170,
    left: 316,
    lineHeight: 15,
    color: Color.colorDimgray_300,
    width: 76,
    height: 40,
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  hSC: {
    top: 102,
    fontSize: FontSize.size_base,
    color: Color.oil11,
    left: 30,
    textAlign: "left",
    fontFamily: FontFamily.openSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  toiInner: {
    top: 125,
    width: 343,
    left: 30,
    maxHeight: "100%",
  },
  ellipseIcon: {
    top: 156,
    left: 32,
    width: 51,
    height: 50,
    position: "absolute",
  },
  giiTnh: {
    top: 362,
    left: 43,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    height: 2,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  groupChild: {
    top: 0,
    width: 342,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 0,
  },
  hVTn: {
    top: 18,
    left: 15,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  chcV: {
    top: 52,
    height: 16,
    width: 135,
    lineHeight: 13,
  },
  kNng: {
    top: 268,
    height: 18,
    width: 135,
    lineHeight: 13,
    left: 14,
  },
  kinhNghim: {
    top: 311,
  },
  chngCh: {
    top: 355,
  },
  bngCp: {
    top: 399,
    width: 134,
    left: 13,
    height: 18,
    lineHeight: 13,
    color: Color.colorDimgray_400,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.openSansRegular,
    textAlign: "left",
    position: "absolute",
  },
  aCh: {
    top: 161,
    height: 18,
    width: 135,
    lineHeight: 13,
    left: 14,
  },
  trnThThy1: {
    top: 19,
    left: 182,
    height: 21,
    width: 128,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    color: Color.oil11,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  ngySinh: {
    top: 96,
    width: 79,
    height: 10,
    lineHeight: 1,
    left: 14,
  },
  text: {
    top: 92,
    width: 105,
    height: 18,
  },
  nhnVinMarketing: {
    top: 55,
    width: 152,
    height: 18,
  },
  n: {
    top: 110,
    width: 46,
    height: 43,
  },
  giiTnh1: {
    top: 132,
    height: 2,
    width: 124,
    lineHeight: 1,
  },
  email: {
    top: 240,
    height: 2,
    width: 124,
    lineHeight: 1,
  },
  sInThoi: {
    top: 206,
    width: 124,
    left: 15,
    lineHeight: 1,
  },
  tiuLa: {
    top: 160,
    height: 19,
  },
  text1: {
    top: 199,
    height: 22,
  },
  editVideoVit: {
    top: 278,
    width: 142,
    height: 21,
  },
  contentCreation: {
    top: 314,
    height: 22,
    width: 128,
  },
  cNhnNgnh: {
    top: 403,
    width: 167,
    height: 22,
  },
  ielts70: {
    top: 359,
    height: 21,
    width: 128,
  },
  thuytranggmailcom: {
    top: 236,
    textDecoration: "underline",
    width: 159,
    height: 20,
  },
  rectangleParent: {
    top: 230,
    left: 29,
    width: 354,
  },
  vectorIcon: {
    top: 126,
    left: 10,
    width: 398,
  },
  ti: {
    top: 42,
    left: 40,
    fontFamily: FontFamily.robotoBold,
    width: 130,
    textAlign: "center",
    fontSize: FontSize.size_5xl,
    color: Color.oil11,
    fontWeight: "700",
    position: "absolute",
  },
  iconUserCircle: {
    height: "5.3%",
    width: "10.95%",
    top: "4.31%",
    right: "81.84%",
    bottom: "90.39%",
    left: "7.21%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  ngXutChild: {
    height: "100%",
    right: "0%",
    bottom: "0%",
    top: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  ngXut1: {
    height: "54.35%",
    width: "39.68%",
    top: "23.91%",
    left: "30.33%",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    fontWeight: "700",
    position: "absolute",
  },
  ngXut: {
    top: 685,
    left: 34,
    width: 325,
    height: 46,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngChild1: {
    bottom: "51%",
    top: "28.25%",
  },
  chcNng1: {
    top: "71%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    textAlign: "center",
  },
  chcNng: {
    top: 759,
    left: 21,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    left: "0%",
    width: "100%",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.robotoRegular,
    textAlign: "left",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
  },
  component1: {
    top: 754,
    left: 169,
  },
  nhpVoNtThngBo: {
    top: 45,
    left: 344,
    width: 25,
    height: 23,
    position: "absolute",
  },
  toi: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default Ti;

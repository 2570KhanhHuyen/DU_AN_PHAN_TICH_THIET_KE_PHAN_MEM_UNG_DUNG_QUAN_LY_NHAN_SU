import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const NhpSInThoiLyLi = () => {
  return (
    <View style={styles.nhpSInThoiLyLi}>
      <View style={[styles.nhpOtp, styles.nhpLayout]}>
        <Image
          style={styles.nhpOtpChild}
          contentFit="cover"
          source={require("../assets/group-401.png")}
        />
        <View style={[styles.nhpOtpItem, styles.nhpLayout]} />
        <Image
          style={[styles.nhpOtpInner, styles.nhpOtpInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-4.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.nhpOtpInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-5.png")}
        />
        <View style={[styles.rectangleView, styles.giOtpLayout]} />
        <Text style={[styles.qunMtKhu, styles.textTypo]}>Quên mật khẩu ?</Text>
        <View style={[styles.nhpOtpChild1, styles.nhpOtpChild1Layout]} />
        <View style={styles.groupParent}>
          <Image
            style={[styles.groupChild, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/group-2.png")}
          />
          <Image
            style={[styles.groupItem, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/group-3.png")}
          />
          <Image
            style={[styles.wifiIcon, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <Text style={[styles.text, styles.textTypo]}>8.00</Text>
        </View>
        <View style={[styles.dodos11Wrapper, styles.dodos11Layout]}>
          <View style={[styles.dodos11, styles.dodos11Layout]}>
            <Text style={[styles.hrms, styles.hrmsClr]}> HRMS</Text>
          </View>
        </View>
        <Image
          style={styles.image10Icon}
          contentFit="cover"
          source={require("../assets/image-10.png")}
        />
        <Image
          style={[styles.managementIcon, styles.nhpOtpChild1Layout]}
          contentFit="cover"
          source={require("../assets/management.png")}
        />
        <Text
          style={[styles.nhpSIn, styles.nhpTypo]}
        >{`Nhập số điện thoại của bạn
để lấy lại mật khẩu`}</Text>
        <View style={[styles.giOtp, styles.giOtpLayout]}>
          <View style={[styles.tipTc, styles.giOtpLayout]}>
            <View style={styles.innerPosition}>
              <View style={[styles.groupInner, styles.innerPosition]} />
            </View>
            <Text style={[styles.tipTc1, styles.hrmsClr]}>Gửi OTP</Text>
          </View>
        </View>
        <Text style={[styles.nhpSIn1, styles.nhpTypo]}>Nhập số điện thoại</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  nhpLayout: {
    width: 375,
    backgroundColor: Color.colorWhite,
  },
  nhpOtpInnerLayout: {
    height: 441,
    width: 441,
    position: "absolute",
  },
  giOtpLayout: {
    height: 45,
    width: 334,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.montserratBold,
    fontWeight: "700",
    position: "absolute",
  },
  nhpOtpChild1Layout: {
    height: 39,
    position: "absolute",
  },
  groupLayout: {
    width: 16,
    height: 16,
    top: 0,
    position: "absolute",
  },
  dodos11Layout: {
    height: 49,
    width: 189,
    position: "absolute",
  },
  hrmsClr: {
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  nhpTypo: {
    fontSize: FontSize.size_mini,
    textAlign: "left",
    position: "absolute",
  },
  innerPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
    width: "100%",
  },
  nhpOtpChild: {
    height: "23.4%",
    width: "31.95%",
    top: "11.08%",
    right: "70.19%",
    bottom: "65.52%",
    left: "-2.13%",
    maxWidth: "100%",
    maxHeight: "100%",
    display: "none",
    opacity: 0.3,
    overflow: "hidden",
    position: "absolute",
  },
  nhpOtpItem: {
    top: 17,
    left: 1,
    width: 375,
    backgroundColor: Color.colorWhite,
    position: "absolute",
    height: 812,
  },
  nhpOtpInner: {
    top: -92,
    left: -229,
  },
  ellipseIcon: {
    top: -190,
    left: 79,
  },
  rectangleView: {
    top: 484,
    borderColor: Color.colorDarkslateblue_100,
    borderWidth: 1,
    borderRadius: Border.br_3xs,
    left: 25,
    width: 334,
    borderStyle: "solid",
  },
  qunMtKhu: {
    top: 387,
    fontSize: FontSize.size_6xl,
    color: Color.colorBlack,
    left: 31,
  },
  nhpOtpChild1: {
    width: 375,
    backgroundColor: Color.colorWhite,
    left: 0,
    top: 0,
  },
  groupChild: {
    left: 290,
  },
  groupItem: {
    left: 306,
  },
  wifiIcon: {
    left: 274,
    overflow: "hidden",
  },
  text: {
    fontSize: FontSize.size_xs,
    color: Color.colorDimgray_200,
    left: 0,
    top: 0,
  },
  groupParent: {
    top: 12,
    width: 322,
    height: 16,
    left: 25,
    position: "absolute",
  },
  hrms: {
    top: "28.16%",
    left: "26.61%",
    fontSize: FontSize.size_12xl_6,
    fontFamily: FontFamily.alataRegular,
  },
  dodos11: {
    overflow: "hidden",
    left: 0,
    top: 0,
  },
  dodos11Wrapper: {
    top: 39,
    left: 221,
  },
  image10Icon: {
    top: 265,
    left: 165,
    width: 202,
    height: 64,
    position: "absolute",
  },
  managementIcon: {
    top: 58,
    left: 235,
    width: 36,
  },
  nhpSIn: {
    top: 428,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    width: 242,
    color: Color.colorBlack,
    left: 31,
  },
  groupInner: {
    backgroundColor: Color.colorMediumaquamarine_100,
    borderRadius: Border.br_3xs,
  },
  tipTc1: {
    height: "55.56%",
    width: "39.7%",
    top: "22.22%",
    left: "34.16%",
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    color: Color.colorWhite,
  },
  tipTc: {
    left: 0,
    top: 0,
  },
  giOtp: {
    top: 567,
    left: 20,
  },
  nhpSIn1: {
    top: 497,
    left: 48,
    fontFamily: FontFamily.interRegular,
    color: Color.colorDarkslateblue_200,
    width: 162,
    height: 22,
  },
  nhpOtp: {
    borderRadius: Border.br_6xl,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    overflow: "hidden",
    borderStyle: "solid",
    width: 375,
    backgroundColor: Color.colorWhite,
    left: 0,
    top: 0,
    position: "absolute",
    height: 812,
  },
  nhpSInThoiLyLi: {
    flex: 1,
    height: 812,
    width: "100%",
  },
});

export default NhpSInThoiLyLi;

import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const ChcNng = () => {
  return (
    <View style={styles.chcNng}>
      <View style={styles.chcNngChild} />
      <Image
        style={[styles.chcNngItem, styles.chcLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Text style={styles.chcNng1}>Chức Năng</Text>
      <Image
        style={[styles.iconUserCircle, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/-icon-user-circle.png")}
      />
      <View style={[styles.dodos11Wrapper, styles.dodos11Layout]}>
        <View style={[styles.dodos11, styles.dodos11Layout]}>
          <Text style={styles.hrms}> HRMS</Text>
        </View>
      </View>
      <Image
        style={styles.managementIcon}
        contentFit="cover"
        source={require("../assets/management1.png")}
      />
      <Image
        style={[styles.chcNngInner, styles.chcLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-51.png")}
      />
      <View style={[styles.xemBngCng, styles.xemLayout]}>
        <View style={[styles.xemBngCngChild, styles.trangChPosition]} />
        <Text style={[styles.xemBngCng1, styles.xemTypo]}>XEM BẢNG CÔNG</Text>
        <Image
          style={[styles.timetableIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/timetable.png")}
        />
      </View>
      <View style={[styles.xemCngVic, styles.xemLayout]}>
        <View style={[styles.xemBngCngChild, styles.trangChPosition]} />
        <Text style={[styles.xemCngVic1, styles.xemTypo]}>XEM CÔNG VIỆC</Text>
        <Image
          style={[styles.iconWorkload, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/-icon-workload.png")}
        />
      </View>
      <View style={[styles.nhGiNhnVinKhc, styles.xemLayout]}>
        <View style={[styles.xemBngCngChild, styles.trangChPosition]} />
        <Text style={[styles.nhGiNhn, styles.xemTypo]}>
          ĐÁNH GIÁ NHÂN VIÊN KHÁC
        </Text>
        <Image
          style={[styles.inscriptionIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/inscription.png")}
        />
      </View>
      <View style={[styles.chcNng2, styles.chcNng2Layout]}>
        <Image
          style={[styles.ellipseIcon, styles.ellipseIconLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-40.png")}
        />
        <Image
          style={[styles.chcNngChild1, styles.chcChildPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-42.png")}
        />
        <Image
          style={[styles.chcNngChild2, styles.chcChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-41.png")}
        />
        <Image
          style={[styles.chcNngChild3, styles.chcChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-43.png")}
        />
        <Text style={[styles.chcNng3, styles.chcNng3Clr]}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNng2Layout]}>
        <Text style={[styles.trangCh, styles.chcNng3Clr]}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.homeIconPosition]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={759}
        propLeft={336}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <Image
        style={styles.nhpVoNtThngBo}
        contentFit="cover"
        source={require("../assets/nhp-vo-nt-thng-bo.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  chcLayout: {
    opacity: 0,
    width: "1.59%",
    height: "0.74%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  iconLayout1: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  dodos11Layout: {
    height: 49,
    width: 189,
    position: "absolute",
  },
  xemLayout: {
    height: 160,
    width: 342,
    left: 29,
    position: "absolute",
  },
  trangChPosition: {
    left: "0%",
    width: "100%",
  },
  xemTypo: {
    fontFamily: FontFamily.openSansRegular,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    color: Color.oil11,
    position: "absolute",
  },
  iconLayout: {
    width: "26.32%",
    height: "56.25%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng2Layout: {
    height: 40,
    width: 62,
    position: "absolute",
  },
  ellipseIconLayout: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcChildPosition: {
    bottom: "51%",
    top: "28.25%",
  },
  chcChildLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.75%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNng3Clr: {
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  homeIconPosition: {
    top: "0%",
    position: "absolute",
  },
  chcNngChild: {
    top: 746,
    backgroundColor: Color.colorGray_200,
    width: 402,
    height: 66,
    left: 0,
    position: "absolute",
  },
  chcNngItem: {
    top: "97.29%",
    right: "39.23%",
    bottom: "1.97%",
    left: "59.18%",
  },
  chcNng1: {
    top: 48,
    left: 75,
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.robotoBold,
    width: 130,
    textAlign: "center",
    color: Color.oil11,
    position: "absolute",
  },
  iconUserCircle: {
    height: "5.3%",
    width: "10.95%",
    top: "5.05%",
    right: "81.84%",
    bottom: "89.66%",
    left: "7.21%",
    position: "absolute",
  },
  hrms: {
    top: "28.16%",
    left: "26.61%",
    fontSize: FontSize.size_12xl_6,
    fontFamily: FontFamily.alataRegular,
    color: Color.colorBlack,
    textAlign: "left",
    position: "absolute",
  },
  dodos11: {
    top: 0,
    left: 0,
    overflow: "hidden",
  },
  dodos11Wrapper: {
    top: 84,
    left: 143,
  },
  managementIcon: {
    top: 91,
    left: 129,
    width: 75,
    height: 58,
    position: "absolute",
  },
  chcNngInner: {
    top: "98.77%",
    right: "36.49%",
    bottom: "0.49%",
    left: "61.92%",
  },
  xemBngCngChild: {
    height: "100%",
    right: "0%",
    bottom: "0%",
    borderRadius: Border.br_xs,
    backgroundColor: Color.colorWhite,
    top: "0%",
    position: "absolute",
  },
  xemBngCng1: {
    top: "72.5%",
    left: "34.21%",
  },
  timetableIcon: {
    top: "4.38%",
    right: "35.67%",
    bottom: "39.38%",
    left: "38.01%",
  },
  xemBngCng: {
    top: 171,
  },
  xemCngVic1: {
    top: "77.5%",
    left: "34.8%",
  },
  iconWorkload: {
    height: "39.81%",
    width: "18.63%",
    top: "23.13%",
    right: "40.44%",
    bottom: "37.06%",
    left: "40.94%",
    position: "absolute",
  },
  xemCngVic: {
    top: 356,
  },
  nhGiNhn: {
    left: "22.81%",
    top: "78.5%",
  },
  inscriptionIcon: {
    top: "18.13%",
    right: "35.47%",
    bottom: "25.63%",
    left: "38.22%",
  },
  nhGiNhnVinKhc: {
    top: 541,
  },
  ellipseIcon: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngChild1: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.75%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngChild2: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngChild3: {
    bottom: "51%",
    top: "28.25%",
  },
  chcNng3: {
    top: "71%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    textAlign: "center",
  },
  chcNng2: {
    top: 761,
    left: 18,
  },
  trangCh: {
    height: "21.5%",
    fontSize: FontSize.size_3xs,
    top: "78.5%",
    left: "0%",
    width: "100%",
    textAlign: "left",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  component1: {
    top: 759,
    left: 170,
  },
  nhpVoNtThngBo: {
    top: 52,
    left: 346,
    width: 25,
    height: 23,
    position: "absolute",
  },
  chcNng: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
  },
});

export default ChcNng;

import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, FontSize, Color, FontFamily } from "../GlobalStyles";

const BnCChcChnMunNgXu = () => {
  return (
    <View style={[styles.bnCChcChnMunNgXu, styles.chcLayout]}>
      <View>
        <View style={[styles.bnCChcChnMunNgXuParent, styles.chcLayout]}>
          <Text style={[styles.bnCChc, styles.xong1FlexBox]}>
            Bạn có chắc chắn muốn đăng xuất không
          </Text>
          <Image
            style={styles.questionMarkIcon}
            contentFit="cover"
            source={require("../assets/question-mark.png")}
          />
          <View style={[styles.chcChn, styles.xongLayout]}>
            <View style={styles.xongParentPosition}>
              <View style={[styles.xong, styles.xongLayout]}>
                <View style={styles.xongParentPosition}>
                  <View
                    style={[styles.groupChild, styles.xongParentPosition]}
                  />
                </View>
                <Text style={[styles.xong1, styles.xong1FlexBox]}>Xong</Text>
              </View>
              <Text style={[styles.chcChn1, styles.khng1Typo]}>Chắc chắn</Text>
            </View>
          </View>
          <View style={[styles.khng, styles.xongLayout]}>
            <View style={styles.xongParentPosition}>
              <View style={styles.xongParentPosition}>
                <View style={[styles.groupChild, styles.xongParentPosition]} />
              </View>
              <Text style={[styles.xong1, styles.xong1FlexBox]}>Xong</Text>
            </View>
            <Text style={[styles.khng1, styles.khng1Typo]}>Không</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  chcLayout: {
    overflow: "hidden",
    borderRadius: Border.br_3xs,
  },
  xong1FlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  xongLayout: {
    height: 52,
    width: 102,
    position: "absolute",
  },
  xongParentPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
    width: "100%",
  },
  khng1Typo: {
    fontSize: FontSize.size_base,
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  bnCChc: {
    marginLeft: -123,
    top: 19,
    fontSize: FontSize.size_6xl,
    width: 263,
    height: 46,
    color: Color.colorBlack,
    fontFamily: FontFamily.robotoRegular,
    textAlign: "center",
    left: "50%",
  },
  questionMarkIcon: {
    top: 83,
    left: 111,
    width: 113,
    height: 80,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorPaleturquoise,
    borderRadius: Border.br_3xs,
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
  },
  xong1: {
    height: "55.58%",
    width: "24.9%",
    top: "22.31%",
    left: "37.55%",
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorWhite,
    display: "none",
  },
  xong: {
    marginLeft: -51,
    top: 0,
    width: 102,
    left: "50%",
  },
  chcChn1: {
    marginTop: -10,
    top: "50%",
    left: 12,
    width: 79,
    height: 19,
  },
  chcChn: {
    left: 32,
    top: 170,
    width: 102,
  },
  khng1: {
    height: "36.54%",
    width: "77.45%",
    top: "30.77%",
    left: "10.78%",
  },
  khng: {
    left: 205,
    top: 170,
    width: 102,
  },
  bnCChcChnMunNgXuParent: {
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 1,
    width: 334,
    height: 253,
  },
  bnCChcChnMunNgXu: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    overflow: "hidden",
  },
});

export default BnCChcChnMunNgXu;

import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const MnHnhHinThCngVic = () => {
  return (
    <View style={styles.mnHnhHinThCngVic}>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.viewGroupPosition]} />
        <Image
          style={[styles.groupItem, styles.groupItemLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-21.png")}
        />
      </View>
      <View style={styles.materialSymbolsLightpause} />
      <Image
        style={[styles.mnHnhHinThCngVicChild, styles.groupItemLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-21.png")}
      />
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={[styles.quayLiChild, styles.quayLayout]}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.quayLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-402.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcNngItemPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-422.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-412.png")}
        />
        <Image
          style={[styles.ellipseIcon, styles.chcNngInnerLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-432.png")}
        />
        <Text style={styles.chcNng1}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={styles.trangCh}>TRANG CHỦ</Text>
        <Image
          style={[styles.homeIcon, styles.quayLayout]}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={759}
        propLeft={338}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
      <View style={[styles.groupParent, styles.groupLayout1]}>
        <View style={[styles.groupContainer, styles.groupLayout1]}>
          <View style={[styles.groupContainer, styles.groupLayout1]}>
            <Image
              style={[styles.groupInner, styles.quayLayout]}
              contentFit="cover"
              source={require("../assets/vector-221.png")}
            />
            <View style={[styles.groupContainer, styles.groupLayout1]}>
              <View style={[styles.rectangleView, styles.luBoCoChildLayout]} />
            </View>
            <View style={[styles.groupWrapper, styles.groupLayout]}>
              <View style={[styles.groupView, styles.groupLayout]}>
                <View style={[styles.groupFrame, styles.groupFrameLayout]}>
                  <View style={[styles.cngVic1Parent, styles.groupFrameLayout]}>
                    <Text style={[styles.cngVic1Container, styles.text2Typo]}>
                      <Text style={styles.cngVic1}>Công việc 1</Text>
                      <Text style={styles.text}>{` `}</Text>
                    </Text>
                    <View
                      style={[styles.frameView, styles.viewGroupPosition]}
                    />
                    <Text style={[styles.text1, styles.text1Typo]}>
                      02/08/2024
                    </Text>
                    <Text style={[styles.nhpNiDung, styles.text1Typo]}>
                      Nhập nội dung ...
                    </Text>
                    <Text style={[styles.text2, styles.text2Typo]}>10:00</Text>
                  </View>
                </View>
                <View style={styles.lineView} />
              </View>
            </View>
            <Image
              style={styles.rectangleIcon}
              contentFit="cover"
              source={require("../assets/rectangle-90.png")}
            />
          </View>
          <Image
            style={styles.zondiconsfilm}
            contentFit="cover"
            source={require("../assets/zondiconsfilm.png")}
          />
        </View>
        <View style={styles.luBoCo}>
          <View style={[styles.luBoCoChild, styles.luBoCoChildLayout]} />
          <Text style={styles.luBoCo1}>Lưu báo cáo</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 66,
    width: 402,
    position: "absolute",
  },
  viewGroupPosition: {
    top: 0,
    left: 0,
  },
  groupItemLayout: {
    opacity: 0,
    width: "1.59%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  quayLayout: {
    maxHeight: "100%",
    position: "absolute",
  },
  chcNngLayout: {
    width: 62,
    position: "absolute",
  },
  chcLayout: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngItemPosition: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNngInnerLayout: {
    left: "50%",
    right: "35.97%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  groupLayout1: {
    height: 442,
    width: 374,
  },
  luBoCoChildLayout: {
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  groupLayout: {
    height: 85,
    width: 356,
    top: 0,
    position: "absolute",
  },
  groupFrameLayout: {
    width: 344,
    height: 85,
    top: 0,
    position: "absolute",
  },
  text2Typo: {
    height: 27,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    top: 13,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  text1Typo: {
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.openSansRegular,
    height: 27,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorGray_200,
    height: 66,
    width: 402,
    position: "absolute",
  },
  groupItem: {
    height: "9.04%",
    top: "66.87%",
    right: "39.24%",
    bottom: "24.1%",
    left: "59.16%",
  },
  rectangleParent: {
    top: 746,
    left: 0,
  },
  materialSymbolsLightpause: {
    top: 503,
    left: 149,
    width: 38,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  mnHnhHinThCngVicChild: {
    height: "0.74%",
    top: "97.29%",
    right: "36.49%",
    bottom: "1.97%",
    left: "61.92%",
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    color: Color.oil11,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_base,
    top: "0%",
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  quayLi: {
    top: 45,
    left: 19,
    width: 79,
    height: 19,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.02%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.65%",
    right: "55.32%",
    width: "14.03%",
    height: "20.98%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.02%",
    top: "0%",
  },
  ellipseIcon: {
    bottom: "50.73%",
    top: "28.29%",
  },
  chcNng1: {
    top: "70.98%",
    left: "12.9%",
    fontSize: FontSize.size_5xs,
    color: Color.colorWhite,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  chcNng: {
    top: 758,
    left: 17,
    height: 41,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    color: Color.colorWhite,
    left: "0%",
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    overflow: "hidden",
  },
  component1: {
    top: 754,
    left: 170,
    height: 40,
  },
  groupInner: {
    left: 5,
    width: 355,
    top: 59,
  },
  rectangleView: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorWhite,
    height: 442,
    width: 374,
    top: 0,
    left: 0,
  },
  groupContainer: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  cngVic1: {
    color: Color.colorDarkorchid,
  },
  text: {
    color: Color.colorBlack,
  },
  cngVic1Container: {
    width: 87,
    left: 8,
  },
  frameView: {
    width: 100,
    height: 33,
    opacity: 0.33,
    position: "absolute",
    overflow: "hidden",
  },
  text1: {
    left: 148,
    width: 85,
    top: 13,
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.openSansRegular,
  },
  nhpNiDung: {
    width: 273,
    left: 8,
    top: 59,
  },
  text2: {
    left: 302,
    width: 42,
    color: Color.colorBlack,
  },
  cngVic1Parent: {
    left: 0,
  },
  groupFrame: {
    left: 1,
  },
  lineView: {
    top: 40,
    borderColor: Color.colorGray_400,
    borderTopWidth: 1,
    width: 357,
    height: 1,
    left: 0,
    position: "absolute",
    borderStyle: "solid",
  },
  groupView: {
    left: 0,
  },
  groupWrapper: {
    left: 9,
  },
  rectangleIcon: {
    top: 191,
    left: 21,
    width: 332,
    height: 125,
    position: "absolute",
  },
  zondiconsfilm: {
    top: 221,
    left: 145,
    width: 91,
    height: 75,
    position: "absolute",
    overflow: "hidden",
  },
  luBoCoChild: {
    height: "100%",
    right: "0%",
    bottom: "0%",
    backgroundColor: Color.colorPaleturquoise,
    left: "0%",
    top: "0%",
    width: "100%",
  },
  luBoCo1: {
    height: "83.33%",
    width: "86.44%",
    top: "10.87%",
    left: "6.78%",
    fontSize: FontSize.size_mid,
    color: Color.colorSeagreen,
    fontFamily: FontFamily.openSansSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  luBoCo: {
    top: 400,
    left: 131,
    width: 118,
    height: 28,
    position: "absolute",
  },
  groupParent: {
    top: 105,
    left: 14,
    position: "absolute",
  },
  mnHnhHinThCngVic: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhitesmoke,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    borderStyle: "solid",
  },
});

export default MnHnhHinThCngVic;

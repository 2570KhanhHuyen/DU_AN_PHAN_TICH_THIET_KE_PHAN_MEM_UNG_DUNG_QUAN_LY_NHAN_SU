import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import Property1Component from "../components/Property1Component";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const XemBngCngCNhn = () => {
  return (
    <View style={styles.xemBangCongCaNha}>
      <View style={styles.xemBangCongCaNhaChild} />
      <Text style={styles.bngCngThng}>Bảng công tháng 4/2024</Text>
      <Image
        style={[styles.xemBangCongCaNhaItem, styles.xemPosition]}
        contentFit="cover"
        source={require("../assets/vector-151.png")}
      />
      <Image
        style={[styles.xemBangCongCaNhaInner, styles.xemPosition]}
        contentFit="cover"
        source={require("../assets/vector-161.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.quayLiItemLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-51.png")}
      />
      <View style={styles.quayLi}>
        <Text style={styles.quayLi1}>Quay lại</Text>
        <Image
          style={styles.quayLiChild}
          contentFit="cover"
          source={require("../assets/vector-13.png")}
        />
        <Image
          style={[styles.quayLiItem, styles.quayLiItemLayout]}
          contentFit="cover"
          source={require("../assets/vector-14.png")}
        />
      </View>
      <View style={[styles.chcNng, styles.chcNngLayout]}>
        <Image
          style={[styles.chcNngChild, styles.chcLayout1]}
          contentFit="cover"
          source={require("../assets/ellipse-403.png")}
        />
        <Image
          style={[styles.chcNngItem, styles.chcPosition]}
          contentFit="cover"
          source={require("../assets/ellipse-424.png")}
        />
        <Image
          style={[styles.chcNngInner, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-413.png")}
        />
        <Image
          style={[styles.chcNngChild1, styles.chcLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-433.png")}
        />
        <Text style={styles.chcNng1}>CHỨC NĂNG</Text>
      </View>
      <View style={[styles.component1, styles.chcNngLayout]}>
        <Text style={styles.trangCh}>TRANG CHỦ</Text>
        <Image
          style={styles.homeIcon}
          contentFit="cover"
          source={require("../assets/home.png")}
        />
      </View>
      <View style={styles.frameParent}>
        <View style={[styles.t2Wrapper, styles.wrapperLayout2]}>
          <Text style={[styles.t2, styles.t2Typo]}>T2</Text>
        </View>
        <View style={[styles.t3Wrapper, styles.wrapperLayout2]}>
          <Text style={[styles.t2, styles.t2Typo]}>T3</Text>
        </View>
        <View style={[styles.t4Wrapper, styles.wrapperLayout2]}>
          <Text style={[styles.t2, styles.t2Typo]}>T4</Text>
        </View>
        <View style={[styles.t5Wrapper, styles.wrapperLayout2]}>
          <Text style={[styles.t2, styles.t2Typo]}>T5</Text>
        </View>
        <View style={[styles.t6Wrapper, styles.wrapperLayout2]}>
          <Text style={[styles.t2, styles.t2Typo]}>T6</Text>
        </View>
        <View style={[styles.t7Wrapper, styles.wrapperLayout2]}>
          <Text style={[styles.t2, styles.t2Typo]}>T7</Text>
        </View>
      </View>
      <View style={[styles.cnWrapper, styles.wrapperPosition3]}>
        <Text style={[styles.cn, styles.t2Typo]}>CN</Text>
      </View>
      <View style={[styles.wrapper, styles.frameWrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>1</Text>
      </View>
      <View style={[styles.container, styles.wrapperPosition2]}>
        <Text style={[styles.text1, styles.textTypo1]}>2</Text>
      </View>
      <View style={[styles.parent, styles.groupLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>3</Text>
        <Text style={[styles.kPhep, styles.phepTypo]}>K phép</Text>
      </View>
      <View style={[styles.frame, styles.wrapperPosition1]}>
        <Text style={[styles.text, styles.textTypo1]}>4</Text>
      </View>
      <View style={[styles.frameView, styles.wrapperPosition]}>
        <Text style={[styles.text, styles.textTypo1]}>5</Text>
      </View>
      <View style={[styles.group, styles.groupLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>6</Text>
        <Text style={[styles.iTr, styles.phepTypo]}>Đi trễ</Text>
      </View>
      <View style={[styles.wrapper1, styles.frameWrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>7</Text>
      </View>
      <View style={[styles.wrapper2, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>18</Text>
      </View>
      <View style={[styles.wrapper3, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>14</Text>
      </View>
      <View style={[styles.wrapper4, styles.wrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>29</Text>
      </View>
      <View style={[styles.xemBangCongCaNhaChild1, styles.xemChildLayout]} />
      <View style={[styles.wrapper5, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>13</Text>
      </View>
      <View style={[styles.wrapper6, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>12</Text>
      </View>
      <View style={[styles.wrapper7, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>11</Text>
      </View>
      <View style={[styles.wrapper8, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>10</Text>
      </View>
      <View style={[styles.wrapper9, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>9</Text>
      </View>
      <View style={[styles.wrapper10, styles.wrapperLayout1]}>
        <Text style={[styles.text, styles.textTypo1]}>8</Text>
      </View>
      <View style={[styles.wrapper11, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>16</Text>
      </View>
      <View style={[styles.wrapper12, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>17</Text>
      </View>
      <View style={[styles.wrapper13, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>20</Text>
      </View>
      <View style={[styles.wrapper14, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>19</Text>
      </View>
      <Text style={[styles.nghiPhep, styles.phepTypo]}>Nghỉ phép</Text>
      <View style={[styles.wrapper15, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>21</Text>
      </View>
      <View style={[styles.wrapper16, styles.wrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>28</Text>
      </View>
      <View style={[styles.wrapper17, styles.wrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>27</Text>
      </View>
      <View style={[styles.wrapper18, styles.wrapperLayout]}>
        <Text style={[styles.text23, styles.textTypo1]}>26</Text>
      </View>
      <View style={[styles.wrapper19, styles.wrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>25</Text>
      </View>
      <View style={[styles.wrapper20, styles.wrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>24</Text>
      </View>
      <View style={[styles.parent1, styles.wrapperLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>23</Text>
        <Text style={[styles.cngTac, styles.phepTypo]}>Công tác</Text>
      </View>
      <View style={[styles.wrapper21, styles.xemChildLayout]}>
        <Text style={[styles.text, styles.textTypo1]}>30</Text>
      </View>
      <View style={[styles.xemBangCongCaNhaChild2, styles.xemChildLayout]} />
      <View style={[styles.xemBangCongCaNhaChild3, styles.xemChildLayout]} />
      <View style={[styles.xemBangCongCaNhaChild4, styles.xemChildLayout]} />
      <View style={[styles.xemBangCongCaNhaChild5, styles.xemChildLayout]} />
      <View style={[styles.xemBangCongCaNhaChild6, styles.xemChildLayout]} />
      <Text style={[styles.ngayCng, styles.ngayTypo]}>{`Ngày công: `}</Text>
      <Text style={[styles.ngayNghi, styles.ngayTypo]}>Ngày nghỉ:</Text>
      <Text style={[styles.ngayCngTac, styles.ngayTypo]}>Ngày công tác:</Text>
      <Text style={[styles.liPhat, styles.ngayTypo]}>Lỗi phạt:</Text>
      <Text style={[styles.text28, styles.textTypo]}>24</Text>
      <Text style={[styles.text29, styles.textTypo]}>01</Text>
      <Text style={[styles.text30, styles.textTypo]}>01</Text>
      <Text style={[styles.kPhep1, styles.iTr1Typo]}>01- K phép</Text>
      <Text style={[styles.iTr1, styles.iTr1Typo]}>01- Đi trễ</Text>
      <View style={[styles.wrapper22, styles.wrapperBorder]}>
        <Text style={[styles.text, styles.textTypo1]}>22</Text>
      </View>
      <Property1Component
        iconPerson={require("../assets/-icon-person.png")}
        propTop={762}
        propLeft={335}
        propFontWeight="unset"
        propFontFamily="Roboto-Regular"
        propColor="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  xemPosition: {
    maxHeight: "100%",
    top: 108,
    position: "absolute",
  },
  quayLiItemLayout: {
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngLayout: {
    height: 40,
    position: "absolute",
  },
  chcLayout1: {
    left: "30.66%",
    right: "55.25%",
    width: "14.1%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcPosition: {
    bottom: "51%",
    top: "28.25%",
  },
  chcLayout: {
    left: "50%",
    right: "35.9%",
    width: "14.1%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  wrapperLayout2: {
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    height: 43,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  t2Typo: {
    height: 14,
    width: 30,
    color: Color.colorBlack,
    fontFamily: FontFamily.interBold,
    textAlign: "left",
    fontWeight: "700",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  wrapperPosition3: {
    left: 335,
    backgroundColor: Color.colorDimgray_700,
  },
  frameWrapperLayout: {
    top: 173,
    height: 73,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  textTypo1: {
    height: 17,
    width: 29,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  wrapperPosition2: {
    left: 70,
    backgroundColor: Color.colorDimgray_600,
  },
  groupLayout: {
    backgroundColor: Color.colorRed,
    height: 73,
    top: 173,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  phepTypo: {
    height: 11,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  wrapperPosition1: {
    left: 176,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapperPosition: {
    left: 229,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapperBorder: {
    top: 319,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  wrapperLayout1: {
    top: 246,
    height: 73,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  wrapperLayout: {
    top: 392,
    height: 73,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  xemChildLayout: {
    top: 465,
    height: 73,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  ngayTypo: {
    height: 27,
    width: 130,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  textTypo: {
    width: 39,
    height: 17,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  iTr1Typo: {
    width: 100,
    height: 17,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  xemBangCongCaNhaChild: {
    top: 746,
    backgroundColor: Color.colorGray_200,
    width: 399,
    height: 66,
    left: 0,
    position: "absolute",
  },
  bngCngThng: {
    top: 83,
    fontFamily: FontFamily.openSansBold,
    color: Color.colorMediumaquamarine_200,
    textAlign: "left",
    fontWeight: "700",
    fontSize: FontSize.size_base,
    left: 31,
    position: "absolute",
  },
  xemBangCongCaNhaItem: {
    width: 340,
    left: 31,
  },
  xemBangCongCaNhaInner: {
    left: 3,
    width: 398,
  },
  ellipseIcon: {
    height: "0.74%",
    width: "1.59%",
    top: "97.29%",
    right: "35.5%",
    bottom: "1.97%",
    left: "62.91%",
    opacity: 0,
  },
  quayLi1: {
    width: "86.08%",
    left: "13.92%",
    color: Color.oil11,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    top: "0%",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  quayLiChild: {
    height: "36.32%",
    width: "4.56%",
    top: "33.16%",
    right: "95.44%",
    bottom: "30.53%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  quayLiItem: {
    height: "5.26%",
    width: "14.18%",
    top: "51.58%",
    right: "85.57%",
    bottom: "43.16%",
    left: "0.25%",
  },
  quayLi: {
    top: 41,
    width: 79,
    height: 19,
    left: 31,
    position: "absolute",
  },
  chcNngChild: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngItem: {
    left: "30.66%",
    right: "55.25%",
    width: "14.1%",
    height: "20.75%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  chcNngInner: {
    bottom: "79.25%",
    top: "0%",
  },
  chcNngChild1: {
    bottom: "51%",
    top: "28.25%",
  },
  chcNng1: {
    top: "71%",
    left: "11.48%",
    fontSize: FontSize.size_5xs,
    color: Color.colorWhite,
    textAlign: "center",
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  chcNng: {
    top: 762,
    left: 24,
    width: 61,
  },
  trangCh: {
    height: "21.5%",
    top: "78.5%",
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    left: "0%",
    fontFamily: FontFamily.robotoRegular,
    textAlign: "left",
    position: "absolute",
    width: "100%",
  },
  homeIcon: {
    height: "78.5%",
    width: "63.55%",
    right: "18.71%",
    bottom: "21.5%",
    left: "17.74%",
    top: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  component1: {
    top: 755,
    width: 62,
    left: 169,
  },
  t2: {
    top: 15,
    left: 12,
  },
  t2Wrapper: {
    backgroundColor: Color.colorDimgray_700,
    top: 0,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    left: 0,
  },
  t3Wrapper: {
    left: 53,
    backgroundColor: Color.colorDimgray_700,
    top: 0,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
  },
  t4Wrapper: {
    left: 106,
    backgroundColor: Color.colorDimgray_700,
    top: 0,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
  },
  t5Wrapper: {
    left: 159,
    backgroundColor: Color.colorDimgray_700,
    top: 0,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
  },
  t6Wrapper: {
    left: 212,
    backgroundColor: Color.colorDimgray_700,
    top: 0,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
  },
  t7Wrapper: {
    left: 265,
    backgroundColor: Color.colorDimgray_700,
    top: 0,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
  },
  frameParent: {
    width: 318,
    height: 43,
    left: 17,
    top: 130,
    position: "absolute",
  },
  cn: {
    top: 14,
    left: 16,
  },
  cnWrapper: {
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    height: 43,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
    top: 130,
    left: 335,
  },
  text: {
    left: 20,
    top: 7,
    height: 17,
    width: 29,
    fontFamily: FontFamily.interRegular,
  },
  wrapper: {
    height: 73,
    backgroundColor: Color.colorDimgray_600,
    left: 17,
  },
  text1: {
    top: 8,
    left: 20,
  },
  container: {
    height: 73,
    top: 173,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  kPhep: {
    width: 45,
    height: 11,
    top: 27,
    left: 12,
  },
  parent: {
    left: 123,
  },
  frame: {
    height: 73,
    top: 173,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  frameView: {
    height: 73,
    top: 173,
    width: 53,
    borderWidth: 1,
    borderColor: Color.colorGray_300,
    position: "absolute",
    overflow: "hidden",
    borderStyle: "solid",
  },
  iTr: {
    left: 14,
    width: 45,
    height: 11,
    top: 27,
  },
  group: {
    left: 282,
  },
  wrapper1: {
    height: 73,
    left: 335,
    backgroundColor: Color.colorDimgray_700,
  },
  wrapper2: {
    backgroundColor: "rgba(205, 68, 76, 0.41)",
    height: 74,
    left: 123,
  },
  wrapper3: {
    left: 335,
    backgroundColor: Color.colorDimgray_700,
  },
  wrapper4: {
    left: 335,
    backgroundColor: Color.colorDimgray_700,
  },
  xemBangCongCaNhaChild1: {
    left: 335,
    backgroundColor: Color.colorDimgray_700,
  },
  wrapper5: {
    left: 282,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper6: {
    left: 229,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper7: {
    left: 176,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper8: {
    left: 123,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper9: {
    left: 70,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper10: {
    backgroundColor: Color.colorDimgray_600,
    left: 17,
  },
  wrapper11: {
    height: 73,
    backgroundColor: Color.colorDimgray_600,
    left: 17,
  },
  wrapper12: {
    left: 70,
    backgroundColor: Color.colorDimgray_600,
    height: 73,
  },
  wrapper13: {
    left: 229,
    backgroundColor: Color.colorDimgray_600,
    height: 73,
  },
  wrapper14: {
    left: 176,
    backgroundColor: Color.colorDimgray_600,
    height: 73,
  },
  nghiPhep: {
    top: 346,
    left: 125,
    width: 49,
  },
  wrapper15: {
    left: 282,
    height: 73,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper16: {
    left: 282,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper17: {
    left: 229,
    backgroundColor: Color.colorDimgray_600,
  },
  text23: {
    top: 7,
    height: 17,
    width: 29,
    fontFamily: FontFamily.interRegular,
    left: 17,
  },
  wrapper18: {
    left: 176,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper19: {
    left: 123,
    backgroundColor: Color.colorDimgray_600,
  },
  wrapper20: {
    left: 70,
    backgroundColor: Color.colorDimgray_600,
  },
  cngTac: {
    top: 31,
    left: 4,
    width: 45,
    height: 11,
  },
  parent1: {
    backgroundColor: "rgba(225, 243, 118, 0.7)",
    left: 17,
  },
  wrapper21: {
    backgroundColor: Color.colorDimgray_600,
    left: 17,
  },
  xemBangCongCaNhaChild2: {
    left: 70,
    backgroundColor: Color.colorDimgray_600,
  },
  xemBangCongCaNhaChild3: {
    left: 123,
    backgroundColor: Color.colorDimgray_600,
  },
  xemBangCongCaNhaChild4: {
    left: 176,
    backgroundColor: Color.colorDimgray_600,
  },
  xemBangCongCaNhaChild5: {
    left: 229,
    backgroundColor: Color.colorDimgray_600,
  },
  xemBangCongCaNhaChild6: {
    left: 282,
    backgroundColor: Color.colorDimgray_600,
  },
  ngayCng: {
    top: 557,
    left: 20,
  },
  ngayNghi: {
    top: 584,
    left: 20,
  },
  ngayCngTac: {
    top: 613,
    left: 20,
  },
  liPhat: {
    top: 641,
    left: 21,
  },
  text28: {
    top: 560,
    left: 169,
  },
  text29: {
    left: 172,
    top: 584,
  },
  text30: {
    left: 172,
    top: 613,
  },
  kPhep1: {
    top: 642,
    left: 171,
  },
  iTr1: {
    top: 666,
    left: 172,
  },
  wrapper22: {
    height: 73,
    left: 335,
    backgroundColor: Color.colorDimgray_700,
  },
  xemBangCongCaNha: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorWhite,
    borderColor: Color.colorBlack,
    borderWidth: 4,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    borderStyle: "solid",
  },
});

export default XemBngCngCNhn;
